#include "sdio.h"

#include "wq_log.h"

static inline int wq_skbreq_init(struct wq_skbreq *req, struct wq_sdio *unused)
{
	(void)unused;
	return 0;
}

#ifdef SDIO_RX_AGGR_MODE
static inline int wq_skbreq_aggrin_init(struct wq_skbreq *req,
					struct wq_sdio *wq_sdio)
{
	req->skb = __dev_alloc_skb(SDIO_ADMA_RX_LEN_MAX, GFP_KERNEL);
	if (req->skb) {
		return 0;
	} else {
		WQ_DBG(DM_TRBUS, DL_ERR, "%s: __dev_alloc_skb failed\n",
		       __func__);
		return -ENOMEM;
	}
}
#endif

#ifdef SDIO_TX_AGGR_MODE
static inline int wq_skbreq_aggrout_init(struct wq_skbreq *req,
					 struct wq_sdio *wq_sdio)
{
	req->skb = __dev_alloc_skb(SDIO_ADMA_WLAN_TX_LEN_MAX, GFP_KERNEL);
	if (req->skb) {
		return 0;
	} else {
		WQ_DBG(DM_TRBUS, DL_ERR, "%s: __dev_alloc_skb failed\n",
		       __func__);
		return -ENOMEM;
	}
}
#endif

static inline void wq_skbreq_deinit(struct wq_skbreq *req, void *unused)
{
	struct sk_buff *skb = req->skb;

	(void)unused;
	if (skb) {
		req->skb = NULL;
		dev_kfree_skb_any(skb);
	}
}

static WQ_LIST_POOL_INIT_FN(wq_skbreq_pool_init, struct wq_skbreq, list,
			    struct wq_sdio *);
static WQ_LIST_POOL_DEINIT_FN(wq_skbreq_pool_deinit, struct wq_skbreq, list,
			      void *);

/**
 * wq_skbreq_pool_grow_one_ex - Grow one entry (internal with callback args)
 * @pool: the grow-on-demand pool to grow
 * @init: per-entry initialization callback
 * @ctx: context passed to init callback
 * @gfp: GFP flags for allocation
 *
 * Concurrency: heavy work (kmalloc / __dev_alloc_skb) is done outside the lock
 * and may sleep; the commit takes pool->pool.list.lock and double-checks the bound,
 * discarding the extra entry if already at max. Concurrent growers may transiently
 * over-allocate one entry which is then safely dropped.
 *
 * Returns: 0 on success; -ENOMEM on entry/skb allocation failure; -ENOSPC when
 * the growth bound is reached.
 */
static int wq_skbreq_pool_grow_one_ex(struct wq_skbreq_pool *pool,
				      int (*init)(struct wq_skbreq *, struct wq_sdio *),
				      struct wq_sdio *ctx, gfp_t gfp)
{
	struct wq_skbreq *req;
	unsigned long flags;
	int ret;

	/* Fast fail at the bound (lockless read is only an optimization; the
	 * authoritative check happens under the lock). */
	if (READ_ONCE(pool->pool.num) >= pool->max)
		return -ENOSPC;

	req = kmalloc(sizeof(struct wq_skbreq), gfp);
	if (!req)
		return -ENOMEM;
	memset(req, 0, sizeof(*req));
	INIT_LIST_HEAD(&req->list);

	ret = init(req, ctx);
	if (ret) {
		kfree(req);
		return ret;
	}

	spin_lock_irqsave(&pool->pool.list.lock, flags);
	if (pool->pool.num >= pool->max) {
		/* Someone else filled it within the race window; drop our extra entry */
		spin_unlock_irqrestore(&pool->pool.list.lock, flags);
		if (req->skb)
			dev_kfree_skb_any(req->skb);
		kfree(req);
		return -ENOSPC;
	}

	/* Commit: push onto the free list (lockless __ variant, lock already held)
	 * and bump the total count. */
	__wq_skbreq_enqueue(&pool->pool.list, req);
	pool->pool.num++;
	spin_unlock_irqrestore(&pool->pool.list.lock, flags);

	return 0;
}

/**
 * wq_skbreq_pool_grow_one - Grow one entry (uses pool's stored init callback)
 * @pool: the grow-on-demand pool to grow
 * @gfp: GFP flags for allocation
 *
 * Public wrapper that uses init_fn/init_ctx stored in the pool structure.
 * Returns: 0 on success; -ENOMEM / -ENOSPC on failure.
 */
int wq_skbreq_pool_grow_one(struct wq_skbreq_pool *pool, gfp_t gfp)
{
	return wq_skbreq_pool_grow_one_ex(pool, pool->init_fn, pool->init_ctx, gfp);
}

/**
 * wq_skbreq_pool_alloc_growable - Get a free entry with on-demand growth
 * @pool: the grow-on-demand pool to allocate from
 *
 * Tries to get a free entry; if none available and below max, grows one then retries.
 * May sleep (GFP_KERNEL), so callers must not hold spinlocks.
 *
 * Returns: a free wq_skbreq on success, NULL at max bound or allocation failure
 */
struct wq_skbreq *wq_skbreq_pool_alloc_growable(struct wq_skbreq_pool *pool)
{
	struct wq_skbreq *req;

	req = wq_skbreq_alloc(&pool->pool);
	if (req)
		return req;

	if (wq_skbreq_pool_grow_one(pool, GFP_KERNEL) == 0)
		return wq_skbreq_alloc(&pool->pool);

	return NULL;
}

/**
 * wq_skbreq_pool_init_growable - Initialize a grow-on-demand pool
 * @pool: the grow-on-demand pool to initialize
 * @min: number of bootstrap entries to preallocate
 * @max: maximum number of entries allowed (growth upper bound)
 * @init: per-entry initialization callback
 * @ctx: context passed to init callback
 *
 * Preallocates `min` bootstrap entries and records growth parameters. Unlike the
 * WQ_LIST_POOL_INIT_FN macro, failures are cleaned up (no half-built entries remain),
 * and returns success count or negative error for caller decision-making.
 *
 * Returns: >=0 actual bootstrap entries allocated; <0 on fatal failure
 */
int wq_skbreq_pool_init_growable(struct wq_skbreq_pool *pool, u16 min, u16 max,
				 int (*init)(struct wq_skbreq *,
					     struct wq_sdio *),
				 struct wq_sdio *ctx)
{
	int i;
	int ret = 0;

	INIT_WQ_LIST_HEAD(&pool->pool.list);
	pool->pool.size = sizeof(struct wq_skbreq);
	pool->pool.entries = NULL;   /* list-based, no contiguous array */
	pool->pool.num = 0;
	pool->min = min;
	pool->max = max;
	pool->init_fn = init;
	pool->init_ctx = ctx;

	for (i = 0; i < min; i++) {
		ret = wq_skbreq_pool_grow_one_ex(pool, init, ctx, GFP_KERNEL);
		if (ret)
			break;
	}

	if (i == 0) {
		WQ_DBG(DM_TRBUS, DL_ERR, "%s: bootstrap alloc failed (%d)\n",
		       __func__, ret);
		return ret;
	}

	WQ_DBG(DM_TRBUS, DL_INF, "%s: bootstrap %d entries, max %d\n",
	       __func__, i, max);
	return i;
}

/**
 * wq_skbreq_pool_deinit_growable - Deinitialize a grow-on-demand pool
 * @pool: the grow-on-demand pool to deinitialize
 *
 * Drains the free list and frees all big skbs and entry structures.
 * Precondition: all in-flight entries must be returned first via
 * wq_sdio_func_queue_deinit (same lifecycle as existing deinit flow).
 *
 * Includes guard for uninitialized pools - safely returns if init_fn is NULL,
 * which indicates the pool was never initialized (e.g., init failed before reaching
 * this aggr pool).
 */
void wq_skbreq_pool_deinit_growable(struct wq_skbreq_pool *pool)
{
	struct wq_skbreq *req;

	/* Skip if the pool was never initialized (init_fn NULL = zeroed struct) */
	if (!pool->init_fn)
		return;

	while ((req = wq_skbreq_dequeue(&pool->pool.list)) != NULL) {
		if (req->skb)
			dev_kfree_skb_any(req->skb);
		kfree(req);
	}

	pool->pool.num = 0;
	pool->min = 0;
	pool->max = 0;
	pool->pool.entries = NULL;
	pool->init_fn = NULL;
	pool->init_ctx = NULL;
}

/**
 * wq_sdio_pools_init - Initialize all driver memory pools
 * @wq_sdio: sdio private device structure
 *
 * Initializes pktout/msgout (core metadata pools) and grow-on-demand aggrin/aggrout pools.
 * Failure for core pools is fatal; aggr pool failures allow probe to continue without aggr mode.
 *
 * Returns: 0 on success, negative error code on failure
 */
int wq_sdio_pools_init(struct wq_sdio *wq_sdio)
{
	int ret;
	const char *pool;

	/* pktout/msgout are core metadata pools (small, no big skb); keep the
	 * original logic, failure remains fatal. */
	ret = wq_skbreq_pool_init(&wq_sdio->pools.pktout, WQ_PTKOUT_NUM,
				  wq_skbreq_init, NULL);
	if (ret <= 0) {
		pool = "pktout";
		goto fail;
	}

	ret = wq_skbreq_pool_init(&wq_sdio->pools.msgout, WQ_MSGOUT_NUM,
				  wq_skbreq_init, NULL);
	if (ret <= 0) {
		pool = "msgout";
		goto fail;
	}

#ifdef SDIO_RX_AGGR_MODE
	/* Only preallocate the WQ_AGGIN_MIN bootstrap, grow up to WQ_AGGIN_NUM */
	ret = wq_skbreq_pool_init_growable(&wq_sdio->pools.aggrin, WQ_AGGIN_MIN,
					   WQ_AGGIN_NUM, wq_skbreq_aggrin_init, wq_sdio);
	if (ret < 0) {
		wq_sdio->pools.aggrin.pool.num = 0;
		pool = "aggrin";
		goto fail;
	}
#endif

#ifdef SDIO_TX_AGGR_MODE
	/* Only preallocate the WQ_AGGROUT_MIN bootstrap, grow up to WQ_AGGROUT_NUM */
	ret = wq_skbreq_pool_init_growable(&wq_sdio->pools.aggrout, WQ_AGGROUT_MIN,
					   WQ_AGGROUT_NUM, wq_skbreq_aggrout_init,
					   wq_sdio);
	if (ret < 0) {
		wq_sdio->pools.aggrout.pool.num = 0;
		pool = "aggrout";
		goto fail;
	}
#endif

	(void)pool;

	return 0;

fail:
	WQ_DBG(DM_TRBUS, DL_ERR, "%s: init pool %s failed\n", __func__, pool);
	return -1;
}

/**
 * wq_sdio_pools_deinit - Deinitialize all driver memory pools
 * @wq_sdio: sdio private device structure
 */
void wq_sdio_pools_deinit(struct wq_sdio *wq_sdio)
{
	wq_skbreq_pool_deinit(&wq_sdio->pools.msgout, wq_skbreq_deinit, NULL);
	wq_skbreq_pool_deinit(&wq_sdio->pools.pktout, wq_skbreq_deinit, NULL);

#ifdef SDIO_RX_AGGR_MODE
	wq_skbreq_pool_deinit_growable(&wq_sdio->pools.aggrin);
#endif

#ifdef SDIO_TX_AGGR_MODE
	wq_skbreq_pool_deinit_growable(&wq_sdio->pools.aggrout);
#endif
}
