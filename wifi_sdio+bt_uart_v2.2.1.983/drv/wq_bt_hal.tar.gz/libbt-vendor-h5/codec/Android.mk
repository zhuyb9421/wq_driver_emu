LOCAL_PATH := $(call my-dir)

# libbt-codec.a
include $(CLEAR_VARS)

LOCAL_SRC_FILES := \
        ./plc/sbcplc.c \
        ./msbc/ms_sbc.c \
        msbc/encoder/srce/sbc_analysis.c \
        msbc/encoder/srce/sbc_dct.c \
        msbc/encoder/srce/sbc_dct_coeffs.c \
        msbc/encoder/srce/sbc_enc_bit_alloc_mono.c \
        msbc/encoder/srce/sbc_enc_bit_alloc_ste.c \
        msbc/encoder/srce/sbc_enc_coeffs.c \
        msbc/encoder/srce/sbc_encoder.c \
        msbc/encoder/srce/sbc_packing.c \
        msbc/decoder/srce/alloc.c \
        msbc/decoder/srce/bitalloc.c \
        msbc/decoder/srce/bitalloc-sbc.c \
        msbc/decoder/srce/bitstream-decode.c \
        msbc/decoder/srce/decoder-oina.c \
        msbc/decoder/srce/decoder-private.c \
        msbc/decoder/srce/decoder-sbc.c \
        msbc/decoder/srce/dequant.c \
        msbc/decoder/srce/framing.c \
        msbc/decoder/srce/framing-sbc.c \
        msbc/decoder/srce/oi_codec_version.c \
        msbc/decoder/srce/synthesis-8-generated.c \
        msbc/decoder/srce/synthesis-dct8.c \
        msbc/decoder/srce/synthesis-sbc.c \
        cvsd/src/cvsd.c

LOCAL_C_INCLUDES := \
        $(LOCAL_PATH)/include \
        $(LOCAL_PATH)/plc \
        $(LOCAL_PATH)/msbc \
        $(LOCAL_PATH)/msbc/decoder/include \
        $(LOCAL_PATH)/msbc/encoder/include \
        $(LOCAL_PATH)/cvsd/inc

LOCAL_CFLAGS := \
        -Wno-error=unused-parameter \
        -Wno-ignored-attributes

LOCAL_MODULE_TAGS := optional
LOCAL_PROPRIETARY_MODULE := true
LOCAL_SHARED_LIBRARIES := libcutils libc
LOCAL_MODULE := libwq-bt-codec
#LOCAL_MULTILIB := 32

include $(BUILD_STATIC_LIBRARY)

