
#include <stdint.h>
#include <string.h>
#include "oi_assert.h"
#include "oi_codec_sbc.h"
#include "ms_sbc.h"

#ifndef UNUSED
#define UNUSED(x) (void)(x)
#endif

//#define DECODER_DATA_BYTES      1536
#define DECODER_DATA_BYTES 1536 * 2

void *ms_sbc_decode_init(unsigned char *buf, int *len, int type, unsigned char out_ch)
{
    OI_CODEC_SBC_DECODER_CONTEXT *context;
    OI_UINT32 *decoderData;
    OI_STATUS ret;

    if (buf == NULL) {
        *len = sizeof(OI_CODEC_SBC_DECODER_CONTEXT) /* 96 bytes */ + DECODER_DATA_BYTES;
        return NULL;
    }

    //APP_CODEC_LOG( "sizeof( OI_CODEC_SBC_DECODER_CONTEXT) = %d\n", ( int)sizeof( OI_CODEC_SBC_DECODER_CONTEXT));

    //os_assert( *len >= ( sizeof( OI_CODEC_SBC_DECODER_CONTEXT) /* 96 bytes */ + DECODER_DATA_BYTES));

    context = (OI_CODEC_SBC_DECODER_CONTEXT *)buf;
    buf += sizeof(OI_CODEC_SBC_DECODER_CONTEXT);

    decoderData = (OI_UINT32 *)buf;
    buf += DECODER_DATA_BYTES;

    *len = (sizeof(OI_CODEC_SBC_DECODER_CONTEXT) + DECODER_DATA_BYTES);

    memset(context, 0, *len);

    if (type == TYPE_MSBC) {
        ret = OI_CODEC_mSBC_DecoderReset(context, decoderData, DECODER_DATA_BYTES);
    } else {
        OI_UINT8 pcmStride = (type == TYPE_SBC_STEREO) ? 2 : 1;
        ret = OI_CODEC_SBC_DecoderReset(context, decoderData, DECODER_DATA_BYTES, 2, pcmStride, FALSE);
    }
    //os_assert( ret == OI_OK);

    if (ret != OI_OK) {
        return NULL;
    }

    //os_dbg( "sbctimd ms_sbc_decode_init:%d %d %d\n",ret,type,*len);

    return (void *)context;
}

void ms_sbc_decode_exit(void)
{
}

int ms_sbc_decode(void *handle, unsigned char *in, int in_len, unsigned char *out, int *out_len)
{
    return (int)OI_CODEC_SBC_DecodeFrame((OI_CODEC_SBC_DECODER_CONTEXT *)handle, (const OI_BYTE **)&in,
                                         (OI_UINT32 *)&in_len, (OI_INT16 *)out, (OI_UINT32 *)out_len);
}

#include "sbc_encoder.h"

//static SBC_ENC_PARAMS sbc_encoder;

void *ms_sbc_encode_init(unsigned char *buf, int *len)
{
    SBC_ENC_PARAMS *sbc_encoder;

    if (buf == NULL || (uint32_t)(*len) < sizeof(SBC_ENC_PARAMS)) {
        *len = sizeof(SBC_ENC_PARAMS);
        return NULL;
    }

    //os_assert(*len >= sizeof(SBC_ENC_PARAMS));

    sbc_encoder = (SBC_ENC_PARAMS *)buf;
    *len = (sizeof(SBC_ENC_PARAMS));

    memset(buf, 0, *len);

    sbc_encoder->mSBCEnabled = 1;
    sbc_encoder->s16NumOfBlocks = 15;
    sbc_encoder->s16NumOfSubBands = 8;
    sbc_encoder->s16AllocationMethod = SBC_LOUDNESS;
    sbc_encoder->s16BitPool = 26;
    sbc_encoder->s16ChannelMode = SBC_MONO;
    sbc_encoder->s16NumOfChannels = 1;
    sbc_encoder->s16SamplingFreq = SBC_sf16000;

    SBC_Encoder_Init(sbc_encoder);

    return (void *)sbc_encoder;
}

int ms_sbc_encode(void *handle, unsigned char *in, int in_len, unsigned char *out, int out_len)
{
    UNUSED(in_len);
    UNUSED(out_len);
    SBC_ENC_PARAMS *sbc_encoder = (SBC_ENC_PARAMS *)handle;
    //int enc_size = 0;

#if (SBC_NO_PCM_CPY_OPTION == TRUE)
    sbc_encoder->ps16PcmBuffer = (SINT16 *)in;
#else
    BT_mem_copy_s(sbc_encoder->as16PcmBuffer, sizeof(sbc_encoder->as16PcmBuffer), in, in_len);
#endif

    sbc_encoder->pu8Packet = out;
    sbc_encoder->u16PacketLength = 0;

    SBC_Encoder(sbc_encoder);

    //enc_size = 4 + (4 * sbc_encoder->s16NumOfSubBands * sbc_encoder->s16NumOfChannels) / 8;
    //enc_size += ((sbc_encoder->s16NumOfBlocks * sbc_encoder->s16NumOfChannels * sbc_encoder->s16BitPool) + 7) / 8;
    return sbc_encoder->u16PacketLength;
}
