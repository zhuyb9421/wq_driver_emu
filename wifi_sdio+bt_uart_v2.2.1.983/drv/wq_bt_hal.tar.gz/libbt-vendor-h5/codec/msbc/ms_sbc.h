#ifndef _MS_SBC_H_
#define _MS_SBC_H_

enum {
    TYPE_SBC_STEREO = 0,
    TYPE_SBC_MONO,
    TYPE_MSBC
};

/**
 * @brief This function is used to init ms sbc decode.
 *
 * @param buf is the pointer of decode buffer.
 * @param len is the length of decode buffer.
 * @param type is the type of msbc decode.
 * @param out_ch is the channel of output.
 * @return void* return msbc decode info.
 */
void *ms_sbc_decode_init(unsigned char *buf, int *len, int type, unsigned char out_ch);

/**
 * @brief  This function is used to exit ms sbc decode.
 *
 */
void ms_sbc_decode_exit(void);

/**
 * @brief  This function is used to decode ms sbc.
 *
 * @param handle is the handle of sbc decode.
 * @param in is the input pointer of decode.
 * @param in_len is the input length of decode.
 * @param out is the output pointer of decode.
 * @param out_len is the output length of decode.
 * @return int show decode status.
 */
int ms_sbc_decode(void *handle, unsigned char *in, int in_len, unsigned char *out, int *out_len);

/**
 * @brief  This function is used to init ms sbc encode.
 *
 * @param buf is the pointer of encode buffer.
 * @param len is the length of ecnode buffer.
 * @return void* return sbc encode info.
 */
void *ms_sbc_encode_init(unsigned char *buf, int *len);

/**
 * @brief  This function is used to encode ms sbc.
 *
 * @param handle is the handle of sbc encode.
 * @param in is the input pointer of encode.
 * @param in_len is the input length of encode.
 * @param out is the output pointer of encode.
 * @param out_len is the output length of encode.
 * @return int return sbc encode u16PacketLength.
 */
int ms_sbc_encode(void *handle, unsigned char *in, int in_len, unsigned char *out, int out_len);

/**
 * @brief  This function is used to init ms sbc mono encode.
 *
 * @param sample_rate is the sample rate of sbc mono encode.
 * @param frame_len is the frame length of sbc mono encode.
 * @param buf is the pointer of sbc mono encode.
 * @param len is the length of sbc mono encode.
 * @return void* return sbc mono encode info.
 */
void *ms_sbc_mono_encode_init(int sample_rate, int *frame_len, unsigned char *buf, int *len);
#define ms_sbc_mono_encode ms_sbc_encode

#endif /* _MS_SBC_H_ */
