/** @file bt_address.h
 *
 * @brief This file is for bt address.
 *
 *  Copyright (C) 2021, WuQi Technologies. ALL RIGHTS RESERVED.
 *
 *  This Information is proprietary to WuQi Technologies and MAY NOT
 *  be copied by any method or incorporated into another program without
 *  the express written consent of WuQi. This Information or any portion
 *  thereof remains the property of WuQi. The Information contained herein
 *  is believed to be accurate and WuQi assumes no responsibility or
 *  liability for its use in any way and conveys no license or title under
 *  any patent or copyright and makes no representation or warranty that this
 *  Information is free from patent or copyright infringement.
 *
 */

#ifndef _BT_ADDRESS_H
#define _BT_ADDRESS_H

#include <fcntl.h>
#include <stdint.h>
#include <string.h>
#include <cutils/properties.h>

#define BT_ADDR_SIZE 6
// Check for a legacy address stored as a property.
static char PERSIST_BDADDR_PROPERTY[] = "persist.service.wq.bdaddr";

static size_t kStringLength = sizeof("XX:XX:XX:XX:XX:XX") - 1;
static size_t kBytes = (sizeof("XX:XX:XX:XX:XX:XX")) / 3;

typedef struct
{
    uint8_t bt_addr[BT_ADDR_SIZE];
} bt_addr_t;

void bytes_to_string(const uint8_t *addr, char *addr_str);

bool string_to_bytes(const char *addr_str, uint8_t *addr);

bool analysis_bt_address(uint8_t *addr);

#endif
