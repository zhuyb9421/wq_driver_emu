/******************************************************************************
 *
 *  Copyright (C) 2009-2018 WuQi Corporation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at:
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 ******************************************************************************/
/******************************************************************************
 *
 *	Module Name:
 *	    bt_parse.h
 *
 *	Abstract:
 *	    Contains wifi-bt coex functions implemented by bluedroid stack
 *
 *	Major Change History:
 *	      When             Who       What
 *	    ---------------------------------------------------------------
 *	    2015-12-15      lamparten   modified
 *	    2014-10-23       kyle_xu    modified
 *
 *	Notes:
 *         This is designed for wifi-bt Coex in Android 6.0.
 *
 ******************************************************************************/

#ifndef BT_PARSE_H
#define BT_PARSE_H

#pragma once

#include <stdlib.h>
#include <strings.h>
#include "bt_vendor_wuqi.h"
#include "userial_vendor.h"

/******************************************************************************
**  Constants & Macros
******************************************************************************/

/******************************************************************************
**  Type definitions
******************************************************************************/
typedef unsigned char UINT8;

/******************************************************************************
**  Extern variables and functions
******************************************************************************/
extern uint8_t coex_log_enable;

/******************************************************************************
**  Functions
******************************************************************************/
typedef struct bt_parse_manager_t
{
    void (*bt_parse_internal_event_intercept)(uint8_t *p);
    void (*bt_parse_init)(void);
    void (*bt_parse_cleanup)(void);
    void (*bt_set_bt_on)(uint8_t bt_on);
} bt_parse_manager_t;

bt_parse_manager_t *bt_parse_manager_get_interface();
#endif /*BT_PARSE_H*/
