/******************************************************************************
 *
 *  Copyright (C) 2009-2018 WuQi Corporation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at:
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 ******************************************************************************/

/******************************************************************************
 *
 *  Filename:      userial_vendor.h
 *
 *  Description:   Contains vendor-specific definitions used in serial port
 *                 controls
 *
 ******************************************************************************/

#ifndef WUQI_SOCKET_H
#define WUQI_SOCKET_H

#include "bt_vendor_wuqi.h"
#include <sys/poll.h>
#include <assert.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/poll.h>
#include <sys/prctl.h>
#include <sys/un.h>

#define MAX(a, b) ((a) > (b) ? (a) : (b))

/******************************************************************************
**  Constants & Macros
******************************************************************************/

uint32_t Skt_Read(int fd, uint8_t *p_buf, uint32_t len, bool *condition);
int Skt_Read_noblock(int fd, uint8_t *p_buf, uint32_t len);
bool Skt_Send(int fd, uint8_t *p_buf, uint16_t msglen);
int Skt_Send_noblock(int fd, uint8_t *p_buf, uint16_t msglen);
#endif
