#ifndef BT_TRANSPORT_CONFIG_H
#define BT_TRANSPORT_CONFIG_H

#include <stdbool.h>
#include <stdint.h>

#define BT_TRANS_H4 0x20
#define BT_TRANS_H5 0x10
#define BT_TRANS_UART 0x01
#define BT_TRANS_HCI_SOCKET 0x02
#define BT_TRANS_HCI_SOCKET_FALLBACK 0x04

typedef struct {
    uint8_t transtype;
    bool use_mbtchar;
} bt_transport_config_t;

bool bt_transport_config_parse(const char *mode,
                               bt_transport_config_t *config);

#endif
