#ifndef BT_VENDOR_OPEN_H
#define BT_VENDOR_OPEN_H

#include <stddef.h>

typedef struct {
    int (*transport_open)(void *config);
    int (*bridge_open)(void);
    void (*transport_close)(void);
} bt_vendor_open_ops_t;

int bt_vendor_open_channels(void *config,
                            int *fd_array,
                            size_t channel_count,
                            const bt_vendor_open_ops_t *ops);

#endif
