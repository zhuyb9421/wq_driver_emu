/******************************************************************************
 *
 *  Copyright (C) 2009-2018 WuQi Corporation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at:
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 ******************************************************************************/
#ifndef BTSERVICE_H
#define BTSERVICE_H

#include <stdio.h>
#include <cutils/log.h>

#define HCI_BT_AUTOPAIR_EVT 0x30

typedef struct bt_service_data
{
    uint16_t opcode;
    uint8_t parameter_len;
    uint8_t *parameter;
    void (*complete_cback)(void *);
} bt_service_data;

#endif
