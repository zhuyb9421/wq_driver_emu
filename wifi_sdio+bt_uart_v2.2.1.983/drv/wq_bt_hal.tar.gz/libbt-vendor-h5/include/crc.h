/****************************************************************************

Copyright(c) 2020 by WuQi Technologies. ALL RIGHTS RESERVED.

This Information is proprietary to WuQi Technologies and MAY NOT
be copied by any method or incorporated into another program without
the express written consent of WuQi. This Information or any portion
thereof remains the property of WuQi. The Information contained herein
is believed to be accurate and WuQi assumes no responsibility or
liability for its use in any way and conveys no license or title under
any patent or copyright and makes no representation or warranty that this
Information is free from patent or copyright infringement.

****************************************************************************/

#ifndef CRC_H
#define CRC_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

uint32_t getcrc32_update(uint32_t init_vect, uint8_t *buffer, uint32_t len);
uint32_t getcrc32(uint8_t *buffer, uint32_t len);
uint32_t getcrc24_update(uint32_t init_vect, uint8_t *buffer, uint32_t len);
uint32_t getcrc24(uint8_t *buffer, uint32_t len);
uint16_t getcrc16_update(uint16_t init_vect, uint8_t *buffer, uint32_t len);
uint16_t getcrc32_h16(uint8_t *buffer, uint32_t len);
uint16_t getcrc16(uint8_t *buffer, uint32_t len);
uint16_t getcrc16_ccitt_update(uint16_t init_vect, uint8_t *buffer,
                               uint32_t len);
uint16_t getcrc16_ccitt(uint8_t *buffer, uint32_t len);
uint8_t getcrc8_update(uint8_t init_vect, uint8_t *buffer, uint32_t len);
uint8_t getcrc8(uint8_t *buffer, uint32_t len);

#ifdef __cplusplus
}
#endif

#endif /* CRC_H */
