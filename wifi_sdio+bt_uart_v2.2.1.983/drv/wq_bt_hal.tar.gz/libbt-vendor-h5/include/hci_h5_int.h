/******************************************************************************
 *
 *  Copyright (C) 2022, WuQi Technologies. ALL RIGHTS RESERVED.
 *
 *  This Information is proprietary to WuQi Technologies and MAY NOT
 *  be copied by any method or incorporated into another program without
 *  the express written consent of WuQi. This Information or any portion
 *  thereof remains the property of WuQi. The Information contained herein
 *  is believed to be accurate and WuQi assumes no responsibility or
 *  liability for its use in any way and conveys no license or title under
 *  any patent or copyright and makes no representation or warranty that this
 *  Information is free from patent or copyright infringement.
 *
 ******************************************************************************/

#ifndef HCI_H5_INT_H
#define HCI_H5_INT_H

#pragma once

#include <stdbool.h>
#include <stdint.h>
#include "wq_hci_layer.h"
#include "bt_vendor_lib.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include "hcidefs.h"
#include "common.h"

// HCI Command opcodes
#define HCI_LE_READ_BUFFER_SIZE 0x2002
#define DATA_TYPE_H5 0x05

// HCI VENDOR Command opcode
#define HCI_VSC_H5_INIT 0xFCEE
#define HCI_READ_LMP_VERSION 0x1001

void ms_delay(uint32_t timeout);

typedef enum
{
    DATA_TYPE_COMMAND = 1,
    DATA_TYPE_ACL = 2,
    DATA_TYPE_SCO = 3,
    DATA_TYPE_EVENT = 4
} serial_data_type_t;

typedef struct hci_h5_callbacks_t
{
    uint16_t (*h5_int_transmit_data_cb)(serial_data_type_t type, uint8_t *data, uint16_t length);
    void (*h5_data_ready_cb)(serial_data_type_t type, unsigned int total_length);
} hci_h5_callbacks_t;

typedef struct hci_h5_t
{
    void (*h5_int_init)(hci_h5_callbacks_t *h5_callbacks);
    void (*h5_int_cleanup)(void);
    uint16_t (*h5_send_cmd)(serial_data_type_t type, uint8_t *data, uint16_t length);
    uint8_t (*h5_send_sync_cmd)(uint16_t opcode, uint8_t *data, uint16_t length);
    uint16_t (*h5_send_acl_data)(serial_data_type_t type, uint8_t *data, uint16_t length);
    uint16_t (*h5_send_sco_data)(serial_data_type_t type, uint8_t *data, uint16_t length);
    bool (*h5_recv_msg)(uint8_t *byte, uint16_t length);
    size_t (*h5_int_read_data)(uint8_t *data_buffer, size_t max_size);
} hci_h5_t;

const hci_h5_t *hci_get_h5_int_interface(void);

#endif
