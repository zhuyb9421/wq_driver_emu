#ifndef HCI_SOCKET_TRANSPORT_H
#define HCI_SOCKET_TRANSPORT_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <time.h>

typedef struct {
    int (*socket_fn)(int domain, int type, int protocol);
    int (*bind_fn)(int fd, const struct sockaddr *addr, socklen_t addr_len);
    int (*close_fn)(int fd);
    ssize_t (*write_fn)(int fd, const void *buffer, size_t length);
    int (*clock_gettime_fn)(clockid_t clock_id, struct timespec *time);
    int (*nanosleep_fn)(const struct timespec *duration,
                        struct timespec *remaining);
} hci_socket_transport_ops_t;

int hci_socket_transport_open(unsigned int dev_id,
                              unsigned int timeout_ms);
int hci_socket_transport_open_with_ops(
        unsigned int dev_id,
        unsigned int timeout_ms,
        const hci_socket_transport_ops_t *ops);
ssize_t hci_socket_transport_write_packet(int fd,
                                          const uint8_t *packet,
                                          size_t packet_length);
ssize_t hci_socket_transport_write_packet_with_ops(
        int fd,
        const uint8_t *packet,
        size_t packet_length,
        const hci_socket_transport_ops_t *ops);
bool hci_socket_transport_is_selected(uint8_t transtype);
bool hci_socket_transport_should_fallback(uint8_t transtype);

#endif
