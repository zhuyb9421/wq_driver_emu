/** @file os_linux_api.h
  *
  * @brief This file is for system opr api.
  *
  *  Copyright (C) 2022, WuQi Technologies. ALL RIGHTS RESERVED.
  *
  *  This Information is proprietary to WuQi Technologies and MAY NOT
  *  be copied by any method or incorporated into another program without
  *  the express written consent of WuQi. This Information or any portion
  *  thereof remains the property of WuQi. The Information contained herein
  *  is believed to be accurate and WuQi assumes no responsibility or
  *  liability for its use in any way and conveys no license or title under
  *  any patent or copyright and makes no representation or warranty that this
  *  Information is free from patent or copyright infringement.
  *
  */
#ifndef _OS_LINUS_API_H
#define _OS_LINUS_API_H
#include <pthread.h>

#if 0
typedef enum _bool
{
  false = 0,
  true = 1
}bool;
#endif

/* Macro to define a pthread tid */
#define OS_DEFINE_THREAD_ID(pid) pthread_t pid;

/* Macro to define a Mutex Variable */
#define OS_DEFINE_MUTEX(mutex) pthread_mutex_t mutex;

/* Macro to define a Mutex Variable with a type qualifier */
#define OS_DEFINE_MUTEX_TYPE(type, mutex) type pthread_mutex_t mutex;

/* Macro to define a Conditional Variable */
#define OS_DEFINE_COND(cond) pthread_cond_t cond;

/* Macro to define a Conditional Variable with a type qualifier */
#define OS_DEFINE_COND_TYPE(type, cond) type pthread_cond_t cond;

/* Macro to create a thread */
#define OS_THREAD_CREATE(pid, attr, start_routine, arg) pthread_create(pid, attr, start_routine, arg)

/* Macro to join a thread */
#define OS_THREAD_JOIN(pid, retval) pthread_join(pid, retval)

/*
 *  Macro to Initialize Mutex.
 */
#define OS_MUTEX_INIT_VOID(mutex) pthread_mutex_init(&(mutex), NULL)

/*
 *  Macro to Initialize Conditional Variable.
 */
#define OS_COND_INIT_VOID(cond) pthread_cond_init(&(cond), NULL)

/*
 *  Locks the Module Specific Mutex which prevents any global variable being
 *  overwritten by any function.
 */
#define OS_MUTEX_LOCK(mutex) pthread_mutex_lock(&(mutex))

/*
 *  Unlocks the Module Specific Mutex which realeses the global variables
 *  to be written into.
 */
#define OS_MUTEX_UNLOCK(mutex) pthread_mutex_unlock(&(mutex))

/*
 *  Macro to Signal Conditional Variable.
 */
#define OS_COND_SIGNAL(cond) pthread_cond_signal(&(cond))

/*
 *  Macro to Wait Conditional Variable and Mutex.
 */
#define OS_COND_WAIT(cond, mutex) pthread_cond_wait(&(cond), &(mutex))

/*
 *  Macro to Wait Conditional Variable and Mutex with timeout.
 */
#define OS_COND_TIMEDWAIT(cond, mutex, timeout) pthread_cond_timedwait(&(cond), &(mutex), &(timeout))

/*
 *  Macro to Destroy Mutex.
 */
#define OS_MUTEX_DESTROY_VOID(mutex) pthread_mutex_destroy(&(mutex))

/*
 *  Macro to Destroy Conditional Variable.
 */
#define OS_COND_DESTROY_VOID(cond) pthread_cond_destroy(&(cond))

#endif
