/******************************************************************************
 *
 *  Copyright (C) 2022, WuQi Technologies. ALL RIGHTS RESERVED.
 *
 *  This Information is proprietary to WuQi Technologies and MAY NOT
 *  be copied by any method or incorporated into another program without
 *  the express written consent of WuQi. This Information or any portion
 *  thereof remains the property of WuQi. The Information contained herein
 *  is believed to be accurate and WuQi assumes no responsibility or
 *  liability for its use in any way and conveys no license or title under
 *  any patent or copyright and makes no representation or warranty that this
 *  Information is free from patent or copyright infringement.
 *
 ******************************************************************************/

/******************************************************************************
 *
 *  Filename:      wq_hci_layer.h
 *
 *  Description:   HCI message ID definitions
 *
 ******************************************************************************/

#ifndef WQ_HCI_LAYER_H
#define WQ_HCI_LAYER_H

///// LEGACY DEFINITIONS /////

/* Message event mask across Host/Controller lib and stack */
#define MSG_EVT_MASK 0xFF00     /* eq. BT_EVT_MASK */
#define MSG_SUB_EVT_MASK 0x00FF /* eq. BT_SUB_EVT_MASK */

/* Message event ID passed from Host/Controller lib to stack */
#define MSG_HC_TO_STACK_HCI_ACL 0x1100      /* eq. BT_EVT_TO_BTU_HCI_ACL */
#define MSG_HC_TO_STACK_HCI_SCO 0x1200      /* eq. BT_EVT_TO_BTU_HCI_SCO */
#define MSG_HC_TO_STACK_HCI_ERR 0x1300      /* eq. BT_EVT_TO_BTU_HCIT_ERR */
#define MSG_HC_TO_STACK_HCI_ISO 0x1700      /* eq. BT_EVT_TO_BTU_HCI_ISO */
#define MSG_HC_TO_STACK_HCI_EVT 0x1000      /* eq. BT_EVT_TO_BTU_HCI_EVT */

/* Message event ID passed from stack to vendor lib */
#define MSG_STACK_TO_HC_HCI_ACL 0x2100 /* eq. BT_EVT_TO_LM_HCI_ACL */
#define MSG_STACK_TO_HC_HCI_SCO 0x2200 /* eq. BT_EVT_TO_LM_HCI_SCO */
#define MSG_STACK_TO_HC_HCI_ISO 0x2d00 /* eq. BT_EVT_TO_LM_HCI_ISO */
#define MSG_STACK_TO_HC_HCI_CMD 0x2000 /* eq. BT_EVT_TO_LM_HCI_CMD */

/* Local Bluetooth Controller ID for BR/EDR */
#define LOCAL_BR_EDR_CONTROLLER_ID 0

///// END LEGACY DEFINITIONS /////

#define BT_HC_HDR_SIZE (sizeof(HC_BT_HDR))

#endif