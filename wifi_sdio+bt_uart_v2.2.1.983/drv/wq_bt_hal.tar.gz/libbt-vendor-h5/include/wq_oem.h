/******************************************************************************
 *
 *  Copyright (C) 2009-2018 WuQi Corporation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at:
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 ******************************************************************************/

/******************************************************************************
 *
 *  Filename:      wq_oem.h
 *
 *  Description:   Contains definitions used for wq oem
 *
 ******************************************************************************/

#ifndef __WQ_OEM_H__
#define __WQ_OEM_H__

#include <stdint.h>

#define WQ_OEM_MAGIC 0x696F6D70
#define WQ_RESOURCE_MAGIC 0x51


#define WQ_RESOURCE_TYPE_BT 5
#define WQ_RESOURCE_TYPE_AUDIO 9

typedef struct{
    uint32_t magic;
    uint8_t version;
    uint8_t type_cnt;
    uint8_t reserved[2];
} wq_oem_hearder_t;

typedef struct  {
    uint8_t magic;
    uint8_t type;
    uint8_t length;
    uint8_t reserved;
    uint8_t data[];
}wq_resource_t;

typedef enum{
    HCI_H2,
    HCI_H4,
    HCI_H5,
    HCI_UNKNOWN
} hci_mode_t;

typedef struct {
    uint16_t hci_mode       : 2;
    uint16_t stb            : 1;
    uint16_t host_wakeup_bt : 1;
    uint16_t bt_wakeup_host : 1;
    uint16_t deep_sleep     : 1;
    uint16_t uart_hw_flow   : 1;
    uint16_t uart_parity_en : 1;
    uint16_t uart_parity_odd: 1;
    uint16_t reserved       : 7;
    uint32_t uart_baudrate;
} __attribute((packed)) wq_resource_bt_info_t;

typedef struct wq_resource_iis_cfg {
    uint8_t iis_mode_master  : 1;
    uint8_t iis_standard     : 2;
    uint8_t iis_data_format  : 2;
    uint8_t iis_pcm_mode     : 1;
    uint8_t reserved         : 2;
} wq_resource_iis_cfg_t;

typedef struct wq_resource_audio_cfg {
    uint8_t audio_path  : 1;
    uint8_t reserved    : 7;
} wq_resource_audio_cfg_t;

typedef struct wq_resource_audio {
    wq_resource_iis_cfg_t tx_cfg;
    wq_resource_iis_cfg_t rx_cfg;
    wq_resource_audio_cfg_t audio_cfg;
    uint8_t reserved;
} wq_resource_audio_t;

wq_resource_bt_info_t* wq_oem_get_bt_info(void);

wq_resource_audio_t* wq_oem_get_audio_config(void);

#endif