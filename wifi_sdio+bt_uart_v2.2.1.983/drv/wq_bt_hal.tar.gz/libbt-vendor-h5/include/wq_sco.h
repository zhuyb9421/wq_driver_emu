#ifndef __WQ_SCO__H__
#define __WQ_SCO__H__

void wq_sco_init(void);
void wq_sco_deinit(void);

void wq_sco_handle_event(unsigned char *recv_buffer, int length);
void wq_sco_recv_sco_data(unsigned char *recv_buffer, int length);
void wq_sco_handle_cmd(unsigned char *recv_buffer, int length);

#endif