LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

BVENDOR_DIR := $(TOP_DIR)hardware/interfaces/bluetooth/1.0/default/

LOCAL_SRC_FILES := \
        bt_socket.c \
        bt_transport_config.c \
        bt_vendor_open.c \
        bt_vendor_wuqi.c \
        hardware.c \
        hci_socket_transport.c \
        userial_vendor.c \
        bt_list.c \
        bt_skbuff.c \
        hci_h5.c \
        bt_parse.c \
        btservice.c \
        bt_heartbeat.c \
        bt_poll.c \
        btsnoop_net.c \
        ringbuffer.c \
        crc.c \
        bt_address.c \
        wq_oem.c \
        wq_sco.c \
        upio.c


ifeq ($(strip $(WQBT_HEARTBEAT_TIMEOUT_RESET)), true)
LOCAL_CFLAGS += -DBT_HEARTBEAT_TIMEOUT_RESET
endif

ifdef WQ_DEFAULT_BT_DEVICE_NODE
LOCAL_CFLAGS += -DDEFAULT_BT_DEVICE_NODE="\"$(WQ_DEFAULT_BT_DEVICE_NODE)\""
endif

ifdef WQ_BT_INI_PATH
LOCAL_CFLAGS += -DWQ_BT_INI_PATH="\"$(WQ_BT_INI_PATH)\""
endif

LOCAL_C_INCLUDES += \
        $(LOCAL_PATH)/../include \
        $(LOCAL_PATH)/../codec/msbc \
        $(LOCAL_PATH)/../codec/plc \
        $(LOCAL_PATH)/../codec/cvsd/inc \
        $(BVENDOR_DIR)

LOCAL_SHARED_LIBRARIES := \
        libcutils \
        libutils \
        liblog

LOCAL_WHOLE_STATIC_LIBRARIES := \
        libwq-bt-codec

LOCAL_MODULE := libbt-vendor-wuqi
LOCAL_MODULE_TAGS := optional
LOCAL_PROPRIETARY_MODULE := true
LOCAL_MODULE_CLASS := SHARED_LIBRARIES

include $(BUILD_SHARED_LIBRARY)
