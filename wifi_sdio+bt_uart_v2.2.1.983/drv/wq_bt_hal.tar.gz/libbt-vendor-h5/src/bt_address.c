/**
 * @brief bt_address.c
 * @brief This file is for bt address.
 *
 *  Copyright (C) 2021, WuQi Technologies. ALL RIGHTS RESERVED.
 *
 *  This Information is proprietary to WuQi Technologies and MAY NOT
 *  be copied by any method or incorporated into another program without
 *  the express written consent of WuQi. This Information or any portion
 *  thereof remains the property of WuQi. The Information contained herein
 *  is believed to be accurate and WuQi assumes no responsibility or
 *  liability for its use in any way and conveys no license or title under
 *  any patent or copyright and makes no representation or warranty that this
 *  Information is free from patent or copyright infringement.
 *
 */
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <utils/Log.h>
#include "bt_address.h"

bt_addr_t local_bd_addr;
char invalid_addr[BT_ADDR_SIZE * 3 + 1] = "00:00:00:00:00:00";
char default_addr[BT_ADDR_SIZE * 3 + 1] = "34:77:33:99:11:45";

void bytes_to_string(const uint8_t *addr, char *addr_str)
{
    sprintf(addr_str, "%02x:%02x:%02x:%02x:%02x:%02x", addr[0], addr[1], addr[2],
            addr[3], addr[4], addr[5]);
}

bool string_to_bytes(const char *addr_str, uint8_t *addr)
{
    if (addr_str == NULL)
        return false;
    if (strnlen(addr_str, kStringLength) != kStringLength)
        return false;
    unsigned char trailing_char = '\0';

    return (sscanf(addr_str, "%02hhx:%02hhx:%02hhx:%02hhx:%02hhx:%02hhx%1c",
                   &addr[0], &addr[1], &addr[2], &addr[3], &addr[4], &addr[5],
                   &trailing_char) == kBytes);
}

bool analysis_bt_address(uint8_t *local_addr)
{
    char property[PROPERTY_VALUE_MAX] = {0};
    char str_addr[BT_ADDR_SIZE * 3 + 1] = {0};
    bool valid_bda = false;
    bool bset_to_chip = false;

    if (local_addr == NULL)
    {
        ALOGE("local_addr null:");
        return bset_to_chip;
    }

    bytes_to_string(local_addr, str_addr);
    ALOGE("bt_str_addr %s:", str_addr);

    if ((strcmp(invalid_addr, str_addr) == 0) || (strcmp(default_addr, str_addr) == 0))
    {
        valid_bda = false;
    }
    else
    {
        valid_bda = true;
    }

    ALOGE("%s: Trying %s %d", __func__, property, valid_bda);

    // Look for a previously stored BDA.
    if (!valid_bda && property_get(PERSIST_BDADDR_PROPERTY, property, NULL) &&
        string_to_bytes(property, local_addr))
    {
        valid_bda = true;
        bset_to_chip = true;
    }

    /* Generate new BDA if necessary */
    if (!valid_bda)
    {
        char bdstr[kStringLength + 1];
        srand(time(0)+rand());
        /* No autogen BDA. Generate one now. */
        local_addr[0] = (uint8_t)rand();
        local_addr[1] = (uint8_t)rand();
        local_addr[2] = (uint8_t)rand();
        local_addr[3] = (uint8_t)rand();
        local_addr[4] = (uint8_t)rand();
        local_addr[5] = (uint8_t)rand();

        /* Convert to ascii, and store as a persistent property */
        bytes_to_string(local_addr, bdstr);
        bset_to_chip = true;

        ALOGE("%s: No preset BDA! Generating BDA: %s for prop %s", __func__,
              (char *)bdstr, PERSIST_BDADDR_PROPERTY);
    }

    return bset_to_chip;
}
