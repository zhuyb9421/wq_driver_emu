/******************************************************************************
 *
 *  Copyright (C) 2009-2018 WuQi Corporation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at:
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 ******************************************************************************/
#define LOG_TAG "bt_heartbeat"

#include <utils/Log.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <inttypes.h>
#include <termios.h>
#include <sys/syscall.h>
#include <time.h>
#include <errno.h>
#include <fcntl.h>
#include <dirent.h>
#include <ctype.h>
#include <cutils/properties.h>
#include <stdlib.h>
#include "wq_hci_layer.h"
#include "bt_vendor_wuqi.h"
#include "userial_vendor.h"
#include "btservice.h"
#include "bt_poll.h"
#include <unistd.h>
#include <sys/eventfd.h>
#include <semaphore.h>
#include <endian.h>
#include <byteswap.h>
#include <sys/un.h>
#include <stddef.h>
#include <sys/socket.h>
#include <sys/types.h>

#include "bt_vendor_lib.h"

#define HCI_EVT_HEARTBEAT_STATUS_OFFSET   (5)
#define HCI_EVT_HEARTBEAT_RUN_TIME_OFFSET (6)

static const uint32_t DEFALUT_HEARTBEAT_TIMEOUT_MS = 1000;   // send a per sercond
int heartBeatLog = -1;
static int heartBeatTimeout = -1;
static bool heartbeatFlag = false;
static int heartbeatCount = 0;
static uint16_t cleanupFlag = 0;
static pthread_mutex_t heartbeat_mutex;
static uint32_t last_runtime = 0;

extern void bt_service_vendorcmd_hook(bt_service_data *btData, int client_sock);
extern uint8_t get_heartbeat_from_hardware();

#ifdef BT_HEARTBEAT_TIMEOUT_RESET
static void bt_heartbeat_send_hw_error(uint8_t status, uint16_t arg1, uint16_t arg2,
                                       int heartbeatCnt)
{
    if (!heartbeatFlag)
        return;

    unsigned char p_buf[100];
    int length;
    p_buf[0] = HCIT_TYPE_EVENT;                      // event
    p_buf[1] = HCI_VSE_SUBCODE_DEBUG_INFO_SUB_EVT;   // firmwre event log
    p_buf[3] = 0x01;                                 // host log opcode
    length = sprintf((char *)&p_buf[4], "host stack: heartbeat hw error: %d:%d:%d:%d \n", status,
                     arg1, arg2, heartbeatCnt);
    p_buf[2] = length + 2;   // len
    length = length + 1 + 4;
    userial_recv_rawdata_hook(p_buf, length);

    length = 4;
    p_buf[0] = HCIT_TYPE_EVENT;          // event
    p_buf[1] = HCI_HARDWARE_ERROR_EVT;   // hardware error
    p_buf[2] = 0x01;                     // len
    p_buf[3] = HEARTBEAT_HWERR_CODE;     // heartbeat error code
    userial_recv_rawdata_hook(p_buf, length);
}
#endif

static void bt_heartbeat_cmpl_cback(void *p_params)
{
    uint8_t status = 0;
    uint32_t run_time = 0;
    HC_BT_HDR *p_evt_buf = NULL;

    if (!heartbeatFlag) {
        return;
    }

    if (p_params != NULL) {
        p_evt_buf = (HC_BT_HDR *)p_params;
        status = p_evt_buf->data[HCI_EVT_HEARTBEAT_STATUS_OFFSET];
        if (p_evt_buf->len == HCI_EVT_HEARTBEAT_RUN_TIME_OFFSET + sizeof(uint32_t)) {
            memcpy(&run_time, &p_evt_buf->data[HCI_EVT_HEARTBEAT_RUN_TIME_OFFSET],
                   sizeof(uint32_t));
        }
    }

    //ALOGW("heart status:%d len:%d run_time:%uld",status,p_evt_buf->len,run_time);
    if (status == 0) {
        pthread_mutex_lock(&heartbeat_mutex);
        heartbeatCount = 0;
        pthread_mutex_unlock(&heartbeat_mutex);

        if (run_time != 0) {
            uint32_t diff = run_time - last_runtime;
            if (last_runtime != 0 && diff >= 5000) {
                ALOGE("heartbeat timed out %uld %uld", last_runtime, run_time);
#ifdef BT_HEARTBEAT_TIMEOUT_RESET
                if (cleanupFlag == 1) {
                    ALOGW("Already cleanup, ignore.");
                    return;
                }
                ALOGE(
                    "heartbeat_timed_out,controller may be suspend! Now restart bluedroid stack\n");
                usleep(1000);
                bt_heartbeat_send_hw_error(0, 0, run_time, diff);
                //kill(getpid(), SIGKILL);
                return;
#endif
            }
            last_runtime = run_time;
        }
    }
}

static void heartbeat_timed_out()   //(union sigval arg)
{
    if (!heartbeatFlag) {
        return;
    }

    pthread_mutex_lock(&heartbeat_mutex);
    heartbeatCount++;
    pthread_mutex_unlock(&heartbeat_mutex);

#ifdef BT_HEARTBEAT_TIMEOUT_RESET
    if (heartbeatCount > 1) {
        ALOGE("heartbeat_timed_out: heartbeatCount=%d", heartbeatCount);
    }

    if (heartbeatCount >= 3) {
        if (cleanupFlag == 1) {
            ALOGW("Already cleanup, ignore.");
            return;
        }
        ALOGE("heartbeat_timed_out,controller may be suspend! Now restart bluedroid stack\n");
        usleep(1000);
        bt_heartbeat_send_hw_error(0, 0, 0, heartbeatCount);
        //kill(getpid(), SIGKILL);
        return;
    }
#endif

    bt_service_data *p_buf = (bt_service_data *)malloc(sizeof(bt_service_data));
    if (NULL == p_buf) {
        ALOGE("p_buf: allocate error");
        return;
    }
    p_buf->opcode = HCI_CMD_VNDR_HEARTBEAT;
    p_buf->parameter = NULL;
    p_buf->parameter_len = 0;
    p_buf->complete_cback = bt_heartbeat_cmpl_cback;

    bt_service_vendorcmd_hook(p_buf, -1);
    free(p_buf);
    poll_timer_flush();
}

static void bt_heartbeat_beginTimer_func(void)
{
    bt_service_data *p_buf;

    if ((heartBeatTimeout != -1) && (heartBeatLog != -1)) {
        poll_init(heartbeat_timed_out, heartBeatTimeout);
    } else {
        heartBeatLog = 0;
        poll_init(heartbeat_timed_out, DEFALUT_HEARTBEAT_TIMEOUT_MS);
    }
    poll_enable(TRUE);

    p_buf = (bt_service_data *)malloc(sizeof(bt_service_data));
    if (NULL == p_buf) {
        ALOGE("p_buf: allocate error");
        return;
    }
    p_buf->opcode = HCI_CMD_VNDR_HEARTBEAT;
    p_buf->parameter = NULL;
    p_buf->parameter_len = 0;
    p_buf->complete_cback = bt_heartbeat_cmpl_cback;

    bt_service_vendorcmd_hook(p_buf, -1);
    free(p_buf);

    poll_timer_flush();
}

void Heartbeat_cleanup()
{
    if (!heartbeatFlag) {
        return;
    }

    heartbeatFlag = false;
    heartbeatCount = 0;
    last_runtime = 0;
    cleanupFlag = 1;
    poll_enable(FALSE);
    poll_cleanup();
}

void Heartbeat_init()
{
    int res;
    ALOGD("Heartbeat_init start");
    Heartbeat_cleanup();
    pthread_mutex_init(&heartbeat_mutex, NULL);
    heartbeatFlag = true;
    heartbeatCount = 0;
    last_runtime = 0;
    cleanupFlag = 0;
    res = get_heartbeat_from_hardware();
    ALOGD("Heartbeat_init res = %x", res);
    if (res == 1) {
        bt_heartbeat_beginTimer_func();
    } else {
        Heartbeat_cleanup();
    }
    ALOGD("Heartbeat_init end");
}
