/******************************************************************************
 *
 *  Copyright (C) 2009-2018 WuQi Corporation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at:
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 ******************************************************************************/

/******************************************************************************
 *
 *	Module Name:
 *		bt_parse.c
 *
 *	Abstract:
 *		Contains wifi-bt coex functions implemented by bluedroid stack
 *
 *	Major Change History:
 *	      When             Who       What
 *	 	---------------------------------------------------------------
 *	    2015-12-15      lamparten   modified
 *	    2014-10-23       kyle_xu    modified
 *	Notes:
 *		  This is designed for wifi-bt Coex in Android 6.0.
 *
 ******************************************************************************/
#define LOG_TAG "bt_parse"

#include <utils/Log.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <termios.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <math.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <sys/un.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/prctl.h>
#include <linux/types.h>
#include <linux/netlink.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <dirent.h>
#include <signal.h>
#include <poll.h>

#include "bt_list.h"
#include "wq_hci_layer.h"
#include "bt_parse.h"
#include <sys/syscall.h>

// #define BT_ROLE_SWITCH_RETRY
extern bool bt_capture_fw_log;

bool is_fw_log = FALSE;

#define MAX_PAYLOAD 255 /* maximum payload size*/

#define HCI_CMD_PREAMBLE_SIZE 3

typedef struct BT_COEX_INFO
{
    RT_LIST_ENTRY list;
    HC_BT_HDR *p_buf;
    uint16_t opcode;
    tINT_CMD_CBACK p_cback;
} tBT_COEX_INFO;

// profile info for all
typedef struct BT_PROF
{
    RT_LIST_HEAD coex_list;
    tINT_CMD_CBACK current_cback;
    pthread_mutex_t coex_mutex;
    uint8_t bt_on;
} tBT_PROF;

tBT_PROF bt_prof;
uint8_t coex_log_enable = 0;
static volatile bool coex_cmd_send = false;

#ifndef BT_PARSE_LOG_BUF_SIZE
#define BT_PARSE_LOG_BUF_SIZE 1024
#endif
#define BT_PARSE_LOG_MAX_SIZE (BT_PARSE_LOG_BUF_SIZE - 12)

#define LOGI0(t, s) __android_log_write(ANDROID_LOG_INFO, t, s)

static void btLogMsg(const char *fmt_str, ...)
{
    static char buffer[BT_PARSE_LOG_BUF_SIZE];
    if (coex_log_enable)
    {
        va_list ap;
        va_start(ap, fmt_str);
        vsnprintf(&buffer[0], BT_PARSE_LOG_MAX_SIZE, fmt_str, ap);
        va_end(ap);

        LOGI0("bt_parse: ", buffer);
    }
    else
    {
        return;
    }
}

void init_coex_hash(tBT_PROF *h5)
{
    RT_LIST_HEAD *head = &h5->coex_list;
    ListInitializeHeader(head);
}

void delete_coex_from_hash(tBT_COEX_INFO *desc)
{
    if (desc)
    {
        ListDeleteNode(&desc->list);
        free(desc);
        desc = NULL;
    }
}

void flush_coex_hash(tBT_PROF *h5)
{
    RT_LIST_HEAD *head = &h5->coex_list;
    RT_LIST_ENTRY *iter = NULL, *temp = NULL;
    tBT_COEX_INFO *desc = NULL;

    pthread_mutex_lock(&bt_prof.coex_mutex);
    LIST_FOR_EACH_SAFELY(iter, temp, head)
    {
        desc = LIST_ENTRY(iter, tBT_COEX_INFO, list);
        delete_coex_from_hash(desc);
    }
    // ListInitializeHeader(head);
    pthread_mutex_unlock(&bt_prof.coex_mutex);
}

static void bt_cmd_complete_cback(void *p_mem)
{
    pthread_mutex_lock(&bt_prof.coex_mutex);
    RT_LIST_ENTRY *iter = ListGetTop(&(bt_prof.coex_list));
    tBT_COEX_INFO *desc = NULL;
    if (iter)
    {
        desc = LIST_ENTRY(iter, tBT_COEX_INFO, list);
        if (desc)
        {
            ListDeleteNode(&desc->list);
        }
    }
    else
    {
        coex_cmd_send = false;
    }
    pthread_mutex_unlock(&bt_prof.coex_mutex);

    if (bt_prof.current_cback)
    {
        bt_prof.current_cback(p_mem);
        bt_prof.current_cback = NULL;
    }

    if (p_mem)
        bt_vendor_cbacks->dealloc(p_mem);

    if (desc)
    {
        pthread_mutex_lock(&bt_prof.coex_mutex);
        if (bt_prof.bt_on)
        {
            btLogMsg("%s, transmit_command Opcode:%x", __func__, desc->opcode);
            bt_prof.current_cback = desc->p_cback;
            bt_vendor_cbacks->xmit_cb(desc->opcode, desc->p_buf, bt_cmd_complete_cback);
        }
        pthread_mutex_unlock(&bt_prof.coex_mutex);
    }

    free(desc);
    return;
}

void bt_vendor_cmd_to_fw(uint16_t opcode, uint8_t parameter_len, uint8_t *parameter, tINT_CMD_CBACK p_cback)
{
    HC_BT_HDR *p_buf = NULL;

    if (!bt_prof.bt_on)
        return;

    if (bt_vendor_cbacks)
        p_buf = (HC_BT_HDR *)bt_vendor_cbacks->alloc(BT_HC_HDR_SIZE + HCI_CMD_PREAMBLE_SIZE + parameter_len);

    if (NULL == p_buf)
    {
        ALOGE("bt_vendor_cmd_to_fw: HC_BT_HDR alloc error");
        return;
    }
    memset(p_buf, 0, (BT_HC_HDR_SIZE + HCI_CMD_PREAMBLE_SIZE + parameter_len));
    p_buf->event = MSG_STACK_TO_HC_HCI_CMD;
    p_buf->offset = 0;
    p_buf->len = HCI_CMD_PREAMBLE_SIZE + parameter_len;
    p_buf->layer_specific = 0;

    uint8_t *p = (uint8_t *)(p_buf + 1);
    UINT16_TO_STREAM(p, opcode);
    *p++ = parameter_len;
    btLogMsg("bt_vendor_cmd_to_fw: Opcode:%x, parameter_len = %d", opcode, parameter_len);

    if (parameter_len > 0)
    {
        memcpy(p, parameter, parameter_len);
    }
    if (bt_vendor_cbacks)
    {
        pthread_mutex_lock(&bt_prof.coex_mutex);
        if (!bt_prof.bt_on)
        {
            pthread_mutex_unlock(&bt_prof.coex_mutex);
            return;
        }
        if (!coex_cmd_send)
        {
            coex_cmd_send = true;
            btLogMsg("begin transmit_command Opcode:%x", opcode);
            pthread_mutex_unlock(&bt_prof.coex_mutex);
            bt_prof.current_cback = p_cback;
            bt_vendor_cbacks->xmit_cb(opcode, p_buf, bt_cmd_complete_cback);
        }
        else
        {
            tBT_COEX_INFO *pcoex_info = NULL;
            pcoex_info = malloc(sizeof(tBT_COEX_INFO));
            if (NULL == pcoex_info)
            {
                ALOGE("bt_vendor_cmd_to_fw: allocate error");
                pthread_mutex_unlock(&bt_prof.coex_mutex);
                return;
            }

            pcoex_info->p_buf = p_buf;
            pcoex_info->opcode = opcode;
            pcoex_info->p_cback = p_cback;

            ListAddToTail(&(pcoex_info->list), &(bt_prof.coex_list));
            pthread_mutex_unlock(&bt_prof.coex_mutex);
        }
    }
    return;
}

void bt_parse_init(void)
{
    memset(&bt_prof, 0, sizeof(bt_prof));
    pthread_mutex_init(&bt_prof.coex_mutex, NULL);
    init_coex_hash(&bt_prof);
}

void bt_parse_cleanup()
{
    btLogMsg("bt_profile_cleanup");
    flush_coex_hash(&bt_prof);
    pthread_mutex_destroy(&bt_prof.coex_mutex);
    memset(&bt_prof, 0, sizeof(bt_prof));
}

void bt_parse_internal_event_intercept(uint8_t *p_msg)
{
    // ALOGE("in bt_parse_internal_event_intercept, *p= %x", *p);
    uint8_t *p = p_msg;
    uint8_t event_code = *p++;
    uint16_t opcode;
    uint8_t status, num_hci_cmd_pkts;

    switch (event_code)
    {
    case HCI_COMMAND_STATUS_EVT:
    {
        status = *p++;
        num_hci_cmd_pkts = *p++;
        STREAM_TO_UINT16(opcode, p);
        break;
    }
    default:
        break;
    }
}

void bt_set_bt_on(uint8_t bt_on)
{
    btLogMsg("bt_set_bt_on bt_on:%d", bt_on);

    pthread_mutex_lock(&bt_prof.coex_mutex);
    bt_prof.bt_on = bt_on;
    pthread_mutex_unlock(&bt_prof.coex_mutex);
}

static bt_parse_manager_t parse_interface = {
    bt_parse_internal_event_intercept,
    bt_parse_init,
    bt_parse_cleanup,
    bt_set_bt_on,
};

bt_parse_manager_t *bt_parse_manager_get_interface()
{
    return &parse_interface;
}
