/******************************************************************************
 *
 *  Copyright (C) 2009-2018 WuQi Corporation.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at:
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 ******************************************************************************/
/******************************************************************************
 *
 *	Module Name:
 *	    bt_skbuff.c
 *
 *	Abstract:
 *	    Data buffer managerment through whole bluetooth stack.
 *
 *	Major Change History:
 *	      When             Who       What
 *	    --------------------------------------------------------------
 *	    2010-06-11       W.Bi    Created.
 *
 *	Notes:
 *		  To reduce memory copy when pass data buffer to other layers,
 *      	BT_BUFFER is designed referring to linux socket buffer.
 *       But I still wonder its effect, since BT_BUFFER is much bigger
 *       than original data buffer.BT_BUFFER will reduce its member if
 *       it would not reach what i had expected.
 *
 ******************************************************************************/

#define LOG_TAG "bt_h5"
#undef NDEBUG
#include <utils/Log.h>
#include <stdlib.h>
#include <fcntl.h>

#include <termios.h>
#include <errno.h>
#include <pthread.h>

#include "bt_list.h"
#include "bt_skbuff.h"
#include "string.h"
#include "hci_h5_int.h"
#define IN
#define OUT

//****************************************************************************
// CONSTANT DEFINITION
//****************************************************************************
/// default header size
/// l2cap header(8)+hci acl(4)
#define DEFAULT_HEADER_SIZE (8 + 4)

// BT_BUFFER data buffer alignment
#define RTB_ALIGN 4

// do alignment with RTB_ALIGN
#define RTB_DATA_ALIGN(_Length) ((_Length + (RTB_ALIGN - 1)) & (~(RTB_ALIGN - 1)))

//****************************************************************************
// STRUCTURE DEFINITION
//****************************************************************************
typedef struct _RTB_QUEUE_HEAD
{
    RT_LIST_HEAD List;
    uint32_t QueueLen;
    pthread_mutex_t Lock;
    uint8_t Id[RTB_QUEUE_ID_LENGTH];
} *PRTB_QUEUE_HEAD;

//****************************************************************************
// FUNCTION
//****************************************************************************
/**
    check whether queue is empty
    \return :   FALSE   Queue is not empty
        TRU Queue is empty
*/
bool RtbQueueIsEmpty(
    IN RTB_QUEUE_HEAD *btQueueHead)
{
    // return ListIsEmpty(&btQueueHead->List);
    return btQueueHead->QueueLen > 0 ? false : true;
}

/**
    Allocate a BT_BUFFER with specified data length and reserved headroom.
    If caller does not know actual headroom to reserve for further usage, specify it to zero to use default value.
    \param [IN]     Length            <uint32_t>        : current data buffer length to allcated
    \param [IN]     HeadRoom     <uint32_t>         : if caller knows reserved head space, set it; otherwise set 0 to use default value
    \return pointer to BT_BUFFER if succeed, null otherwise
*/
BT_BUFFER *
RtbAllocate(
    uint32_t Length,
    uint32_t HeadRoom)
{
    BT_BUFFER *Rtb = NULL;
    /// Rtb buffer length:
    ///      BT_BUFFER   48
    ///      HeadRoom      HeadRomm or 12
    ///      Length
    /// memory size: 48 + Length + 12(default) + 8*2(header for each memory) ---> a multiple of 8
    /// example:       (48 + 8)+ (300 + 12 + 8) = 372
    Rtb = malloc(sizeof(BT_BUFFER));
    if (Rtb)
    {
        uint32_t BufferLen = HeadRoom ? (Length + HeadRoom) : (Length + DEFAULT_HEADER_SIZE);
        BufferLen = RTB_DATA_ALIGN(BufferLen);
        Rtb->Head = malloc(BufferLen);
        if (Rtb->Head)
        {
            Rtb->HeadRoom = HeadRoom ? HeadRoom : DEFAULT_HEADER_SIZE;
            Rtb->Data = Rtb->Head + Rtb->HeadRoom;
            Rtb->End = Rtb->Data;
            Rtb->Tail = Rtb->End + Length;
            Rtb->Length = 0;
            ListInitializeHeader(&Rtb->List);
            Rtb->RefCount = 1;
            return Rtb;
        }
    }

    if (Rtb)
    {
        if (Rtb->Head)
        {
            free(Rtb->Head);
        }

        free(Rtb);
    }
    return NULL;
}

/**
    Free specified bt_buffer
    \param [IN]     btBuffer            <BT_BUFFER*>        : buffer to free
*/
void RtbFree(
    BT_BUFFER *btBuffer)
{
    if (btBuffer)
    {
        free(btBuffer->Head);
        free(btBuffer);
    }
    return;
}

/**
    Add a specified length protocal header to the start of data buffer hold by specified bt_buffer.
    This function extends used data area of the buffer at the buffer start.
    \param [IN OUT]     btBuffer            <BT_BUFFER*>        : data buffer to add
    \param [IN]            Length                <uint32_t>                 : header length
    \return  Pointer to the first byte of the extra data is returned
*/
uint8_t *
RtbAddHead(
    BT_BUFFER *btBuffer,
    uint32_t Length)
{

    if ((uint32_t)(btBuffer->Data - btBuffer->Head) >= Length)
    {
        btBuffer->Data -= Length;
        btBuffer->Length += Length;
        btBuffer->HeadRoom -= Length;
        return btBuffer->Data;
    }

    return NULL;
}
/**
    Remove a specified length data from the start of data buffer hold by specified bt_buffer.
    This function returns the memory to the headroom.
    \param [IN OUT]     btBuffer            <BT_BUFFER*>        : data buffer to remove
    \param [IN]            Length                <uint32_t>                 : header length
    \return  Pointer to the next data in the buffer is returned, usually useless
*/
unsigned char
RtbRemoveHead(
    BT_BUFFER *btBuffer,
    uint32_t Length)
{

    if (btBuffer->Length >= Length)
    {
        btBuffer->Data += Length;
        btBuffer->Length -= Length;
        btBuffer->HeadRoom += Length;
        return true;
    }

    return false;
}

/**
    Add a specified length protocal header to the end of data buffer hold by specified bt_buffer.
    This function extends used data area of the buffer at the buffer end.
    \param [IN OUT]     btBuffer            <BT_BUFFER*>        : data buffer to add
    \param [IN]            Length                <uint32_t>                 : header length
    \return  Pointer to the first byte of the extra data is returned
*/
uint8_t *
RtbAddTail(
    BT_BUFFER *btBuffer,
    uint32_t Length)
{

    if ((uint32_t)(btBuffer->Tail - btBuffer->End) >= Length)
    {
        uint8_t *Tmp = btBuffer->End;
        btBuffer->End += Length;
        btBuffer->Length += Length;
        return Tmp;
    }

    return NULL;
}

unsigned char
RtbRemoveTail(
    IN OUT BT_BUFFER *btBuffer,
    IN uint32_t Length)
{

    if ((uint32_t)(btBuffer->End - btBuffer->Data) >= Length)
    {
        btBuffer->End -= Length;
        btBuffer->Length -= Length;
        return true;
    }

    return false;
}
//****************************************************************************
// RTB list manipulation
//****************************************************************************
/**
    Initialize a rtb queue.
    \return  Initilized rtb queue if succeed, otherwise NULL
*/
RTB_QUEUE_HEAD *
RtbQueueInit()
{
    RTB_QUEUE_HEAD *RtbQueue = NULL;
    int ret = 0;
    RtbQueue = malloc(sizeof(RTB_QUEUE_HEAD));
    if (RtbQueue)
    {
        ret = pthread_mutex_init(&RtbQueue->Lock, NULL);
        if (!ret)
        {
            ListInitializeHeader(&RtbQueue->List);
            RtbQueue->QueueLen = 0;
            return RtbQueue;
        }
    }

    // error code comes here
    if (RtbQueue)
    {
        free(RtbQueue);
    }
    return NULL;
}

/**
    Free a rtb queue.
    \param [IN]     btQueueHead        <RTB_QUEUE_HEAD*>        : bt Queue
*/
void RtbQueueFree(
    RTB_QUEUE_HEAD *btQueueHead)
{
    if (btQueueHead)
    {

        RtbEmptyQueue(btQueueHead);
        pthread_mutex_destroy(&btQueueHead->Lock);
        free(btQueueHead);
    }
}

/**
    Queue specified btBuffer into a btQueue at list tail.
    \param [IN OUT]     btQueueHead        <RTB_QUEUE_HEAD*>        : bt Queue
    \param [IN]            btBuffer                <BT_BUFFER*>                 : bt buffer to add
*/
void RtbQueueTail(
    IN OUT RTB_QUEUE_HEAD *btQueueHead,
    IN BT_BUFFER *btBuffer)
{
    pthread_mutex_lock(&btQueueHead->Lock);
    ListAddToTail(&btBuffer->List, &btQueueHead->List);
    btQueueHead->QueueLen++;
    pthread_mutex_unlock(&btQueueHead->Lock);
}

/**
    Queue specified btBuffer into a btQueue at list Head.
    \param [IN OUT]     btQueueHead        <RTB_QUEUE_HEAD*>        : bt Queue
    \param [IN]            btBuffer                <BT_BUFFER*>                 : bt buffer to add
*/
void RtbQueueHead(
    IN OUT RTB_QUEUE_HEAD *btQueueHead,
    IN BT_BUFFER *btBuffer)
{
    pthread_mutex_lock(&btQueueHead->Lock);
    ListAddToHead(&btBuffer->List, &btQueueHead->List);
    btQueueHead->QueueLen++;
    pthread_mutex_unlock(&btQueueHead->Lock);
}

/**
    Insert new btbuffer in the old buffer
    \param [IN OUT]     btQueueHead        <RTB_QUEUE_HEAD*>        : bt Queue
    \param [IN]            OldBuffer                <BT_BUFFER*>                 : old bt buffer
    \param [IN]            NewBuffer                <BT_BUFFER*>                 : bt buffer to add
*/
void RtbInsertBefore(
    IN OUT RTB_QUEUE_HEAD *btQueueHead,
    IN BT_BUFFER *pOldBuffer,
    IN BT_BUFFER *pNewBuffer)
{
    pthread_mutex_lock(&btQueueHead->Lock);
    ListAdd(&pNewBuffer->List, pOldBuffer->List.Prev, &pOldBuffer->List);
    btQueueHead->QueueLen++;
    pthread_mutex_unlock(&btQueueHead->Lock);
}

/**
    check whether the buffer is the last node in the queue
*/
unsigned char
RtbNodeIsLast(
    IN RTB_QUEUE_HEAD *btQueueHead,
    IN BT_BUFFER *pBuffer)
{
    BT_BUFFER *pBuf;
    pthread_mutex_lock(&btQueueHead->Lock);

    pBuf = (BT_BUFFER *)btQueueHead->List.Prev;
    if (pBuf == pBuffer)
    {
        pthread_mutex_unlock(&btQueueHead->Lock);
        return true;
    }
    pthread_mutex_unlock(&btQueueHead->Lock);
    return false;
}

/**
    get the next buffer node after the specified buffer in the queue
    if the specified buffer is the last node in the queue , return NULL
    \param [IN]     btBuffer        <BT_BUFFER*>        : bt Queue
    \param [IN]     btBuffer        <BT_BUFFER*>        : bt buffer
    \return node after the specified buffer
*/
BT_BUFFER *
RtbQueueNextNode(
    IN RTB_QUEUE_HEAD *btQueueHead,
    IN BT_BUFFER *pBuffer)
{
    BT_BUFFER *pBuf;
    pthread_mutex_lock(&btQueueHead->Lock);
    pBuf = (BT_BUFFER *)btQueueHead->List.Prev;
    if (pBuf == pBuffer)
    {
        pthread_mutex_unlock(&btQueueHead->Lock);
        return NULL; ///< if it is already the last node in the queue , return NULL
    }
    pBuf = (BT_BUFFER *)pBuffer->List.Next;
    pthread_mutex_unlock(&btQueueHead->Lock);
    return pBuf; ///< return next node after this node
}

/**
    Delete specified btBuffer from a btQueue.
    It don't hold spinlock itself, so caller must hold it at someplace.
    \param [IN OUT]     btQueueHead        <RTB_QUEUE_HEAD*>        : bt Queue
    \param [IN]            btBuffer                <BT_BUFFER*>                 : bt buffer to Remove
*/
void RtbRemoveNode(
    IN OUT RTB_QUEUE_HEAD *btQueueHead,
    IN BT_BUFFER *btBuffer)
{
    btQueueHead->QueueLen--;
    ListDeleteNode(&btBuffer->List);
}

/**
    Get the btBuffer which is the head of a btQueue
    \param [IN OUT]     btQueueHead        <RTB_QUEUE_HEAD*>        : bt Queue
    \return head of the btQueue , otherwise NULL
*/
BT_BUFFER *
RtbTopQueue(
    IN RTB_QUEUE_HEAD *btQueueHead)
{
    BT_BUFFER *Rtb = NULL;
    pthread_mutex_lock(&btQueueHead->Lock);

    if (RtbQueueIsEmpty(btQueueHead))
    {
        pthread_mutex_unlock(&btQueueHead->Lock);
        return NULL;
    }

    Rtb = (BT_BUFFER *)btQueueHead->List.Next;
    pthread_mutex_unlock(&btQueueHead->Lock);

    return Rtb;
}

/**
    Remove a btBuffer from specified btqueue at list tail.
    \param [IN OUT]     btQueueHead        <RTB_QUEUE_HEAD*>        : bt Queue
    \return    removed btbuffer if succeed, otherwise NULL
*/
BT_BUFFER *
RtbDequeueTail(
    IN OUT RTB_QUEUE_HEAD *btQueueHead)
{
    BT_BUFFER *Rtb = NULL;

    pthread_mutex_lock(&btQueueHead->Lock);
    if (RtbQueueIsEmpty(btQueueHead))
    {
        pthread_mutex_unlock(&btQueueHead->Lock);
        return NULL;
    }
    Rtb = (BT_BUFFER *)btQueueHead->List.Prev;
    RtbRemoveNode(btQueueHead, Rtb);
    pthread_mutex_unlock(&btQueueHead->Lock);

    return Rtb;
}

/**
    Remove a btBuffer from specified btqueue at list head.
    \param [IN OUT]     btQueueHead        <RTB_QUEUE_HEAD*>        : bt Queue
    \return    removed btbuffer if succeed, otherwise NULL
*/
BT_BUFFER *
RtbDequeueHead(
    IN OUT RTB_QUEUE_HEAD *btQueueHead)
{
    BT_BUFFER *Rtb = NULL;
    pthread_mutex_lock(&btQueueHead->Lock);

    if (RtbQueueIsEmpty(btQueueHead))
    {
        pthread_mutex_unlock(&btQueueHead->Lock);
        return NULL;
    }
    Rtb = (BT_BUFFER *)btQueueHead->List.Next;
    RtbRemoveNode(btQueueHead, Rtb);
    pthread_mutex_unlock(&btQueueHead->Lock);
    return Rtb;
}

/**
    Get current rtb queue's length.
    \param [IN]     btQueueHead        <RTB_QUEUE_HEAD*>        : bt Queue
    \return    current queue's length
*/
signed long RtbGetQueueLen(
    IN RTB_QUEUE_HEAD *btQueueHead)
{
    return btQueueHead->QueueLen;
}

/**
    Empty the btqueue.
    \param [IN OUT]     btQueueHead        <RTB_QUEUE_HEAD*>        : bt Queue
*/
void RtbEmptyQueue(
    IN OUT RTB_QUEUE_HEAD *btQueueHead)
{
    BT_BUFFER *Rtb = NULL;
    pthread_mutex_lock(&btQueueHead->Lock);

    while (!RtbQueueIsEmpty(btQueueHead))
    {
        Rtb = (BT_BUFFER *)btQueueHead->List.Next;
        RtbRemoveNode(btQueueHead, Rtb);
        RtbFree(Rtb);
    }

    pthread_mutex_unlock(&btQueueHead->Lock);
    return;
}

/// Annie_tmp
unsigned char
RtbCheckQueueLen(IN RTB_QUEUE_HEAD *btQueueHead, IN uint8_t Len)
{
    return btQueueHead->QueueLen < Len ? true : false;
}

/**
    clone buffer for upper or lower layer, because original buffer should be stored in l2cap
    \param <BT_BUFFER* pDataBuffer: original buffer
    \return cloned buffer
*/
BT_BUFFER *
RtbCloneBuffer(
    IN BT_BUFFER *pDataBuffer)
{
    BT_BUFFER *pNewBuffer = NULL;
    if (pDataBuffer)
    {
        pNewBuffer = RtbAllocate(pDataBuffer->Length, 0);
        if (!pNewBuffer)
        {
            return NULL;
        }
        if (pDataBuffer && pDataBuffer->Data)
            memcpy(pNewBuffer->Data, pDataBuffer->Data, pDataBuffer->Length);
        else
        {
            RtbFree(pNewBuffer);
            return NULL;
        }

        pNewBuffer->Length = pDataBuffer->Length;
    }
    return pNewBuffer;
}
