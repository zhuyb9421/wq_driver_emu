#include "bt_transport_config.h"

#include <stddef.h>
#include <strings.h>

bool bt_transport_config_parse(const char *mode,
                               bt_transport_config_t *config)
{
    if (mode == NULL || config == NULL)
        return false;

    config->use_mbtchar = false;
    if (strcasecmp(mode, "H2") == 0) {
        config->transtype = BT_TRANS_H4 | BT_TRANS_HCI_SOCKET;
    } else if (strcasecmp(mode, "H4") == 0) {
        config->transtype = BT_TRANS_H4 | BT_TRANS_HCI_SOCKET |
                BT_TRANS_HCI_SOCKET_FALLBACK;
    } else if (strcasecmp(mode, "H5") == 0) {
        config->transtype = BT_TRANS_H5;
    } else {
        return false;
    }
    return true;
}
