#include "bt_vendor_open.h"

#include <errno.h>

int bt_vendor_open_channels(void *config,
                            int *fd_array,
                            size_t channel_count,
                            const bt_vendor_open_ops_t *ops)
{
    if (fd_array == NULL || ops == NULL || ops->transport_open == NULL ||
        ops->bridge_open == NULL || ops->transport_close == NULL) {
        errno = EINVAL;
        return 0;
    }

    for (size_t i = 0; i < channel_count; ++i)
        fd_array[i] = -1;

    if (ops->transport_open(config) == -1)
        return 0;

    const int stack_fd = ops->bridge_open();
    if (stack_fd == -1) {
        ops->transport_close();
        return 0;
    }

    for (size_t i = 0; i < channel_count; ++i)
        fd_array[i] = stack_fd;
    return 1;
}
