/******************************************************************************
 *
 *  Copyright (C) 2009-2018 WuQi Corporation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at:
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 ******************************************************************************/

/******************************************************************************
 *
 *  Filename:      bt_vendor_wuqi.c
 *
 *  Description:   WuQi vendor specific library implementation
 *
 ******************************************************************************/

#undef NDEBUG
#define LOG_TAG "libbt_vendor"
#include <utils/Log.h>
#include <stdio.h>
#include <stdint.h>
#include "bt_vendor_wuqi.h"
#include "bt_vendor_open.h"
#include "userial_vendor.h"
#include "wq_oem.h"
#include "upio.h"

/******************************************************************************
**  Externs
******************************************************************************/
extern unsigned int h5logfilter;
extern unsigned int h5_log_enable;
extern bool btsnoop_dump;
extern bool btsnoop_net_dump;
extern bool btsnoop_save_log;
extern char btsnoop_path[];
extern uint8_t coex_log_enable;
extern void hw_config_start(char transtype);
extern void hci_close_firmware_log_file(int fd);
extern int hci_firmware_log_fd;
#if (HW_END_WITH_HCI_RESET == TRUE)
void hw_epilog_process(void);
#endif

/******************************************************************************
**  Variables
******************************************************************************/
bt_vendor_callbacks_t *bt_vendor_cbacks = NULL;
extern bd_addr_t local_bd_addr;
bool bt_capture_fw_log = false;
bool bt_uart_dump = false;
bool sco_over_hci = false;

int mchar_fd = -1;

/******************************************************************************
**  Local type definitions
******************************************************************************/
#define DEVICE_NODE_MAX_LEN 512
#define BT_CONF_FILE        "/vendor/etc/bluetooth/wuqibt.conf"

#ifndef  WQ_BT_INI_PATH
#define BT_INI_FILE         "/vendor/firmware/wq_wlan_settings.ini"
#else
#define BT_INI_FILE         WQ_BT_INI_PATH
#endif

#ifndef DEFAULT_BT_DEVICE_NODE
#define DEFAULT_BT_DEVICE_NODE "?/dev/ttyAMA1:H5"
#endif

#define WQ_USB_DEVICE_NODE "/dev/mbtchar0"

static const char* FIRMWARE_PATHS[] = {
    BT_INI_FILE,
    "/vendor/etc/firmware/wq_wlan_settings.ini",
    "/system/etc/firmware/wq_wlan_settings.ini",
    "/system/vendor/firmware/wq_wlan_settings.ini",
    NULL
};

typedef struct {
	uint16_t uart_flowctrl : 1;
	uint16_t sco_over_hci : 1;
	uint16_t stb : 1;
	uint16_t host_wakeup_bt : 1;
	uint16_t bt_wakeup_host : 1;
	uint16_t deep_sleep : 1;
	uint16_t reserved : 9;
	char hci_mode[16];
	uint32_t uart_baudrate;
} wq_resource_bt_ini_t;

/******************************************************************************
**  Static Variables
******************************************************************************/
//transfer_type(4 bit) | transfer_interface(4 bit)
char bt_transtype = 0;
static char bt_device_node[DEVICE_NODE_MAX_LEN] = {0};

static tUSERIAL_CFG userial_cfg = {(USERIAL_DATABITS_8 | USERIAL_PARITY_NONE | USERIAL_STOPBITS_1), USERIAL_BAUD_1_5M,
                                   USERIAL_HW_FLOW_CTRL_OFF};

static int open_userial_transport(void *config)
{
    return userial_vendor_open((tUSERIAL_CFG *)config);
}

static const bt_vendor_open_ops_t userial_open_ops = {
    .transport_open = open_userial_transport,
    .bridge_open = userial_socket_open,
    .transport_close = userial_vendor_close,
};

/******************************************************************************
**  Functions
******************************************************************************/
static char *bt_trim(char *str)
{
    while (isspace(*str)) ++str;

    if (!*str) return str;

    char *end_str = str + strlen(str) - 1;
    while (end_str > str && isspace(*end_str)) --end_str;

    end_str[1] = '\0';
    return str;
}

static void load_bt_stack_conf()
{
    char *split;
    FILE *fp = fopen(BT_CONF_FILE, "rt");
    if (!fp) {
        ALOGE("%s unable to open file '%s': %s", __func__, BT_CONF_FILE, strerror(errno));
        return;
    }
    int line_num = 0;
    char line[1024];
    //char value[1024];
    while (fgets(line, sizeof(line), fp)) {
        char *line_ptr = bt_trim(line);
        ++line_num;

        // Skip blank and comment lines.
        if (*line_ptr == '\0' || *line_ptr == '#' || *line_ptr == '[') continue;

        split = strchr(line_ptr, '=');
        if (!split) {
            ALOGE("%s no key/value separator found on line %d.", __func__, line_num);
            continue;
        }

        *split = '\0';
        char *endptr;
        if (!strcmp(bt_trim(line_ptr), "btLogFilter")) {
            h5logfilter = strtol(bt_trim(split + 1), &endptr, 0);
        } else if (!strcmp(bt_trim(line_ptr), "H5LogOutput")) {
            h5_log_enable = strtol(bt_trim(split + 1), &endptr, 0);
        } else if (!strcmp(bt_trim(line_ptr), "BtsnoopNetDump")) {
            if (!strcmp(bt_trim(split + 1), "true")) btsnoop_net_dump = true;
        } else if (!strcmp(bt_trim(line_ptr), "BtSnoopFileName")) {
            sprintf(btsnoop_path, "%s_hal", bt_trim(split + 1));
        } else if (!strcmp(bt_trim(line_ptr), "BtCoexLogOutput")) {
            coex_log_enable = strtol(bt_trim(split + 1), &endptr, 0);
        } else if (!strcmp(bt_trim(line_ptr), "BtCaptureFwLog")) {
            if (!strcmp(bt_trim(split + 1), "true")) bt_capture_fw_log = true;
        }
    }

    fclose(fp);
}

static void bt_stack_conf_cleanup()
{
    h5logfilter = 0;
    h5_log_enable = 0;
    btsnoop_dump = false;
    btsnoop_net_dump = false;
}

static void load_bt_conf()
{
    char *split;
    memset(bt_device_node, 0, sizeof(bt_device_node));
    FILE *fp = fopen(BT_CONF_FILE, "rt");
    if (!fp) {
        ALOGE("%s unable to open file '%s': %s", __func__, BT_CONF_FILE, strerror(errno));
        strcpy(bt_device_node, DEFAULT_BT_DEVICE_NODE);
    } else {
        int line_num = 0;
        char line[1024];
        while (fgets(line, sizeof(line), fp)) {
            char *line_ptr = bt_trim(line);
            ++line_num;

            // Skip blank and comment lines.
            if (*line_ptr == '\0' || *line_ptr == '#' || *line_ptr == '[') continue;

            split = strchr(line_ptr, '=');
            if (!split) {
                ALOGE("%s no key/value separator found on line %d.", __func__, line_num);
                strcpy(bt_device_node, DEFAULT_BT_DEVICE_NODE);
                fclose(fp);
                return;
            }
            *split = '\0';
            if (!strcmp(bt_trim(line_ptr), "BtDeviceNode")) {
                strcpy(bt_device_node, bt_trim(split + 1));
            }
        }
        fclose(fp);
    }
    bt_transtype = 0;
    if (bt_device_node[0] == '?') {
        int i = 0;
        while (bt_device_node[i] != '\0') {
            bt_device_node[i] = bt_device_node[i + 1];
            i++;
        }
    }

    if ((split = strchr(bt_device_node, ':')) != NULL) {
        *split = '\0';
        if (!strcmp(bt_trim(split + 1), "H5")) {
            bt_transtype |= BT_TRANS_H5;
        } else if (!strcmp(bt_trim(split + 1), "H4")) {
            bt_transtype |= BT_TRANS_H4;
        }
    } else {
        //default use h4
        bt_transtype |= BT_TRANS_H4;
    }

    ALOGI("%s bt_device_node[%s],bt_transtype[0x%x]", __func__, bt_device_node, bt_transtype);
}

static const char* get_ini_path(void) {
    for (int i = 0; FIRMWARE_PATHS[i] != NULL; i++) {
        if (access(FIRMWARE_PATHS[i], F_OK) == 0) {
            if (access(FIRMWARE_PATHS[i], R_OK) == 0) {
                return FIRMWARE_PATHS[i];
            } else {
                ALOGE("INI file exists but not readable: %s\n", FIRMWARE_PATHS[i]);
            }
        }
    }
    
    ALOGE("No valid INI file found in predefined paths\n");
    return NULL;
}

static int load_ini(wq_resource_bt_ini_t *bt_info)
{
    char *split;
    const char* ini_path = get_ini_path();
    if (!ini_path) {
        return -EINVAL;
    }
    FILE *fp = fopen(ini_path, "rt");
    if (!fp) {
        ALOGE("%s unable to open file '%s': %s", __func__, ini_path, strerror(errno));
        return -1;
    }
    int line_num = 0;
    char line[1024];
    //char value[1024];
    while (fgets(line, sizeof(line), fp)) {
        char *line_ptr = bt_trim(line);
        ++line_num;

        // Skip blank and comment lines.
        if (*line_ptr == '\0' || *line_ptr == '#' || *line_ptr == '[') continue;

        split = strchr(line_ptr, '=');
        if (!split) {
            ALOGE("%s no key/value separator found on line %d.", __func__, line_num);
            continue;
        }

        *split = '\0';
        char *endptr;
        if (!strcmp(bt_trim(line_ptr), "hci_mode")) {
            snprintf(bt_info->hci_mode, sizeof(bt_info->hci_mode), "%s", bt_trim(split + 1));
        } else if (!strcmp(bt_trim(line_ptr), "hci_uart_flowctrl")) {
            bt_info->uart_flowctrl = strtol(bt_trim(split + 1), &endptr, 0);
        } else if (!strcmp(bt_trim(line_ptr), "hci_uart_baudrate")) {
            bt_info->uart_baudrate = (uint32_t)strtol(bt_trim(split + 1), &endptr, 0);
        } else if (!strcmp(bt_trim(line_ptr), "sco_over_hci")) {
            bt_info->sco_over_hci = (uint32_t)strtol(bt_trim(split + 1), &endptr, 0);
        }
    }
    fclose(fp);
    return 0;
}

static int load_ini_bt_info(void)
{
    int ret = 0;
    wq_resource_bt_ini_t *bt_info = (wq_resource_bt_ini_t*)calloc(1, sizeof(wq_resource_bt_ini_t));
    if (!bt_info) {
        ret = -ENOMEM;
        ALOGE("%s: malloc for bt info failed", __func__);
        goto out;
    }
    if((ret = load_ini(bt_info))) {
        ret = -EINVAL;
        goto release_bt_info;
    }
    ALOGD("%s hci:%s baudrate:%u flowctrl:%u sco_over_hci:%u", __func__, bt_info->hci_mode,
          bt_info->uart_baudrate, bt_info->uart_flowctrl, bt_info->sco_over_hci);

    bt_transport_config_t transport_config;
    if (!bt_transport_config_parse(bt_info->hci_mode, &transport_config)) {
        ALOGE("%s: hci_mode:%s is error", __func__, bt_info->hci_mode);
        ret = -EINVAL;
        goto release_bt_info;
    }
    bt_transtype = (char)transport_config.transtype;
    if (transport_config.use_mbtchar) {
        strcpy(bt_device_node, WQ_USB_DEVICE_NODE);
    }

    switch (bt_info->uart_baudrate) {
    case 9600:
        userial_cfg.baud = USERIAL_BAUD_9600;
        break;
    case 115200:
        userial_cfg.baud = USERIAL_BAUD_115200;
        break;
    case 230400:
        userial_cfg.baud = USERIAL_BAUD_230400;
        break;
    case 460800:
        userial_cfg.baud = USERIAL_BAUD_460800;
        break;
    case 921600:
        userial_cfg.baud = USERIAL_BAUD_921600;
        break;
    case 1000000:
        userial_cfg.baud = USERIAL_BAUD_1M;
        break;
    case 1500000:
        userial_cfg.baud = USERIAL_BAUD_1_5M;
        break;
    case 2000000:
        userial_cfg.baud = USERIAL_BAUD_2M;
        break;
    case 3000000:
        userial_cfg.baud = USERIAL_BAUD_3M;
        break;
    case 4000000:
        userial_cfg.baud = USERIAL_BAUD_4M;
        break;
    default:
        ALOGE("%s: unsupported baudrate:%d", __func__, bt_info->uart_baudrate);
        break;
    }

    if (bt_info->uart_flowctrl) {
        userial_cfg.hw_fctrl = USERIAL_HW_FLOW_CTRL_ON;
    } else {
        userial_cfg.hw_fctrl = USERIAL_HW_FLOW_CTRL_OFF;
    }

    if(bt_info->sco_over_hci){
        sco_over_hci = true;
        property_set("bluetooth.vendor.wq.sco_over_hci", "true");
    }else{
        sco_over_hci = false;
        property_set("bluetooth.vendor.wq.sco_over_hci", "false");
    }

release_bt_info:
    free(bt_info);
    bt_info = NULL;
out:
    ALOGD("%s done, bt_transtype:%x baud:%d fmt:0x%x, sco_over_hci:%d", __func__, bt_transtype, userial_cfg.baud, userial_cfg.fmt, sco_over_hci);
    return ret;
}

static void load_oem_bt_info(void)
{
    wq_resource_bt_info_t *bt_info = wq_oem_get_bt_info();
    if (!bt_info) {
        ALOGE("load_oem_bt_info: wq_get_bt_info failed");
        return;
    }

    ALOGD("load_oem_bt_info hci:%d baudrate:%d flow:%d parity_en:%d parity_odd:%d", bt_info->hci_mode,
          bt_info->uart_baudrate, bt_info->uart_hw_flow, bt_info->uart_parity_en, bt_info->uart_parity_odd);

    if (bt_info->hci_mode == HCI_H2) {
        bt_transtype = BT_TRANS_H4 | BT_TRANS_HCI_SOCKET;
    } else if (bt_info->hci_mode == HCI_H4) {
        bt_transtype = BT_TRANS_H4 | BT_TRANS_HCI_SOCKET |
                BT_TRANS_HCI_SOCKET_FALLBACK;
    } else if (bt_info->hci_mode == HCI_H5) {
        bt_transtype = BT_TRANS_H5;
    } else {
        ALOGE("load_oem_bt_info: hci_mode:%d is error", bt_info->hci_mode);
    }

    switch (bt_info->uart_baudrate) {
    case 9600:
        userial_cfg.baud = USERIAL_BAUD_9600;
        break;
    case 115200:
        userial_cfg.baud = USERIAL_BAUD_115200;
        break;
    case 230400:
        userial_cfg.baud = USERIAL_BAUD_230400;
        break;
    case 460800:
        userial_cfg.baud = USERIAL_BAUD_460800;
        break;
    case 921600:
        userial_cfg.baud = USERIAL_BAUD_921600;
        break;
    case 1000000:
        userial_cfg.baud = USERIAL_BAUD_1M;
        break;
    case 1500000:
        userial_cfg.baud = USERIAL_BAUD_1_5M;
        break;
    case 2000000:
        userial_cfg.baud = USERIAL_BAUD_2M;
        break;
    case 3000000:
        userial_cfg.baud = USERIAL_BAUD_3M;
        break;
    case 4000000:
        userial_cfg.baud = USERIAL_BAUD_4M;
        break;
    default:
        ALOGE("load_oem_bt_info: unsupported baudrate:%d", bt_info->uart_baudrate);
        break;
    }

    if (bt_info->uart_hw_flow) {
        userial_cfg.hw_fctrl = USERIAL_HW_FLOW_CTRL_ON;
    } else {
        userial_cfg.hw_fctrl = USERIAL_HW_FLOW_CTRL_OFF;
    }

    userial_cfg.fmt = USERIAL_DATABITS_8 | USERIAL_STOPBITS_1;
    if (bt_info->uart_parity_en) {
        if (bt_info->uart_parity_odd) {
            userial_cfg.fmt |= USERIAL_PARITY_ODD;
        } else {
            userial_cfg.fmt |= USERIAL_PARITY_EVEN;
        }
    } else {
        userial_cfg.fmt |= USERIAL_PARITY_NONE;
    }

    ALOGD("load_oem_bt_info done, bt_transtype:%x baud:%d fmt:0x%x", bt_transtype, userial_cfg.baud, userial_cfg.fmt);
}

static void load_oem_audio_config(void)
{
    static const char* iis_standard_tbl[] = {"philips", "msb", "lsb"};
    wq_resource_audio_t *audio_cfg = wq_oem_get_audio_config();
    if (!audio_cfg) {
        ALOGE("load_oem_audio_config: wq_get_audio_config failed");
        return;
    }

    ALOGD("load_oem_audio_config done, audio_path:%s", audio_cfg->audio_cfg.audio_path ? "hci": "pcm");
    ALOGD("oem audio_i2s_tx cfg: mode(%s) standard(%s) format(%s) pcm(%s)",
        audio_cfg->tx_cfg.iis_mode_master ? "master": "slave", iis_standard_tbl[audio_cfg->tx_cfg.iis_standard],
        audio_cfg->tx_cfg.iis_data_format ? "24B": "16B", audio_cfg->tx_cfg.iis_pcm_mode ? "true": "false");
    ALOGD("oem audio_i2s_rx cfg: mode(%s) standard(%s) format(%s) pcm(%s)",
        audio_cfg->rx_cfg.iis_mode_master ? "master": "slave", iis_standard_tbl[audio_cfg->rx_cfg.iis_standard],
        audio_cfg->rx_cfg.iis_data_format ? "24B": "16B", audio_cfg->rx_cfg.iis_pcm_mode ? "true": "false");

    if(audio_cfg->audio_cfg.audio_path){
        sco_over_hci = true;
        property_set("bluetooth.vendor.wq.sco_over_hci", "true");
    }else{
        sco_over_hci = false;
        property_set("bluetooth.vendor.wq.sco_over_hci", "false");
    }
}

/*****************************************************************************
**
**   BLUETOOTH VENDOR INTERFACE LIBRARY FUNCTIONS
**
*****************************************************************************/

static int init(const bt_vendor_callbacks_t *p_cb, unsigned char *local_bdaddr)
{
    ALOGI("init addr %02X:%02X:%02X:%02X:%02X:%02X", local_bdaddr[0], local_bdaddr[1], local_bdaddr[2], local_bdaddr[3],
          local_bdaddr[4], local_bdaddr[5]);

    char value[100];
    load_bt_conf();
    load_bt_stack_conf();
    if(load_ini_bt_info() != 0) {
        // If loading INI fails, we can still continue with default settings.
        ALOGE("%s: failed to load INI file, falling back to oem settings", __func__);
        load_oem_bt_info();
        load_oem_audio_config();
    }
    if (p_cb == NULL) {
        ALOGE("init failed with no user callbacks!");
        return -1;
    }

    /* This is handed over from the stack */
    memset(&local_bd_addr, 0x00, sizeof(local_bd_addr));

    property_get("persist.vendor.wq.uartdump.enable", value, "false");
    if (strncmp(value, "true", 4) == 0) {
        bt_uart_dump = true;
    }

    property_get("persist.vendor.btsnoop.enable", value, "false");
    if (strncmp(value, "true", 4) == 0) {
        btsnoop_dump = true;
    }

    property_get("persist.vendor.btsnoopsavelog", value, "false");
    if (strncmp(value, "true", 4) == 0) {
        btsnoop_save_log = true;
    }

    upio_init();

    userial_vendor_init(bt_device_node);

    /* store reference to user callbacks */
    bt_vendor_cbacks = (bt_vendor_callbacks_t *) p_cb;


    ALOGE("btsnoop_dump = %d, btsnoop_save_log = %d", btsnoop_dump, btsnoop_save_log);
    if (btsnoop_dump) btsnoop_open();
    if (btsnoop_net_dump) btsnoop_net_open();

#define BT_FWDNLD_PROP "wuqi.vendor.bluetooth.fwdnld"
    property_set(BT_FWDNLD_PROP, "true");
    return 0;
}

/** Requested operations */
static int op(bt_vendor_opcode_t opcode, void *param)
{
    int retval = 0;

    //BTVNDDBG("op for %d", opcode);

    switch (opcode) {
    case BT_VND_OP_POWER_CTRL: {
        ALOGD("-------BT_VND_OP_POWER_CTRL------");
        if (BT_VND_PWR_OFF == *(int *)param) {
            ALOGD("Power off");
        } else if (BT_VND_PWR_ON == *(int *)param) {
            ALOGD("Power on");
        } else {
            retval = -1;
        }

    } break;

    case BT_VND_OP_FW_CFG: {
        ALOGD("-------BT_VND_OP_FW_CFG------");
        hw_config_start(bt_transtype);
    } break;

    case BT_VND_OP_SCO_CFG: {
        retval = -1;
    } break;

    case BT_VND_OP_USERIAL_OPEN: {
        ALOGD("-------BT_VND_OP_USERIAL_OPEN------");
        int(*fd_array)[] = (int(*)[])param;

        retval = bt_vendor_open_channels(&userial_cfg,
                                         *fd_array,
                                         CH_MAX,
                                         &userial_open_ops);
        /* retval contains numbers of open fd of HCI channels */
    } break;

    case BT_VND_OP_USERIAL_CLOSE: {
        ALOGD("-------BT_VND_OP_USERIAL_CLOSE------");
        userial_vendor_close();
    } break;

    case BT_VND_OP_GET_LPM_IDLE_TIMEOUT: {
        uint32_t *p_lpm_timeout_ms = (uint32_t *)param;
        *p_lpm_timeout_ms = LPM_IDLE_TIMEOUT_MS;
    } break;

    case BT_VND_OP_LPM_SET_MODE: {

        bt_vendor_lpm_mode_t mode = *(bt_vendor_lpm_mode_t *)param;
        ALOGD("-------BT_VND_OP_LPM_SET_MODE------ %d", mode);
        //for now if the mode is BT_VND_LPM_DISABLE, we guess the hareware bt
        //interface is closing, we shall not send any cmd to the interface.
        if (mode == BT_VND_LPM_DISABLE) {
            upio_set(UPIO_LPM_MODE, UPIO_DEASSERT, 0);
            userial_set_bt_interface_state(0);
        } else {
            upio_set(UPIO_LPM_MODE, UPIO_ASSERT, 0);
            userial_set_bt_interface_state(1);
        }
    } break;

    case BT_VND_OP_LPM_WAKE_SET_STATE: {
        bt_vendor_lpm_wake_state_t wake_state = *(bt_vendor_lpm_wake_state_t *)param;
        ALOGD("-------BT_VND_OP_LPM_WAKE_SET_STATE------ %d", wake_state);
        if (BT_VND_LPM_WAKE_ASSERT == wake_state) {
            upio_set(UPIO_BT_WAKE, UPIO_ASSERT, 0);
        } else {
            upio_set(UPIO_BT_WAKE, UPIO_DEASSERT, 0);
        }
    } break;
    case BT_VND_OP_EPILOG: {

#if (HW_END_WITH_HCI_RESET == FALSE)
        if (bt_vendor_cbacks) {
            bt_vendor_cbacks->epilog_cb(BT_VND_OP_RESULT_SUCCESS);
        }
#else
        hw_epilog_process();
#endif
    } break;

    default:
        break;
    }

    return retval;
}

/** Closes the interface */
static void cleanup(void)
{
    BTVNDDBG("cleanup");
    bt_vendor_cbacks = NULL;

    if (btsnoop_dump) btsnoop_close();
    if (btsnoop_net_dump) btsnoop_net_close();
    if (bt_capture_fw_log) {
        hci_close_firmware_log_file(hci_firmware_log_fd);
    }
    bt_stack_conf_cleanup();
    upio_cleanup();
}

// Entry point of DLib
const bt_vendor_interface_t BLUETOOTH_VENDOR_LIB_INTERFACE = {sizeof(bt_vendor_interface_t), init, op, cleanup};
