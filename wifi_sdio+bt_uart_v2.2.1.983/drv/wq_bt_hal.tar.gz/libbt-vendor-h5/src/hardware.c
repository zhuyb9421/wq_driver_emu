/******************************************************************************
 *
 *  Copyright (C) 2009-2018 WuQi Corporation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at:
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 ******************************************************************************/

/******************************************************************************
 *
 *  Filename:      hardware.c
 *
 *  Description:   Contains controller-specific functions, like
 *                      firmware patch download
 *                      low power mode operations
 *
 ******************************************************************************/

#define LOG_TAG "bt_hwcfg"

#include <utils/Log.h>
#include <cutils/properties.h>
#include <stdlib.h>
#include "wq_hci_layer.h"
#include "bt_vendor_wuqi.h"
#include "userial_vendor.h"
#include "bt_vendor_lib.h"
#include "hardware.h"
#include "bt_address.h"


bt_hw_cfg_cb_t hw_cfg_cb;
#define HCI_EVT_STATUS_OFFSET 5
#define HCI_EVT_DATA_OFFSET 6

static void hw_config_cback(void *p_evt_buf);

extern bt_hw_cfg_cb_t hw_cfg_cb;
extern bool bt_auto_restart;
extern volatile int h5_init_datatrans_flag;
extern bd_addr_t local_bd_addr;

uint8_t get_heartbeat_from_hardware()
{
    return hw_cfg_cb.heartbeat;
}

/*******************************************************************************
**
** Function         hw_lpm_ctrl_cback
**
** Description      Callback function for lpm enable/disable rquest
**
** Returns          None
**
*******************************************************************************/
void hw_lpm_ctrl_cback(void *p_mem)
{
    HC_BT_HDR *p_evt_buf = (HC_BT_HDR *) p_mem;
    bt_vendor_op_result_t status = BT_VND_OP_RESULT_FAIL;

    if (*((uint8_t *)(p_evt_buf + 1) + HCI_EVT_CMD_CMPL_STATUS_OFFSET) == 0)
    {
        status = BT_VND_OP_RESULT_SUCCESS;
    }

    if (bt_vendor_cbacks)
    {
        bt_vendor_cbacks->lpm_cb(status);
        bt_vendor_cbacks->dealloc(p_evt_buf);
    }
}


#if (HW_END_WITH_HCI_RESET == TRUE)
/******************************************************************************
*
**
** Function         hw_epilog_cback
**
** Description      Callback function for Command Complete Events from HCI
**                  commands sent in epilog process.
**
** Returns          None
**
*******************************************************************************/
void hw_epilog_cback(void *p_mem)
{
    HC_BT_HDR   *p_evt_buf = (HC_BT_HDR *) p_mem;
    uint8_t     *p, status;
    uint16_t    opcode;

    status = *((uint8_t *)(p_evt_buf + 1) + HCI_EVT_CMD_CMPL_STATUS_OFFSET);
    p = (uint8_t *)(p_evt_buf + 1) + HCI_EVT_CMD_CMPL_OPCODE_OFFSET;
    STREAM_TO_UINT16(opcode,p);

    BTVNDDBG("%s Opcode:0x%04X Status: %d", __FUNCTION__, opcode, status);

    if (bt_vendor_cbacks)
    {
        /* Must free the RX event buffer */
        bt_vendor_cbacks->dealloc(p_evt_buf);

        /* Once epilog process is done, must call epilog_cb callback
           to notify caller */
        bt_vendor_cbacks->epilog_cb(BT_VND_OP_RESULT_SUCCESS);
    }
}

/******************************************************************************
*
**
** Function         hw_epilog_process
**
** Description      Sample implementation of epilog process
**
** Returns          None
**
*******************************************************************************/
void hw_epilog_process(void)
{
    HC_BT_HDR  *p_buf = NULL;
    uint8_t     *p;

    BTVNDDBG("hw_epilog_process");

    /* Sending a HCI_RESET */
    if (bt_vendor_cbacks)
    {
        /* Must allocate command buffer via HC's alloc API */
        p_buf = (HC_BT_HDR *) bt_vendor_cbacks->alloc(BT_HC_HDR_SIZE + \
                                                       HCI_CMD_PREAMBLE_SIZE);
    }

    if (p_buf)
    {
        p_buf->event = MSG_STACK_TO_HC_HCI_CMD;
        p_buf->offset = 0;
        p_buf->layer_specific = 0;
        p_buf->len = HCI_CMD_PREAMBLE_SIZE;

        p = (uint8_t *) (p_buf + 1);
        UINT16_TO_STREAM(p, HCI_RESET);
        *p = 0; /* parameter length */

        /* Send command via HC's xmit_cb API */
        bt_vendor_cbacks->xmit_cb(HCI_RESET, p_buf, hw_epilog_cback);
    }
    else
    {
        if (bt_vendor_cbacks)
        {
            ALOGE("vendor lib epilog process aborted [no buffer]");
            bt_vendor_cbacks->epilog_cb(BT_VND_OP_RESULT_FAIL);
        }
    }
}
#endif // (HW_END_WITH_HCI_RESET == TRUE)


static void hw_config_complete(bool success)
{
    ALOGD("hw_config_complete success:%d", success);

    if(success){
        bt_vendor_cbacks->fwcfg_cb(BT_VND_OP_RESULT_SUCCESS);
        hw_cfg_cb.state = 0;
        h5_init_datatrans_flag = 0;
        hw_cfg_cb.heartbeat = 1;
    }else{
        bt_vendor_cbacks->fwcfg_cb(BT_VND_OP_RESULT_FAIL);
    }
}

static void hw_config_send_hci_command(uint16_t opcode, uint8_t *param, uint8_t param_len)
{
    HC_BT_HDR  *p_buf = NULL;
    uint8_t     *p;

    /* Must allocate command buffer via HC's alloc API */
    p_buf = (HC_BT_HDR *) bt_vendor_cbacks->alloc(BT_HC_HDR_SIZE + HCI_CMD_PREAMBLE_SIZE + param_len);
    if (p_buf) {
        p_buf->event = MSG_STACK_TO_HC_HCI_CMD;
        p_buf->offset = 0;
        p_buf->layer_specific = 0;
        p_buf->len = HCI_CMD_PREAMBLE_SIZE + param_len;

        p = (uint8_t *) (p_buf + 1);
        UINT16_TO_STREAM(p, opcode);
        *p++ = param_len; /* parameter length */
        if(param && param_len){
            memcpy(p, param, param_len);
        }
        bt_vendor_cbacks->xmit_cb(opcode, p_buf, hw_config_cback);
    } else {
        ALOGE("%s buffer alloc fail!", __func__);
        bt_vendor_cbacks->fwcfg_cb(BT_VND_OP_RESULT_FAIL);
    }
}

/*******************************************************************************
**
** Function         hw_config_cback
**
** Description      Callback function for controller configuration
**
** Returns          None
**
*******************************************************************************/
static void hw_config_cback(void *p_mem)
{
    HC_BT_HDR   *p_evt_buf = NULL;
    uint8_t     *p = NULL;
    uint8_t     status = 0;
    uint16_t    opcode = 0;

    if (!p_mem) {
        ALOGE("hw_config_cback error, p_mem==NULL");
        return;
    }

    if (!bt_vendor_cbacks) {
        ALOGE("hw_config_cback error, bt_vendor_cbacks==NULL");
        return;
    }

    p_evt_buf = (HC_BT_HDR *) p_mem;
    status = *((uint8_t *)(p_evt_buf + 1) + HCI_EVT_CMD_CMPL_STATUS_OFFSET);
    p = (uint8_t *)(p_evt_buf + 1) + HCI_EVT_CMD_CMPL_OPCODE_OFFSET;
    STREAM_TO_UINT16(opcode,p);

    ALOGD("%s state:%d opcode:0x%X status:%d", __func__, hw_cfg_cb.state, opcode, status);

    if(status != 0){
        ALOGE("hw_config_cback status:%d error", status);
        hw_config_complete(false);
        return;
    }

    if (opcode == HCI_VSC_H5_INIT) {
        bt_vendor_cbacks->dealloc(p_evt_buf);
        hw_cfg_cb.state = HW_CFG_BT_ON;
        uint8_t on = 1;
        hw_config_send_hci_command(HCI_CMD_VNDR_BT_ON_OFF, &on, 1);
    }else if (opcode == HCI_CMD_VNDR_BT_ON_OFF) {
        bt_vendor_cbacks->dealloc(p_evt_buf);
        hw_cfg_cb.state = HW_CFG_READ_ADDR;
        hw_config_send_hci_command(HCI_READ_BD_ADDR, NULL, 0);
    } else if (opcode == HCI_READ_BD_ADDR) {
        memcpy(&(local_bd_addr.addr), &(p_evt_buf->data[HCI_EVT_DATA_OFFSET]), 6);
        bt_vendor_cbacks->dealloc(p_evt_buf);
        if (analysis_bt_address(local_bd_addr.addr)) {
            hw_cfg_cb.state = HW_CFG_SET_ADDR;
            hw_config_send_hci_command(HCI_VS_CMD_SET_MAC_ADDR, local_bd_addr.addr, 6);
        } else {
            hw_config_complete(true);
        }
    } else if (opcode == HCI_VS_CMD_SET_MAC_ADDR) {
        char bdstr[kStringLength + 1];
        bytes_to_string(local_bd_addr.addr, bdstr);
        if (property_set(PERSIST_BDADDR_PROPERTY, (char *)bdstr) < 0) {
            ALOGE("%s: Failed to set random BDA in prop %s", __func__, PERSIST_BDADDR_PROPERTY);
        }
        bt_vendor_cbacks->dealloc(p_evt_buf);
        hw_config_complete(true);
    } else {
        bt_vendor_cbacks->dealloc(p_evt_buf);
        ALOGE("hw_config_cback unknown opcode:0x%x", opcode);
    }
}

/*******************************************************************************
**
** Function        hw_config_start
**
** Description     Kick off controller initialization process
**
** Returns         None
**
*******************************************************************************/
void hw_config_start(char transtype)
{
    memset(&hw_cfg_cb, 0, sizeof(bt_hw_cfg_cb_t));

    BTVNDDBG("hw_config_start, transtype = 0x%x \n", transtype);

    if (bt_vendor_cbacks) {
        if (transtype & BT_TRANS_H5) {
            hw_cfg_cb.state = HW_CFG_H5_INIT;
            hw_config_send_hci_command(HCI_VSC_H5_INIT, NULL, 0);
        } else {
            hw_cfg_cb.state = HW_CFG_BT_ON;
            uint8_t on = 1;
            hw_config_send_hci_command(HCI_CMD_VNDR_BT_ON_OFF, &on, 1);
        }
    } else {
        ALOGE("%s call back is null", __func__);
    }
}
