#include "hci_socket_transport.h"
#include "bt_transport_config.h"

#include <errno.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>

#define BTPROTO_HCI 1
#define HCI_CHANNEL_USER 1
#define HCI_RETRY_INTERVAL_MS 1000U

struct sockaddr_hci {
    sa_family_t hci_family;
    unsigned short hci_dev;
    unsigned short hci_channel;
};

static const hci_socket_transport_ops_t posix_ops = {
    .socket_fn = socket,
    .bind_fn = bind,
    .close_fn = close,
    .write_fn = write,
    .clock_gettime_fn = clock_gettime,
    .nanosleep_fn = nanosleep,
};

static int64_t timespec_to_ms(const struct timespec *time)
{
    return (int64_t)time->tv_sec * 1000 + time->tv_nsec / 1000000;
}

static bool ops_are_valid(const hci_socket_transport_ops_t *ops)
{
    return ops != NULL && ops->socket_fn != NULL && ops->bind_fn != NULL &&
           ops->close_fn != NULL && ops->write_fn != NULL &&
           ops->clock_gettime_fn != NULL && ops->nanosleep_fn != NULL;
}

static int sleep_ms(unsigned int duration_ms,
                    const hci_socket_transport_ops_t *ops)
{
    struct timespec requested = {
        .tv_sec = duration_ms / 1000,
        .tv_nsec = (long)(duration_ms % 1000) * 1000000,
    };
    struct timespec remaining;

    while (ops->nanosleep_fn(&requested, &remaining) == -1) {
        if (errno != EINTR)
            return -1;
        requested = remaining;
    }
    return 0;
}

int hci_socket_transport_open_with_ops(
        unsigned int dev_id,
        unsigned int timeout_ms,
        const hci_socket_transport_ops_t *ops)
{
    struct timespec start;

    if (!ops_are_valid(ops)) {
        errno = EINVAL;
        return -1;
    }
    if (ops->clock_gettime_fn(CLOCK_MONOTONIC, &start) == -1)
        return -1;

    const int64_t deadline_ms = timespec_to_ms(&start) + timeout_ms;
    for (;;) {
        int fd = ops->socket_fn(AF_BLUETOOTH,
                                SOCK_RAW | SOCK_CLOEXEC,
                                BTPROTO_HCI);
        if (fd == -1)
            return -1;

        const struct sockaddr_hci address = {
            .hci_family = AF_BLUETOOTH,
            .hci_dev = (unsigned short)dev_id,
            .hci_channel = HCI_CHANNEL_USER,
        };

        int result;
        do {
            result = ops->bind_fn(fd,
                                  (const struct sockaddr *)&address,
                                  sizeof(address));
        } while (result == -1 && errno == EINTR);

        if (result == 0)
            return fd;

        const int bind_error = errno;
        ops->close_fn(fd);
        if (bind_error != ENODEV) {
            errno = bind_error;
            return -1;
        }

        struct timespec now;
        if (ops->clock_gettime_fn(CLOCK_MONOTONIC, &now) == -1)
            return -1;
        const int64_t remaining_ms = deadline_ms - timespec_to_ms(&now);
        if (remaining_ms <= 0) {
            errno = ENODEV;
            return -1;
        }

        const unsigned int delay_ms =
                remaining_ms < HCI_RETRY_INTERVAL_MS
                        ? (unsigned int)remaining_ms
                        : HCI_RETRY_INTERVAL_MS;
        if (sleep_ms(delay_ms, ops) == -1)
            return -1;
    }
}

int hci_socket_transport_open(unsigned int dev_id,
                              unsigned int timeout_ms)
{
    return hci_socket_transport_open_with_ops(dev_id, timeout_ms, &posix_ops);
}

ssize_t hci_socket_transport_write_packet_with_ops(
        int fd,
        const uint8_t *packet,
        size_t packet_length,
        const hci_socket_transport_ops_t *ops)
{
    if (!ops_are_valid(ops) || packet == NULL || packet_length == 0) {
        errno = EINVAL;
        return -1;
    }

    ssize_t result;
    do {
        result = ops->write_fn(fd, packet, packet_length);
    } while (result == -1 && errno == EINTR);

    if (result == -1)
        return -1;
    if ((size_t)result != packet_length) {
        errno = EIO;
        return -1;
    }
    return result;
}

ssize_t hci_socket_transport_write_packet(int fd,
                                          const uint8_t *packet,
                                          size_t packet_length)
{
    return hci_socket_transport_write_packet_with_ops(
            fd, packet, packet_length, &posix_ops);
}

bool hci_socket_transport_is_selected(uint8_t transtype)
{
    return (transtype & BT_TRANS_HCI_SOCKET) != 0;
}

bool hci_socket_transport_should_fallback(uint8_t transtype)
{
    return (transtype & BT_TRANS_HCI_SOCKET_FALLBACK) != 0;
}
