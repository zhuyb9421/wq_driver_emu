/****************************************************************************

Copyright(c) 2022 by WuQi Technologies. ALL RIGHTS RESERVED.

This Information is proprietary to WuQi Technologies and MAY NOT
be copied by any method or incorporated into another program without
the express written consent of WuQi. This Information or any portion
thereof remains the property of WuQi. The Information contained herein
is believed to be accurate and WuQi assumes no responsibility or
liability for its use in any way and conveys no license or title under
any patent or copyright and makes no representation or warranty that this
Information is free from patent or copyright infringement.

****************************************************************************/

#include <string.h>
#include <stdio.h>
#include "ringbuffer.h"

enum ringbuffer_state ringbuffer_status(struct ringbuffer *rb)
{
    if (rb == NULL){
        return RINGBUFFER_EMPTY;
    }

    if (rb->read_index == rb->write_index)
    {
        if (rb->read_mirror == rb->write_mirror){
            return RINGBUFFER_EMPTY;
        }
        else
            return RINGBUFFER_FULL;
    }
    return RINGBUFFER_HALFFULL;
}

void ringbuffer_init(struct ringbuffer *rb,
                        uint8_t           *pool,
                        int16_t            size)
{
    if ((rb == NULL) || (size <= 0)){
        return;
    }

    /* initialize read and write index */
    rb->read_mirror = rb->read_index = 0;
    rb->write_mirror = rb->write_index = 0;

    /* set buffer pool and size */
    rb->buffer_ptr = pool;
    rb->buffer_size = ALIGN_DOWN(size, 4);
}

/**
 * put a block of data into ring buffer
 */
uint16_t ringbuffer_put(struct ringbuffer *rb,
                            const uint8_t *ptr,
                            uint16_t       length,
                            bool           force)
{
    uint16_t size;

    if (rb == NULL){
        return 0;
    }

    /* whether has enough space */
    size = ringbuffer_space_len(rb);

    /* no space */
    if (size == 0)
        return 0;

    /* drop some data */
    if (!force && (size < length))
    {
        length = size;
    }

    /* replace some data */
    if (force && (length > rb->buffer_size))
    {
        ptr = &ptr[length - rb->buffer_size];
        length = rb->buffer_size;
    }

    if (rb->buffer_size - rb->write_index > length)
    {
        /* read_index - write_index = empty space */
        memcpy(&rb->buffer_ptr[rb->write_index], ptr, length);
        /* this should not cause overflow because there is enough space for
         * length of data in current mirror */
        rb->write_index += length;

        if (force && (length > size))
        {
            rb->read_index = rb->write_index;
        }

        return length;
    }

    memcpy(&rb->buffer_ptr[rb->write_index],
           &ptr[0],
           rb->buffer_size - rb->write_index);
    memcpy(&rb->buffer_ptr[0],
           &ptr[rb->buffer_size - rb->write_index],
           length - (rb->buffer_size - rb->write_index));

    /* we are going into the other side of the mirror */
    rb->write_mirror = ~rb->write_mirror;
    rb->write_index = length - (rb->buffer_size - rb->write_index);

    if (force && (length > size))
    {
        rb->read_mirror = ~rb->read_mirror;
        rb->read_index = rb->write_index;
    }

    return length;
}

/**
 *  get data from ring buffer
 */
uint16_t ringbuffer_get(struct ringbuffer *rb,
                            uint8_t           *ptr,
                            uint16_t           length)
{
    uint16_t size;

    if (rb == NULL){
        return 0;
    }

    /* whether has enough data  */
    size = ringbuffer_data_len(rb);

    /* no data */
    if (size == 0)
        return 0;

    /* less data */
    if (size < length)
        length = size;

    if (rb->buffer_size - rb->read_index > length)
    {
        /* copy all of data */
        memcpy(ptr, &rb->buffer_ptr[rb->read_index], length);
        /* this should not cause overflow because there is enough space for
         * length of data in current mirror */
        rb->read_index += length;
        return length;
    }

    memcpy(&ptr[0],
           &rb->buffer_ptr[rb->read_index],
           rb->buffer_size - rb->read_index);
    memcpy(&ptr[rb->buffer_size - rb->read_index],
           &rb->buffer_ptr[0],
           length - (rb->buffer_size - rb->read_index));

    /* we are going into the other side of the mirror */
    rb->read_mirror = ~rb->read_mirror;
    rb->read_index = length - (rb->buffer_size - rb->read_index);

    return length;
}

/**
 * get the size of data in rb
 */
uint16_t ringbuffer_data_len(struct ringbuffer *rb)
{
    switch (ringbuffer_status(rb))
    {
        case RINGBUFFER_EMPTY:
            return 0;
        case RINGBUFFER_FULL:
            return rb->buffer_size;
        case RINGBUFFER_HALFFULL:
        default:
            if (rb->write_index > rb->read_index){
                return rb->write_index - rb->read_index;
            }
            else{
                return rb->buffer_size - (rb->read_index - rb->write_index);
            }
    };
}

/**
 * empty the rb
 */
void ringbuffer_reset(struct ringbuffer *rb)
{
    if (rb == NULL){
        return;
    }

    rb->read_mirror = 0;
    rb->read_index = 0;
    rb->write_mirror = 0;
    rb->write_index = 0;
}
