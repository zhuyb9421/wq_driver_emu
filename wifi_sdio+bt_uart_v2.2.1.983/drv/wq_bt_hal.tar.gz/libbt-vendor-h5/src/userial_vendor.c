/******************************************************************************
 *
 *  Copyright (C) 2009-2018 BT Corporation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at:
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 ******************************************************************************/

/******************************************************************************
 *
 *  Filename:      userial_vendor.c
 *
 *  Description:   Contains vendor-specific userial functions
 *
 ******************************************************************************/
#undef NDEBUG
#define LOG_TAG "bt_userial_vendor"

#include <utils/Log.h>
#include <termios.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <sys/eventfd.h>
#include "userial_vendor.h"
#include "bt_socket.h"
#include "btservice.h"
#include <cutils/sockets.h>
#include "bt_address.h"
#include "hci_socket_transport.h"
#include "wq_sco.h"

/******************************************************************************
**  Constants & Macros
******************************************************************************/

#ifndef VNDUSERIAL_DBG
#define VNDUSERIAL_DBG TRUE
#endif

#if (VNDUSERIAL_DBG == TRUE)
#define VNDUSERIALDBG(param, ...)    \
    {                                \
        ALOGD(param, ##__VA_ARGS__); \
    }
#else
#define VNDUSERIALDBG(param, ...) \
    {                             \
    }
#endif

#define VND_PORT_NAME_MAXLEN 256

/******************************************************************************
**  Extern functions
******************************************************************************/
extern char bt_transtype;
extern bool bt_capture_fw_log;
extern void Heartbeat_cleanup();
extern void Heartbeat_init();
extern int btservice_init();
extern bd_addr_t local_bd_addr;
extern bool bt_uart_dump;
extern bool sco_over_hci;

extern bool is_fw_log;
const int INVALID_FD = -1;
int hci_firmware_log_fd = INVALID_FD;

uint16_t fw_event_count = 0;
uint8_t segment = 0;
uint16_t fw_event_block = 0xFFFD;

/******************************************************************************
**  Local type definitions
******************************************************************************/
#if !defined(EFD_SEMAPHORE)
#define EFD_SEMAPHORE (1 << 0)
#endif

#define BT_DATA_RECEIVED 1
#define BT_DATA_SEND 0
struct bt_object_t
{
    int fd;               // the file descriptor to monitor for events.
    void *context;        // a context that's passed back to the *_ready functions..
    pthread_mutex_t lock; // protects the lifetime of this object and all variables.

    void (*read_ready)(void *context);  // function to call when the file descriptor becomes readable.
    void (*write_ready)(void *context); // function to call when the file descriptor becomes writeable.
};

/* vendor serial control block */
typedef struct
{
    int fd; /* fd to Bluetooth device */
    int uart_fd[2];
    int signal_fd[2];
    int epoll_fd;
    int cpoll_fd;
    int event_fd;
    struct termios termios; /* serial terminal of BT port */
    char port_name[VND_PORT_NAME_MAXLEN];
    pthread_t thread_socket_id;
    pthread_t thread_uart_id;
    pthread_t thread_coex_id;
    bool thread_running;

    RTB_QUEUE_HEAD *recv_data;
    RTB_QUEUE_HEAD *send_data;
    RTB_QUEUE_HEAD *data_order;
    volatile bool btdriver_state;
    bool hci_socket_active;
    bool initialized;
} vnd_userial_cb_t;


/******************************************************************************
**  Static functions
******************************************************************************/
static void h5_data_ready_cb(serial_data_type_t type, unsigned int total_length);
static uint16_t h5_int_transmit_data_cb(serial_data_type_t type, uint8_t *data, uint16_t length);
extern void btservice_destroyed();
extern void bt_vendor_cmd_to_fw(uint16_t opcode, uint8_t parameter_len, uint8_t *parameter, tINT_CMD_CBACK p_cback);
extern void bt_service_vendorcmd_hook(bt_service_data *btData, int client_sock);
/******************************************************************************
**  Static variables
******************************************************************************/
static vnd_userial_cb_t vnd_userial;
static pthread_mutex_t driver_fd_mutex = PTHREAD_MUTEX_INITIALIZER;
static const hci_h5_t *h5_int_interface;
static int packet_recv_state = BT_PACKET_IDLE;
static unsigned int packet_bytes_need = 0;
static serial_data_type_t current_type = 0;
static struct bt_object_t bt_socket_object;
static struct bt_object_t bt_coex_object;
static unsigned char h4_read_buffer[2048] = {0};
static int h4_read_length = 0;

static bool userial_hci_socket_active(void)
{
    return vnd_userial.hci_socket_active;
}

static int coex_packet_recv_state = BT_PACKET_IDLE;
static int coex_packet_bytes_need = 0;
static serial_data_type_t coex_current_type = 0;
static unsigned char coex_resvered_buffer[2048] = {0};
static int coex_resvered_length = 0;

#ifdef BT_HANDLE_EVENT
static int received_packet_state = BT_PACKET_IDLE;
static unsigned int received_packet_bytes_need = 0;
static serial_data_type_t recv_packet_current_type = 0;
static unsigned char received_resvered_data[2048] = {0};
static unsigned char *received_resvered_header = NULL;
static int received_resvered_length = 0;
static bt_version_t bt_version;
static bt_lescn_t bt_adv_con;
#endif

static bt_parse_manager_t *bt_parse_manager = NULL;

static hci_h5_callbacks_t h5_int_callbacks = {
    .h5_int_transmit_data_cb = h5_int_transmit_data_cb,
    .h5_data_ready_cb = h5_data_ready_cb,
};

static const uint8_t hci_preamble_sizes[] = {
    COMMAND_PREAMBLE_SIZE,
    ACL_PREAMBLE_SIZE,
    SCO_PREAMBLE_SIZE,
    EVENT_PREAMBLE_SIZE};

/*****************************************************************************
**   Helper Functions
*****************************************************************************/

/*******************************************************************************
**
** Function        userial_to_tcio_baud
**
** Description     helper function converts USERIAL baud rates into TCIO
**                  conforming baud rates
**
** Returns         TRUE/FALSE
**
*******************************************************************************/
uint8_t userial_to_tcio_baud(uint8_t cfg_baud, uint32_t *baud)
{
    if (cfg_baud == USERIAL_BAUD_115200)
        *baud = B115200;
    else if (cfg_baud == USERIAL_BAUD_4M)
        *baud = B4000000;
    else if (cfg_baud == USERIAL_BAUD_3M)
        *baud = B3000000;
    else if (cfg_baud == USERIAL_BAUD_2M)
        *baud = B2000000;
    else if (cfg_baud == USERIAL_BAUD_1M)
        *baud = B1000000;
    else if (cfg_baud == USERIAL_BAUD_1_5M)
        *baud = B1500000;
    else if (cfg_baud == USERIAL_BAUD_921600)
        *baud = B921600;
    else if (cfg_baud == USERIAL_BAUD_460800)
        *baud = B460800;
    else if (cfg_baud == USERIAL_BAUD_230400)
        *baud = B230400;
    else if (cfg_baud == USERIAL_BAUD_57600)
        *baud = B57600;
    else if (cfg_baud == USERIAL_BAUD_19200)
        *baud = B19200;
    else if (cfg_baud == USERIAL_BAUD_9600)
        *baud = B9600;
    else if (cfg_baud == USERIAL_BAUD_1200)
        *baud = B1200;
    else if (cfg_baud == USERIAL_BAUD_600)
        *baud = B600;
    else
    {
        ALOGE("userial vendor open: unsupported baud idx %i", cfg_baud);
        *baud = B115200;
        return FALSE;
    }
    ALOGI("userial vendor open: baud idx %i", cfg_baud);

    return TRUE;
}

static void dump_bytes(const char* prefix, uint8_t* data, int length)
{
    char buffer[1024];
    for(int i = 0; i < length && i < 1000/3; i++){
        snprintf(&buffer[i*3], 4, "%02x ", data[i]);
    }
    ALOGD("%s: %s", prefix, buffer);
}

#if (BT_WAKE_VIA_USERIAL_IOCTL == TRUE)
/*******************************************************************************
**
** Function        userial_ioctl_init_bt_wake
**
** Description     helper function to set the open state of the bt_wake if ioctl
**                  is used. it should not hurt in the rfkill case but it might
**                  be better to compile it out.
**
** Returns         none
**
*******************************************************************************/
void userial_ioctl_init_bt_wake(int fd)
{
    uint32_t bt_wake_state;

    /* assert BT_WAKE through ioctl */
    ioctl(fd, USERIAL_IOCTL_BT_WAKE_ASSERT, NULL);
    ioctl(fd, USERIAL_IOCTL_BT_WAKE_GET_ST, &bt_wake_state);
    VNDUSERIALDBG("userial_ioctl_init_bt_wake read back BT_WAKE state=%i",
                  bt_wake_state);
}
#endif // (BT_WAKE_VIA_USERIAL_IOCTL==TRUE)

/*****************************************************************************
**   Userial Vendor API Functions
*****************************************************************************/
static void userial_send_hw_error()
{
    unsigned char p_buf[100];
    int length;
    p_buf[0] = HCIT_TYPE_EVENT;                    // event
    p_buf[1] = HCI_VSE_SUBCODE_DEBUG_INFO_SUB_EVT; // firmwre event log
    p_buf[3] = 0x01;                               // host log opcode
    length = sprintf((char *)&p_buf[4], "host stack: userial error \n");
    p_buf[2] = length + 2; // len
    length = length + 1 + 4;
    userial_recv_rawdata_hook(p_buf, length);

    length = 4;
    p_buf[0] = HCIT_TYPE_EVENT;        // event
    p_buf[1] = HCI_HARDWARE_ERROR_EVT; // hardware error
    p_buf[2] = 0x01;                   // len
    p_buf[3] = USERIAL_HWERR_CODE;     // userial error code
    userial_recv_rawdata_hook(p_buf, length);
}

/*******************************************************************************
**
** Function        userial_vendor_init
**
** Description     Initialize userial vendor-specific control block
**
** Returns         None
**
*******************************************************************************/
void userial_vendor_init(char *bt_device_node)
{
#ifdef BT_HANDLE_EVENT

    memset(&bt_adv_con, 0, sizeof(bt_lescn_t));
#endif
    memset(&vnd_userial, 0, sizeof(vnd_userial_cb_t));
    vnd_userial.fd = -1;
    vnd_userial.hci_socket_active = false;
    vnd_userial.uart_fd[0] = -1;
    vnd_userial.uart_fd[1] = -1;
    vnd_userial.signal_fd[0] = -1;
    vnd_userial.signal_fd[1] = -1;
    vnd_userial.epoll_fd = -1;
    vnd_userial.cpoll_fd = -1;
    vnd_userial.event_fd = -1;
    vnd_userial.thread_socket_id = (pthread_t)-1;
    vnd_userial.thread_uart_id = (pthread_t)-1;
    vnd_userial.thread_coex_id = (pthread_t)-1;
    vnd_userial.initialized = true;
    char value[100];
    snprintf(vnd_userial.port_name, VND_PORT_NAME_MAXLEN, "%s",
             bt_device_node);
    if (bt_transtype & BT_TRANS_H5)
    {
        h5_int_interface = hci_get_h5_int_interface();
        h5_int_interface->h5_int_init(&h5_int_callbacks);
    }
    bt_parse_manager = NULL;
    property_get("persist.vendor.bluetooth.coex", value, "true");
    if (strncmp(value, "true", 4) == 0)
    {
        bt_parse_manager = bt_parse_manager_get_interface();
        bt_parse_manager->bt_parse_init();
    }
    vnd_userial.data_order = RtbQueueInit();
    vnd_userial.recv_data = RtbQueueInit();
    vnd_userial.send_data = RtbQueueInit();

    // reset coex gloable variables
    coex_packet_recv_state = BT_PACKET_IDLE;
    coex_packet_bytes_need = 0;
    coex_current_type = 0;
    coex_resvered_length = 0;

#ifdef BT_HANDLE_EVENT
    // reset handle event gloable variables
    received_packet_state = BT_PACKET_IDLE;
    received_packet_bytes_need = 0;
    recv_packet_current_type = 0;
    received_resvered_length = 0;
#endif

#ifdef CONFIG_SCO_OVER_HCI
    if(sco_over_hci) wq_sco_init();
#endif
}

/*******************************************************************************
**
** Function        userial_vendor_open
**
** Description     Open the serial port with the given configuration
**
** Returns         device fd
**
*******************************************************************************/
int userial_vendor_open(tUSERIAL_CFG *p_cfg)
{
    uint32_t baud;
    uint16_t parity;
    uint8_t stop_bits;

    vnd_userial.fd = -1;
    vnd_userial.hci_socket_active = false;

    if (hci_socket_transport_is_selected((uint8_t)bt_transtype))
    {
        vnd_userial.fd = hci_socket_transport_open(0, 3000);
        if (vnd_userial.fd == -1)
        {
            switch (errno)
            {
            case ENODEV:
                ALOGE("HCI socket: hci0 not found after 3000 ms");
                break;
            case EBUSY:
                ALOGE("HCI socket: hci0 is already up or being configured");
                break;
            case EUSERS:
                ALOGE("HCI socket: hci0 user channel is already owned");
                break;
            case EPERM:
            case EACCES:
                ALOGE("HCI socket: CAP_NET_ADMIN or SELinux permission denied");
                break;
            default:
                ALOGE("HCI socket: unable to bind hci0: %s", strerror(errno));
                break;
            }
            if (!hci_socket_transport_should_fallback(
                        (uint8_t)bt_transtype))
                return -1;

            ALOGW("HCI socket: falling back to TTY node %s",
                  vnd_userial.port_name);
        }
        else
        {
            vnd_userial.hci_socket_active = true;
            vnd_userial.btdriver_state = true;
            ALOGI("HCI socket fd=%d bound to hci0 user channel",
                  vnd_userial.fd);
            return vnd_userial.fd;
        }
    }

    if (!userial_to_tcio_baud(p_cfg->baud, &baud))
    {
        return -1;
    }

    if (p_cfg->fmt & USERIAL_PARITY_NONE)
        parity = 0;
    else if (p_cfg->fmt & USERIAL_PARITY_EVEN)
        parity = PARENB;
    else if (p_cfg->fmt & USERIAL_PARITY_ODD)
        parity = (PARENB | PARODD);
    else
    {
        ALOGE("userial vendor open: unsupported parity bit mode");
        return -1;
    }

    if (p_cfg->fmt & USERIAL_STOPBITS_1)
        stop_bits = 0;
    else if (p_cfg->fmt & USERIAL_STOPBITS_2)
        stop_bits = CSTOPB;
    else
    {
        ALOGE("userial vendor open: unsupported stop bits");
        return -1;
    }

    ALOGI("userial vendor open: opening %s", vnd_userial.port_name);

    if ((vnd_userial.fd = open(vnd_userial.port_name, O_RDWR | O_NOCTTY)) == -1)
    {
        ALOGE("userial vendor open: unable to open %s", vnd_userial.port_name);
        return -1;
    }

    tcflush(vnd_userial.fd, TCIOFLUSH);
    tcgetattr(vnd_userial.fd, &vnd_userial.termios);
    cfmakeraw(&vnd_userial.termios);

    if (p_cfg->hw_fctrl == USERIAL_HW_FLOW_CTRL_ON)
    {
        ALOGI("userial vendor open: with HW flowctrl ON");
        vnd_userial.termios.c_cflag |= (CRTSCTS | stop_bits | parity);
    }
    else
    {
        ALOGI("userial vendor open: with HW flowctrl OFF");
        vnd_userial.termios.c_cflag &= ~CRTSCTS;
        vnd_userial.termios.c_cflag |= (stop_bits | parity);
    }


    tcsetattr(vnd_userial.fd, TCSANOW, &vnd_userial.termios);
    tcflush(vnd_userial.fd, TCIOFLUSH);

    tcsetattr(vnd_userial.fd, TCSANOW, &vnd_userial.termios);
    tcflush(vnd_userial.fd, TCIOFLUSH);
    tcflush(vnd_userial.fd, TCIOFLUSH);

    /* set input/output baudrate */
    cfsetospeed(&vnd_userial.termios, baud);
    cfsetispeed(&vnd_userial.termios, baud);
    tcsetattr(vnd_userial.fd, TCSANOW, &vnd_userial.termios);

#if (BT_WAKE_VIA_USERIAL_IOCTL == TRUE)
    userial_ioctl_init_bt_wake(vnd_userial.fd);
#endif
    vnd_userial.btdriver_state = true;
    ALOGI("device fd = %d open", vnd_userial.fd);

    return vnd_userial.fd;
}

static void userial_driver_fd_close(void)
{
    int fd;

    pthread_mutex_lock(&driver_fd_mutex);
    fd = vnd_userial.fd;
    vnd_userial.fd = -1;
    vnd_userial.btdriver_state = false;
    pthread_mutex_unlock(&driver_fd_mutex);

    if (fd >= 0 && close(fd) < 0)
        ALOGE("%s fd=%d failed: %s", __func__, fd, strerror(errno));
}

static void userial_socket_close(void)
{
    int result;

    if (vnd_userial.epoll_fd >= 0 && vnd_userial.uart_fd[1] >= 0 &&
        epoll_ctl(vnd_userial.epoll_fd, EPOLL_CTL_DEL,
                  vnd_userial.uart_fd[1], NULL) == -1)
        ALOGE("%s unable to unregister fd %d from epoll set: %s", __func__, vnd_userial.uart_fd[1], strerror(errno));

    if (vnd_userial.epoll_fd >= 0 && vnd_userial.signal_fd[1] >= 0 &&
        epoll_ctl(vnd_userial.epoll_fd, EPOLL_CTL_DEL,
                  vnd_userial.signal_fd[1], NULL) == -1)
        ALOGE("%s unable to unregister signal fd %d from epoll set: %s", __func__, vnd_userial.signal_fd[1], strerror(errno));

    if (vnd_userial.uart_fd[0] >= 0)
    {
        result = close(vnd_userial.uart_fd[0]);
        if (result < 0)
            ALOGE("%s (fd:%d) FAILED result:%d", __func__, vnd_userial.uart_fd[0], result);
        vnd_userial.uart_fd[0] = -1;
    }

    if (vnd_userial.uart_fd[1] >= 0)
    {
        result = close(vnd_userial.uart_fd[1]);
        if (result < 0)
            ALOGE("%s (fd:%d) FAILED result:%d", __func__, vnd_userial.uart_fd[1], result);
        vnd_userial.uart_fd[1] = -1;
    }

    if (vnd_userial.thread_socket_id != (pthread_t)-1)
    {
        result = pthread_join(vnd_userial.thread_socket_id, NULL);
        if (result != 0)
            ALOGE("data thread pthread_join()  vnd_userial.thread_socket_id failed result:%d", result);
        else
        {
            vnd_userial.thread_socket_id = (pthread_t)-1;
            ALOGE("data thread pthread_join() vnd_userial.thread_socket_id pthread_join_success result:%d", result);
        }
    }

    if (vnd_userial.epoll_fd >= 0)
    {
        close(vnd_userial.epoll_fd);
        vnd_userial.epoll_fd = -1;
    }

    if (vnd_userial.signal_fd[0] >= 0)
    {
        result = close(vnd_userial.signal_fd[0]);
        if (result < 0)
            ALOGE("%s (signal fd[0]:%d) FAILED result:%d", __func__, vnd_userial.signal_fd[0], result);
        vnd_userial.signal_fd[0] = -1;
    }
    if (vnd_userial.signal_fd[1] >= 0)
    {
        result = close(vnd_userial.signal_fd[1]);
        if (result < 0)
            ALOGE("%s (signal fd[1]:%d) FAILED result:%d", __func__, vnd_userial.signal_fd[1], result);
        vnd_userial.signal_fd[1] = -1;
    }
}

static void userial_uart_close(void)
{
    userial_driver_fd_close();
    if (vnd_userial.thread_uart_id != (pthread_t)-1)
    {
        pthread_join(vnd_userial.thread_uart_id, NULL);
        vnd_userial.thread_uart_id = (pthread_t)-1;
    }
}

static void userial_coex_close(void)
{
    int result;

    if (vnd_userial.cpoll_fd >= 0 && vnd_userial.event_fd >= 0 &&
        epoll_ctl(vnd_userial.cpoll_fd, EPOLL_CTL_DEL,
                  vnd_userial.event_fd, NULL) == -1)
        ALOGE("%s unable to unregister fd %d from cpoll set: %s", __func__, vnd_userial.event_fd, strerror(errno));

    if (vnd_userial.cpoll_fd >= 0 && vnd_userial.signal_fd[1] >= 0 &&
        epoll_ctl(vnd_userial.cpoll_fd, EPOLL_CTL_DEL,
                  vnd_userial.signal_fd[1], NULL) == -1)
        ALOGE("%s unable to unregister fd %d from cpoll set: %s", __func__, vnd_userial.signal_fd[1], strerror(errno));

    if (vnd_userial.event_fd >= 0)
    {
        result = close(vnd_userial.event_fd);
        if (result < 0)
            ALOGE("%s (fd:%d) FAILED result:%d", __func__, vnd_userial.event_fd, result);
        vnd_userial.event_fd = -1;
    }

    if (vnd_userial.cpoll_fd >= 0)
    {
        close(vnd_userial.cpoll_fd);
        vnd_userial.cpoll_fd = -1;
    }
    if (vnd_userial.thread_coex_id != (pthread_t)-1)
    {
        if (pthread_join(vnd_userial.thread_coex_id, NULL) != 0)
        {
            ALOGE("%s vnd_userial.thread_coex_id  pthread_join_failed", __func__);
        }
        else
        {
            vnd_userial.thread_coex_id = (pthread_t)-1;
            ALOGE("%s vnd_userial.thread_coex_id  pthread_join_success", __func__);
        }
    }
}

void userial_send_close_signal(void)
{
    unsigned char close_signal = 1;
    ssize_t ret;
    if (vnd_userial.signal_fd[0] >= 0)
        BT_NO_INTR(ret = write(vnd_userial.signal_fd[0], &close_signal, 1));
}

void userial_quene_close(void)
{
#if 0
    int data_order_len = 0;
    int recv_data_len = 0;
    int send_data_len = 0;
    data_order_len = RtbGetQueueLen(vnd_userial.data_order);
    recv_data_len = RtbGetQueueLen(vnd_userial.recv_data);
    send_data_len = RtbGetQueueLen(vnd_userial.send_data);
    ALOGE( "%s data_order_len = %d,recv_data_len = %d ,send_data_len = %d", __func__,data_order_len,recv_data_len,send_data_len);
#endif
    if (vnd_userial.data_order)
    {
        RtbQueueFree(vnd_userial.data_order);
        vnd_userial.data_order = NULL;
    }
    if (vnd_userial.recv_data)
    {
        RtbQueueFree(vnd_userial.recv_data);
        vnd_userial.recv_data = NULL;
    }
    if (vnd_userial.send_data)
    {
        RtbQueueFree(vnd_userial.send_data);
        vnd_userial.send_data = NULL;
    }
}

/*******************************************************************************
**
** Function        userial_vendor_close
**
** Description     Conduct vendor-specific close work
**
** Returns         None
**
*******************************************************************************/
void userial_vendor_close(void)
{
    if (!vnd_userial.initialized)
        return;

    if ((bt_transtype & BT_TRANS_H5) && vnd_userial.fd >= 0)
    {
#if (BT_WAKE_VIA_USERIAL_IOCTL == TRUE)
        /* de-assert bt_wake BEFORE closing port */
        ioctl(vnd_userial.fd, USERIAL_IOCTL_BT_WAKE_DEASSERT, NULL);
#endif
        // h5_int_interface->h5_int_cleanup();
    }

    vnd_userial.thread_running = false;
#ifdef CONFIG_SCO_OVER_HCI
    if(sco_over_hci) wq_sco_deinit();
#endif
    Heartbeat_cleanup();
    btservice_destroyed();
    userial_send_close_signal();
    userial_uart_close();
    userial_coex_close();
    userial_socket_close();
    userial_quene_close();
    if (bt_transtype & BT_TRANS_H5)
    {
        h5_int_interface->h5_int_cleanup();
    }

    if (bt_parse_manager)
    {
        bt_parse_manager->bt_parse_cleanup();
    }
    bt_parse_manager = NULL;
    vnd_userial.initialized = false;
    ALOGD("%s finish", __func__);
}

/*******************************************************************************
**
** Function        userial_vendor_set_baud
**
** Description     Set new baud rate
**
** Returns         None
**
*******************************************************************************/
void userial_vendor_set_baud(uint8_t userial_baud)
{
    uint32_t tcio_baud;
    ALOGI("userial_vendor_set_baud");
    if (userial_hci_socket_active())
    {
        ALOGD("%s ignored for HCI socket transport", __func__);
        return;
    }
    userial_to_tcio_baud(userial_baud, &tcio_baud);

    if (cfsetospeed(&vnd_userial.termios, tcio_baud) < 0)
        ALOGE("cfsetospeed fail");

    if (cfsetispeed(&vnd_userial.termios, tcio_baud) < 0)
        ALOGE("cfsetispeed fail");

    if (tcsetattr(vnd_userial.fd, TCSANOW, &vnd_userial.termios) < 0)
        ALOGE("tcsetattr fail ");

    tcflush(vnd_userial.fd, TCIOFLUSH);
}

/*******************************************************************************
**
** Function        userial_vendor_ioctl
**
** Description     ioctl inteface
**
** Returns         None
**
*******************************************************************************/
void userial_vendor_ioctl(userial_vendor_ioctl_op_t op, void *p_data)
{
    BT_UNUSED(p_data);
    if (userial_hci_socket_active())
    {
        ALOGD("%s ignored for HCI socket transport", __func__);
        return;
    }
    switch (op)
    {
#if (BT_WAKE_VIA_USERIAL_IOCTL == TRUE)
    case USERIAL_OP_ASSERT_BT_WAKE:
        VNDUSERIALDBG("## userial_vendor_ioctl: Asserting BT_Wake ##");
        ioctl(vnd_userial.fd, USERIAL_IOCTL_BT_WAKE_ASSERT, NULL);
        break;

    case USERIAL_OP_DEASSERT_BT_WAKE:
        VNDUSERIALDBG("## userial_vendor_ioctl: De-asserting BT_Wake ##");
        ioctl(vnd_userial.fd, USERIAL_IOCTL_BT_WAKE_DEASSERT, NULL);
        break;

    case USERIAL_OP_GET_BT_WAKE_STATE:
        ioctl(vnd_userial.fd, USERIAL_IOCTL_BT_WAKE_GET_ST, p_data);
        break;
#endif //  (BT_WAKE_VIA_USERIAL_IOCTL==TRUE)

    default:
        break;
    }
}

/*******************************************************************************
**
** Function        userial_set_port
**
** Description     Configure UART port name
**
** Returns         0 : Success
**                 Otherwise : Fail
**
*******************************************************************************/
int userial_set_port(char *p_conf_name, char *p_conf_value, int param)
{
    BT_UNUSED(p_conf_name);
    BT_UNUSED(param);
    strcpy(vnd_userial.port_name, p_conf_value);

    return 0;
}

/*******************************************************************************
**
** Function        userial_vendor_set_hw_fctrl
**
** Description     Conduct vendor-specific close work
**
** Returns         None
**
*******************************************************************************/
void userial_vendor_set_hw_fctrl(uint8_t hw_fctrl)
{
    struct termios termios_old;

    if (userial_hci_socket_active())
    {
        ALOGD("%s ignored for HCI socket transport", __func__);
        return;
    }

    if (vnd_userial.fd == -1)
    {
        ALOGE("vnd_userial.fd is -1");
        return;
    }

    tcgetattr(vnd_userial.fd, &termios_old);
    if (hw_fctrl)
    {
        if (termios_old.c_cflag & CRTSCTS)
        {
            BTVNDDBG("userial_vendor_set_hw_fctrl already hw flowcontrol on");
            return;
        }
        else
        {
            termios_old.c_cflag |= CRTSCTS;
            tcsetattr(vnd_userial.fd, TCSANOW, &termios_old);
            BTVNDDBG("userial_vendor_set_hw_fctrl set hw flowcontrol on");
        }
    }
    else
    {
        if (termios_old.c_cflag & CRTSCTS)
        {
            termios_old.c_cflag &= ~CRTSCTS;
            tcsetattr(vnd_userial.fd, TCSANOW, &termios_old);
            return;
        }
        else
        {
            ALOGI("userial_vendor_set_hw_fctrl set hw flowcontrol off");
            return;
        }
    }
}

static uint16_t h4_int_transmit_data(uint8_t *data, uint16_t total_length)
{
    assert(data != NULL);
    assert(total_length > 0);

    static pthread_mutex_t h4_tx_mutex = PTHREAD_MUTEX_INITIALIZER;

    pthread_mutex_lock(&h4_tx_mutex);

    if (userial_hci_socket_active())
    {
        ssize_t result = hci_socket_transport_write_packet(
                vnd_userial.fd, data, total_length);
        if (result == -1)
        {
            ALOGE("%s: HCI socket packet write failed: %s",
                  __func__, strerror(errno));
            pthread_mutex_unlock(&h4_tx_mutex);
            return 0;
        }
        if (bt_uart_dump)
            dump_bytes("write", data, total_length);
        pthread_mutex_unlock(&h4_tx_mutex);
        return (uint16_t)result;
    }

    uint16_t length = total_length;
    uint16_t transmitted_length = 0;
    while (length > 0 && vnd_userial.btdriver_state)
    {
        ssize_t ret = write(vnd_userial.fd, data + transmitted_length, length);

        if(bt_uart_dump) dump_bytes("write", data + transmitted_length, length);

        switch (ret)
        {
        case -1:
            ALOGE("In %s, error writing to the uart serial port: %s", __func__, strerror(errno));
            goto done;
        case 0:
            // If we wrote nothing, don't loop more because we
            // can't go to infinity or beyond, ohterwise H5 can resend data
            ALOGE("%s, ret %zd", __func__, ret);
            goto done;
        default:
            transmitted_length += ret;
            length -= ret;
            break;
        }
    }

done:
    pthread_mutex_unlock(&h4_tx_mutex);
    return transmitted_length;
}

static void userial_enqueue_coex_rawdata(unsigned char *buffer, int length, bool is_recved)
{
    BT_BUFFER *skb_data = RtbAllocate(length, 0);
    BT_BUFFER *skb_type = RtbAllocate(1, 0);
    memcpy(skb_data->Data, buffer, length);
    skb_data->Length = length;
    if (is_recved)
    {
        *skb_type->Data = BT_DATA_RECEIVED;
        skb_type->Length = 1;
        RtbQueueTail(vnd_userial.recv_data, skb_data);
        RtbQueueTail(vnd_userial.data_order, skb_type);
    }
    else
    {
        *skb_type->Data = BT_DATA_SEND;
        skb_type->Length = 1;
        RtbQueueTail(vnd_userial.send_data, skb_data);
        RtbQueueTail(vnd_userial.data_order, skb_type);
    }

    if (eventfd_write(vnd_userial.event_fd, 1) == -1)
    {
        ALOGE("%s unable to write for coex event fd.", __func__);
    }
}

static void userial_send_acl_to_controller(unsigned char *recv_buffer, int total_length)
{
    if (bt_transtype & BT_TRANS_H4)
    {
        h4_int_transmit_data(recv_buffer, total_length);
    }
    else
    {
        h5_int_interface->h5_send_acl_data(DATA_TYPE_ACL, &recv_buffer[1], (total_length - 1));
    }
    userial_enqueue_coex_rawdata(recv_buffer, total_length, false);
}

void userial_send_sco_to_controller(unsigned char *recv_buffer, int total_length)
{
    if (bt_transtype & BT_TRANS_H4)
    {
        h4_int_transmit_data(recv_buffer, total_length);
    }
    else
    {
        h5_int_interface->h5_send_sco_data(DATA_TYPE_SCO, &recv_buffer[1], (total_length - 1));
    }
    userial_enqueue_coex_rawdata(recv_buffer, total_length, false);
}

static int userial_coex_recv_data_handler(unsigned char *recv_buffer, int total_length)
{
    serial_data_type_t type = 0;
    unsigned char *p_data = recv_buffer;
    int length = total_length;
    HC_BT_HDR *p_buf;
    uint8_t boundary_flag;
    uint16_t len, handle, acl_length, l2cap_length;
    switch (coex_packet_recv_state)
    {
    case BT_PACKET_IDLE:
        coex_packet_bytes_need = 1;
        while (length)
        {
            type = p_data[0];
            length--;
            p_data++;
            assert((type > DATA_TYPE_COMMAND) && (type <= DATA_TYPE_EVENT));
            if (type < DATA_TYPE_ACL || type > DATA_TYPE_EVENT)
            {
                ALOGE("%s invalid data type: %d", __func__, type);
                if (!length)
                    return total_length;

                continue;
            }
            break;
        }
        coex_current_type = type;
        coex_packet_recv_state = BT_PACKET_TYPE;
        // fall through

    case BT_PACKET_TYPE:
        if (coex_current_type == DATA_TYPE_ACL)
        {
            coex_packet_bytes_need = 4;
        }
        else if (coex_current_type == DATA_TYPE_EVENT)
        {
            coex_packet_bytes_need = 2;
        }
        else
        {
            coex_packet_bytes_need = 3;
        }
        coex_resvered_length = 0;
        coex_packet_recv_state = BT_PACKET_HEADER;
        // fall through

    case BT_PACKET_HEADER:
        if (length >= coex_packet_bytes_need)
        {
            memcpy(&coex_resvered_buffer[coex_resvered_length], p_data, coex_packet_bytes_need);
            coex_resvered_length += coex_packet_bytes_need;
            length -= coex_packet_bytes_need;
            p_data += coex_packet_bytes_need;
        }
        else
        {
            memcpy(&coex_resvered_buffer[coex_resvered_length], p_data, length);
            coex_resvered_length += length;
            coex_packet_bytes_need -= length;
            length = 0;
            return total_length;
        }
        coex_packet_recv_state = BT_PACKET_CONTENT;

        if (coex_current_type == DATA_TYPE_ACL)
        {
            coex_packet_bytes_need = *(uint16_t *)&coex_resvered_buffer[2];
        }
        else if (coex_current_type == DATA_TYPE_EVENT)
        {
            coex_packet_bytes_need = coex_resvered_buffer[1];
        }
        else
        {
            coex_packet_bytes_need = coex_resvered_buffer[2];
        }
        // fall through

    case BT_PACKET_CONTENT:
        if (length >= coex_packet_bytes_need)
        {
            memcpy(&coex_resvered_buffer[coex_resvered_length], p_data, coex_packet_bytes_need);
            length -= coex_packet_bytes_need;
            p_data += coex_packet_bytes_need;
            coex_resvered_length += coex_packet_bytes_need;
            coex_packet_bytes_need = 0;
        }
        else
        {
            memcpy(&coex_resvered_buffer[coex_resvered_length], p_data, length);
            coex_resvered_length += length;
            coex_packet_bytes_need -= length;
            length = 0;
            return total_length;
        }
        coex_packet_recv_state = BT_PACKET_END;
        // fall through

    case BT_PACKET_END:
    {
        len = BT_HC_HDR_SIZE + coex_resvered_length;
        uint8_t packet[len];
        p_buf = (HC_BT_HDR *)packet;
        p_buf->offset = 0;
        p_buf->layer_specific = 0;
        p_buf->len = coex_resvered_length;
        memcpy((uint8_t *)(p_buf + 1), coex_resvered_buffer, coex_resvered_length);
        switch (coex_current_type)
        {
        case DATA_TYPE_EVENT:
            p_buf->event = MSG_HC_TO_STACK_HCI_EVT;
            if (bt_parse_manager)
            {
                bt_parse_manager->bt_parse_internal_event_intercept(coex_resvered_buffer);
            }
            uint8_t *p_data = coex_resvered_buffer;
            uint8_t event = p_data[0];
            switch (event)
            {
            case HCI_COMMAND_COMPLETE_EVT:
            {
                uint16_t opcode = *((uint16_t *)&p_data[3]);
                ALOGI("%s opcode %x", __func__, opcode);
                break;
            }
            default:
                break;
            }
            break;

        case DATA_TYPE_ACL:
            p_buf->event = MSG_HC_TO_STACK_HCI_ACL;
            handle = *(uint16_t *)coex_resvered_buffer;
            acl_length = *(uint16_t *)&coex_resvered_buffer[2];
            l2cap_length = *(uint16_t *)&coex_resvered_buffer[4];
            boundary_flag = BT_GET_BOUNDARY_FLAG(handle);
            break;

        case DATA_TYPE_SCO:
            p_buf->event = MSG_HC_TO_STACK_HCI_SCO;
            break;

        default:
            p_buf->event = MSG_HC_TO_STACK_HCI_ERR;
            break;
        }
        if (!is_fw_log)
            btsnoop_capture(p_buf, true);
        else
        {
            is_fw_log = FALSE;
            fw_event_count++;
            if (hci_firmware_log_fd == INVALID_FD)
            {
                hci_firmware_log_fd = hci_open_firmware_log_file(segment);
                segment++;
            }
            else if (fw_event_count > fw_event_block)
            {
                fw_event_count = 0;
                ALOGD("%s seg = %d open new file ", __func__, segment);
                hci_close_firmware_log_file(hci_firmware_log_fd);
                hci_firmware_log_fd = hci_open_firmware_log_file(segment);
                segment++;
            }
            if (hci_firmware_log_fd != INVALID_FD)
                hci_log_firmware_debug_packet(hci_firmware_log_fd, p_buf);
        }
    }
    break;

    default:

        break;
    }

    coex_packet_recv_state = BT_PACKET_IDLE;
    coex_packet_bytes_need = 0;
    coex_current_type = 0;
    coex_resvered_length = 0;

    return (total_length - length);
}

static void userial_coex_send_data_handler(unsigned char *send_buffer, int total_length)
{
    serial_data_type_t type = 0;
    type = send_buffer[0];
    int length = total_length;
    HC_BT_HDR *p_buf;
    uint8_t boundary_flag;
    uint16_t len, handle, acl_length, l2cap_length;

    len = BT_HC_HDR_SIZE + (length - 1);
    uint8_t packet[len];
    p_buf = (HC_BT_HDR *)packet;
    p_buf->offset = 0;
    p_buf->layer_specific = 0;
    p_buf->len = total_length - 1;
    memcpy((uint8_t *)(p_buf + 1), &send_buffer[1], length - 1);

    switch (type)
    {
    case DATA_TYPE_COMMAND:
        p_buf->event = MSG_STACK_TO_HC_HCI_CMD;
        break;

    case DATA_TYPE_ACL:
        p_buf->event = MSG_STACK_TO_HC_HCI_ACL;
        handle = *(uint16_t *)&send_buffer[1];
        acl_length = *(uint16_t *)&send_buffer[3];
        l2cap_length = *(uint16_t *)&send_buffer[5];
        boundary_flag = BT_GET_BOUNDARY_FLAG(handle);
        break;

    case DATA_TYPE_SCO:
        p_buf->event = MSG_STACK_TO_HC_HCI_SCO;
        break;
    default:
        p_buf->event = 0;
        ALOGE("%s invalid data type: %d", __func__, type);
        break;
    }
    btsnoop_capture(p_buf, false);
}

static void userial_coex_handler(void *context)
{
    BT_UNUSED(context);
    BT_BUFFER *skb_data;
    BT_BUFFER *skb_type;
    eventfd_t value;
    unsigned int read_length = 0;
    eventfd_read(vnd_userial.event_fd, &value);
    if (!value && !vnd_userial.thread_running)
    {
        return;
    }

    while (!RtbQueueIsEmpty(vnd_userial.data_order))
    {
        read_length = 0;
        skb_type = RtbDequeueHead(vnd_userial.data_order);
        if (skb_type)
        {
            if (*(skb_type->Data) == BT_DATA_RECEIVED)
            {
                skb_data = RtbDequeueHead(vnd_userial.recv_data);
                if (skb_data)
                {
                    do
                    {
                        read_length += userial_coex_recv_data_handler((skb_data->Data + read_length), (skb_data->Length - read_length));
                    } while (read_length < skb_data->Length);
                    RtbFree(skb_data);
                }
            }
            else
            {
                skb_data = RtbDequeueHead(vnd_userial.send_data);
                if (skb_data)
                {
                    userial_coex_send_data_handler(skb_data->Data, skb_data->Length);
                    RtbFree(skb_data);
                }
            }

            RtbFree(skb_type);
        }
    }
}

#ifdef BT_HANDLE_CMD
static int userial_handle_cmd(unsigned char *recv_buffer, int total_length)
{
    BT_UNUSED(total_length);
    uint16_t opcode = *(uint16_t *)recv_buffer;
    switch (opcode)
    {
    case HCI_SET_EVENT_MASK:
        ALOGE("set event mask, it should bt stack init, set coex bt on");
        Heartbeat_init();
        break;
    default:
        break;
    }

    return 0;
}
#endif

// This recv data from bt process. The data type only have ACL/SCO/COMMAND
//  direction  BT HOST ----> CONTROLLER
static void userial_recv_H4_rawdata(void *context)
{
    BT_UNUSED(context);
    serial_data_type_t type = 0;
    ssize_t bytes_read;
    uint16_t opcode;
    uint16_t transmitted_length = 0;
    // unsigned char *buffer = NULL;

    switch (packet_recv_state)
    {
    case BT_PACKET_IDLE:
        packet_bytes_need = 1;
        do
        {
            BT_NO_INTR(bytes_read = read(vnd_userial.uart_fd[1], &type, 1));

            if(bt_uart_dump) if(bytes_read > 0) dump_bytes("hci_rx", (uint8_t*)&type, 1);

            if (bytes_read == -1)
            {
                ALOGE("%s, state = %d, read error %s", __func__, packet_recv_state, strerror(errno));
                return;
            }
            if (!bytes_read && packet_bytes_need)
            {
                ALOGE("%s, state = %d, bytes_read 0", __func__, packet_recv_state);
                return;
            }

            if (type < DATA_TYPE_COMMAND || type > DATA_TYPE_SCO)
            {
                ALOGE("%s invalid data type: %d", __func__, type);
                assert((type >= DATA_TYPE_COMMAND) && (type <= DATA_TYPE_SCO));
            }
            else
            {
                packet_bytes_need -= bytes_read;
                packet_recv_state = BT_PACKET_TYPE;
                current_type = type;
                h4_read_buffer[0] = type;
            }
        } while (packet_bytes_need);
        // fall through

    case BT_PACKET_TYPE:
        packet_bytes_need = hci_preamble_sizes[HCI_PACKET_TYPE_TO_INDEX(current_type)];
        h4_read_length = 0;
        packet_recv_state = BT_PACKET_HEADER;
        // fall through

    case BT_PACKET_HEADER:
        do
        {
            BT_NO_INTR(bytes_read = read(vnd_userial.uart_fd[1], &h4_read_buffer[h4_read_length + 1], packet_bytes_need));

            if(bt_uart_dump) if(bytes_read > 0) dump_bytes("hci_rx", &h4_read_buffer[h4_read_length + 1], bytes_read);

            if (bytes_read == -1)
            {
                ALOGE("%s, state = %d, read error %s", __func__, packet_recv_state, strerror(errno));
                return;
            }
            if (!bytes_read && packet_bytes_need)
            {
                ALOGE("%s, state = %d, bytes_read 0, type : %d", __func__, packet_recv_state, current_type);
                return;
            }
            packet_bytes_need -= bytes_read;
            h4_read_length += bytes_read;
        } while (packet_bytes_need);
        packet_recv_state = BT_PACKET_CONTENT;

        if (current_type == DATA_TYPE_ACL)
        {
            packet_bytes_need = *(uint16_t *)&h4_read_buffer[COMMON_DATA_LENGTH_INDEX];
        }
        else if (current_type == DATA_TYPE_EVENT)
        {
            packet_bytes_need = h4_read_buffer[EVENT_DATA_LENGTH_INDEX];
        }
        else
        {
            packet_bytes_need = h4_read_buffer[COMMON_DATA_LENGTH_INDEX];
        }
        // fall through

    case BT_PACKET_CONTENT:
        while (packet_bytes_need)
        {
            BT_NO_INTR(bytes_read = read(vnd_userial.uart_fd[1], &h4_read_buffer[h4_read_length + 1], packet_bytes_need));

            if(bt_uart_dump) if(bytes_read > 0) dump_bytes("hci_rx", &h4_read_buffer[h4_read_length + 1], bytes_read);

            if (bytes_read == -1)
            {
                ALOGE("%s, state = %d, read error %s", __func__, packet_recv_state, strerror(errno));
                return;
            }
            if (!bytes_read)
            {
                ALOGE("%s, state = %d, bytes_read 0", __func__, packet_recv_state);
                return;
            }

            packet_bytes_need -= bytes_read;
            h4_read_length += bytes_read;
        }
        packet_recv_state = BT_PACKET_END;
        // fall through

    case BT_PACKET_END:
        switch (current_type)
        {
        case DATA_TYPE_COMMAND:
#ifdef BT_HANDLE_CMD
            userial_handle_cmd(&h4_read_buffer[1], h4_read_length);
#endif
#ifdef CONFIG_SCO_OVER_HCI
            if(sco_over_hci) wq_sco_handle_cmd(&h4_read_buffer[1], h4_read_length);
#endif
            if (bt_transtype & BT_TRANS_H4)
            {
                h4_int_transmit_data(h4_read_buffer, (h4_read_length + 1));
            }
            else
            {
                opcode = *(uint16_t *)&h4_read_buffer[1];
                if (opcode == HCI_VSC_H5_INIT)
                {
                    h5_int_interface->h5_send_sync_cmd(opcode, NULL, h4_read_length);
                }
                else
                {
                    transmitted_length = h5_int_interface->h5_send_cmd(type, &h4_read_buffer[1], h4_read_length);
                }
            }
            userial_enqueue_coex_rawdata(h4_read_buffer, (h4_read_length + 1), false);
            break;

        case DATA_TYPE_ACL:
            userial_send_acl_to_controller(h4_read_buffer, (h4_read_length + 1));
            break;

        case DATA_TYPE_SCO:
            userial_send_sco_to_controller(h4_read_buffer, (h4_read_length + 1));
            break;
        default:
            ALOGE("%s invalid data type: %d", __func__, current_type);
            userial_enqueue_coex_rawdata(h4_read_buffer, (h4_read_length + 1), false);
            break;
        }
        break;

    default:

        break;
    }

    packet_recv_state = BT_PACKET_IDLE;
    packet_bytes_need = 0;
    current_type = 0;
    h4_read_length = 0;
}

static uint16_t h5_int_transmit_data_cb(serial_data_type_t type, uint8_t *data, uint16_t length)
{
    assert(data != NULL);
    assert(length > 0);

    if (type != DATA_TYPE_H5)
    {
        ALOGE("%s invalid data type: %d", __func__, type);
        return 0;
    }

    uint16_t transmitted_length = 0;
    while (length > 0 && vnd_userial.btdriver_state)
    {
        ssize_t ret = write(vnd_userial.fd, data + transmitted_length, length);

        if(bt_uart_dump) dump_bytes("write", data + transmitted_length, length);

        switch (ret)
        {
        case -1:
            ALOGE("In %s, error writing to the uart serial port: %s", __func__, strerror(errno));
            goto done;
        case 0:
            // If we wrote nothing, don't loop more because we
            // can't go to infinity or beyond, ohterwise H5 can resend data
            ALOGE("%s, ret %zd", __func__, ret);
            goto done;
        default:
            transmitted_length += ret;
            length -= ret;
            break;
        }
    }

done:
    return transmitted_length;
}

#ifdef BT_HANDLE_EVENT
static int userial_handle_event(unsigned char *recv_buffer, int total_length)
{
    BT_UNUSED(total_length);
    uint8_t event;
    uint8_t *p_data = recv_buffer;
    event = p_data[0];

    switch (event)
    {
    case HCI_COMMAND_COMPLETE_EVT:
    {
        uint16_t opcode = *((uint16_t *)&p_data[3]);
        uint8_t *stream = &p_data[6];
        if (opcode == HCI_READ_LOCAL_VERSION_INFO)
        {
            STREAM_TO_UINT8(bt_version.hci_version, stream);
            STREAM_TO_UINT16(bt_version.hci_revision, stream);
            STREAM_TO_UINT8(bt_version.lmp_version, stream);
            STREAM_TO_UINT16(bt_version.manufacturer, stream);
            STREAM_TO_UINT16(bt_version.lmp_subversion, stream);
        }
        else if (opcode == HCI_BLE_WRITE_ADV_ENABLE)
        {
            if (bt_version.hci_version > HCI_PROTO_VERSION_4_2)
            {
                break;
            }
            if (bt_adv_con.adverting_start && (p_data[5] == HCI_SUCCESS))
            {
                bt_adv_con.adverting_enable = TRUE;
                bt_adv_con.adverting_start = FALSE;
            }
        }
    }
    break;
    default:
        break;
    }

    return 0;
}

static int userial_handle_recv_data(unsigned char *recv_buffer, unsigned int total_length)
{
    serial_data_type_t type = 0;
    unsigned char *p_data = recv_buffer;
    unsigned int length = total_length;
    uint8_t event;
    int ret = 0;

    if (!length)
    {
        ALOGE("%s, length is 0, return immediately", __func__);
        return total_length;
    }
    switch (received_packet_state)
    {
    case BT_PACKET_IDLE:
        received_packet_bytes_need = 1;
        received_resvered_header = &received_resvered_data[1];
        while (length)
        {
            type = p_data[0];
            length--;
            p_data++;
            if (type < DATA_TYPE_ACL || type > DATA_TYPE_EVENT)
            {
                ALOGE("%s invalid data type: %d", __func__, type);
                assert((type > DATA_TYPE_COMMAND) && (type <= DATA_TYPE_EVENT));
                if (!length)
                {
                    ALOGE("%s, IDLE length %d", __func__, total_length);
                    return total_length;
                }

                continue;
            }
            break;
        }
        recv_packet_current_type = type;
        received_resvered_data[0] = type;
        received_packet_state = BT_PACKET_TYPE;
        // fall through

    case BT_PACKET_TYPE:
        received_packet_bytes_need = hci_preamble_sizes[HCI_PACKET_TYPE_TO_INDEX(recv_packet_current_type)];
        received_resvered_length = 0;
        received_packet_state = BT_PACKET_HEADER;
        // fall through

    case BT_PACKET_HEADER:
        if (length >= received_packet_bytes_need)
        {
            memcpy(&received_resvered_header[received_resvered_length], p_data, received_packet_bytes_need);
            received_resvered_length += received_packet_bytes_need;
            length -= received_packet_bytes_need;
            p_data += received_packet_bytes_need;
        }
        else
        {
            memcpy(&received_resvered_header[received_resvered_length], p_data, length);
            received_resvered_length += length;
            received_packet_bytes_need -= length;
            length = 0;
            //ALOGE("%s, HEADER length %d", __func__, total_length);
            return total_length;
        }
        received_packet_state = BT_PACKET_CONTENT;

        if (recv_packet_current_type == DATA_TYPE_ACL)
        {
            received_packet_bytes_need = *(uint16_t *)&received_resvered_header[2];
        }
        else if (recv_packet_current_type == DATA_TYPE_EVENT)
        {
            received_packet_bytes_need = received_resvered_header[1];
        }
        else
        {
            received_packet_bytes_need = received_resvered_header[2];
        }
        // fall through

    case BT_PACKET_CONTENT:
        BT_UNUSED(event);
#if 0
        if (recv_packet_current_type == DATA_TYPE_EVENT)
        {
            event = received_resvered_header[0];

            if (event == HCI_COMMAND_COMPLETE_EVT)
            {
                if (received_resvered_length == 2)
                {
                    if (length >= 1)
                    {
                        *p_data = 1;
                    }
                }
            }
            else if (event == HCI_COMMAND_STATUS_EVT)
            {
                if (received_resvered_length < 4)
                {
                    unsigned int act_len = 4 - received_resvered_length;
                    if (length >= act_len)
                    {
                        *(p_data + act_len - 1) = 1;
                    }
                }
            }
        }
#endif
        if (length >= received_packet_bytes_need)
        {
            memcpy(&received_resvered_header[received_resvered_length], p_data, received_packet_bytes_need);
            length -= received_packet_bytes_need;
            p_data += received_packet_bytes_need;
            received_resvered_length += received_packet_bytes_need;
            received_packet_bytes_need = 0;
        }
        else
        {
            memcpy(&received_resvered_header[received_resvered_length], p_data, length);
            received_resvered_length += length;
            received_packet_bytes_need -= length;
            length = 0;
            //ALOGE("%s, CONTENT length %d", __func__, total_length);
            return total_length;
        }
        received_packet_state = BT_PACKET_END;
        // fall through

    case BT_PACKET_END:
        switch (recv_packet_current_type)
        {
        case DATA_TYPE_EVENT:
            userial_handle_event(received_resvered_header, received_resvered_length);
#ifdef CONFIG_SCO_OVER_HCI
            if(sco_over_hci) wq_sco_handle_event(received_resvered_header, received_resvered_length);
#endif
            break;
        case DATA_TYPE_SCO:
#ifdef CONFIG_SCO_OVER_HCI
            if(sco_over_hci) wq_sco_recv_sco_data(received_resvered_header, received_resvered_length);
#endif
            break;
        default:

            break;
        }
        break;

    default:

        break;
    }
    int send_length = received_resvered_length + 1;
    uint16_t transmitted_length = 0;

    received_packet_state = BT_PACKET_IDLE;
    received_packet_bytes_need = 0;
    recv_packet_current_type = 0;
    received_resvered_length = 0;
    received_resvered_header = NULL;

    if (ret > 0)
    {
        ALOGE("%s, total_length - length %d", __func__, total_length - length);
        return (total_length - length);
    }

    if(received_resvered_data[0] == DATA_TYPE_SCO)
    {
        return (total_length - length);
    }

    if ((received_resvered_data[0] == DATA_TYPE_ACL) && (*(uint16_t *)&received_resvered_data[3] == 0))
    {
        ALOGE("%s received 0 len ACL data packet, discard", __func__);
        return (total_length - length);
    }

    if ((received_resvered_data[0] == DATA_TYPE_EVENT) && (received_resvered_data[1] == 0xFF) && (received_resvered_data[2] == 2) && (received_resvered_data[3] == 0x61))
    {
        ALOGE("%s received 0xFF event subev:0x61 success(1) or failed(0) parse fw&config=%d, discard.", __func__, received_resvered_data[4]);
        return (total_length - length);
    }

    while (send_length > 0)
    {
        BT_NO_INTR(ret = write(vnd_userial.uart_fd[1], received_resvered_data + transmitted_length, send_length));

        if(bt_uart_dump) dump_bytes("hci_tx", received_resvered_data + transmitted_length, send_length);

        if (ret == -1)
        {
            ALOGE("In %s, error writing to the uart serial port: %s", __func__, strerror(errno));
            break;
        }
        else if (ret == 0)
        {
            // If we wrote nothing, don't loop more because we
            // can't go to infinity or beyond
            break;
        }
        else
        {
            transmitted_length += ret;
            send_length -= ret;
        }
    }

    return (total_length - length);
}
#endif

static void h5_data_ready_cb(serial_data_type_t type, unsigned int total_length)
{
    unsigned char buffer[1028] = {0};
    int length = 0;
    length = h5_int_interface->h5_int_read_data(&buffer[1], total_length);

    //ALOGE("%s", __func__);
    if (length == -1)
    {
        ALOGE("%s, error read length", __func__);
        assert(length != -1);
    }
    buffer[0] = type;
    length++;
    unsigned int real_length = length;
#ifdef BT_HANDLE_EVENT
    unsigned int read_length = 0;
    do
    {
        read_length += userial_handle_recv_data(buffer + read_length, real_length - read_length);
    } while (vnd_userial.thread_running && read_length < total_length);
#endif

    if (real_length)
        userial_enqueue_coex_rawdata(buffer, real_length, true);
    return;
}

// This recv data from driver which is sent or recv by the controller. The data type have ACL/SCO/EVENT
//  direction CONTROLLER -----> BT HOST
static void userial_recv_uart_rawdata(unsigned char *buffer, unsigned int total_length)
{
#ifdef BT_HANDLE_EVENT
    unsigned int read_length = 0;
    do
    {
        read_length += userial_handle_recv_data(buffer + read_length, total_length - read_length);
    } while (read_length < total_length);
#endif
    if (total_length)
        userial_enqueue_coex_rawdata(buffer, total_length, true);
    return;
}

void userial_recv_rawdata_hook(unsigned char *buffer, unsigned int total_length)
{
    uint16_t transmitted_length = 0;
    unsigned int real_length = total_length;

    while (vnd_userial.thread_running && (total_length > 0))
    {
        ssize_t ret;
        BT_NO_INTR(ret = write(vnd_userial.uart_fd[1], buffer + transmitted_length, total_length));

        if(bt_uart_dump) dump_bytes("hci_tx", buffer + transmitted_length, total_length);

        switch (ret)
        {
        case -1:
            ALOGE("In %s, error writing to the uart serial port: %s", __func__, strerror(errno));
            goto done;
        case 0:
            // If we wrote nothing, don't loop more because we
            // can't go to infinity or beyond
            goto done;
        default:
            transmitted_length += ret;
            total_length -= ret;
            break;
        }
    }
done:;
    if (real_length && vnd_userial.thread_running)
        userial_enqueue_coex_rawdata(buffer, real_length, true);
    return;
}

static void *userial_recv_socket_thread(void *arg)
{
    BT_UNUSED(arg);
    struct epoll_event events[64] = {{0}};
    int j;
    while (vnd_userial.thread_running)
    {
        int ret;
        do
        {
            ret = epoll_wait(vnd_userial.epoll_fd, events, 32, 500);
        } while (vnd_userial.thread_running && ret == -1 && errno == EINTR);

        if (ret == -1)
        {
            ALOGE("%s error in epoll_wait: %s", __func__, strerror(errno));
        }
        for (j = 0; j < ret; ++j)
        {
            struct bt_object_t *object = (struct bt_object_t *)events[j].data.ptr;
            if (events[j].data.ptr == NULL)
                continue;
            else
            {
                if (events[j].events & (EPOLLIN | EPOLLHUP | EPOLLRDHUP | EPOLLERR) && object->read_ready)
                    object->read_ready(object->context);
                if (events[j].events & EPOLLOUT && object->write_ready)
                    object->write_ready(object->context);
            }
        }
    }
    // vnd_userial.thread_socket_id = -1;
    ALOGD("%s exit", __func__);
    return NULL;
}

static void *userial_recv_uart_thread(void *arg)
{
    BT_UNUSED(arg);
    struct pollfd pfd[2] = {0};
    pfd[0].events = POLLIN | POLLHUP | POLLERR | POLLRDHUP;
    pfd[0].fd = vnd_userial.signal_fd[1];
    pfd[1].events = POLLIN | POLLHUP | POLLERR | POLLRDHUP;
    pfd[1].fd = vnd_userial.fd;
    int ret;
    unsigned char read_buffer[2056] = {0};
    ssize_t bytes_read;
    while (vnd_userial.thread_running)
    {
        do
        {
            ret = poll(pfd, 2, 500);
        } while (ret == -1 && errno == EINTR && vnd_userial.thread_running);

        // exit signal is always at first index
        if (pfd[0].revents && !vnd_userial.thread_running)
        {
            ALOGE("receive exit signal and stop thread ");
            return NULL;
        }

        if (pfd[1].revents & POLLIN)
        {
            BT_NO_INTR(bytes_read = read(vnd_userial.fd, read_buffer, sizeof(read_buffer)));

            if(bt_uart_dump) if(bytes_read > 0) dump_bytes("read", read_buffer, bytes_read);

            if (!bytes_read) continue;
            if (bytes_read < 0)
            {
                ALOGE("%s, read fail, error : %s", __func__, strerror(errno));
                continue;
            }

            if (bt_transtype & BT_TRANS_H5)
            {
                h5_int_interface->h5_recv_msg(read_buffer, bytes_read);
            }
            else
            {
                userial_recv_uart_rawdata(read_buffer, bytes_read);
            }
        }

        if (pfd[1].revents & (POLLERR | POLLHUP))
        {
            ALOGE("%s poll error, fd : %d", __func__, vnd_userial.fd);
            userial_driver_fd_close();
            userial_send_hw_error();
            return NULL;
        }
        if (ret < 0)
        {
            ALOGE("%s : error (%d)", __func__, ret);
            continue;
        }
    }
    vnd_userial.thread_uart_id = -1;
    ALOGD("%s exit", __func__);
    return NULL;
}

static void *userial_coex_thread(void *arg)
{
    BT_UNUSED(arg);
    struct epoll_event events[64] = {{0}};
    int j;
    while (vnd_userial.thread_running)
    {
        int ret;
        do
        {
            ret = epoll_wait(vnd_userial.cpoll_fd, events, 64, 500);
        } while (ret == -1 && errno == EINTR && vnd_userial.thread_running);
        if (ret == -1)
        {
            ALOGE("%s error in epoll_wait: %s", __func__, strerror(errno));
        }
        for (j = 0; j < ret; ++j)
        {
            struct bt_object_t *object = (struct bt_object_t *)events[j].data.ptr;
            if (events[j].data.ptr == NULL)
                continue;
            else
            {
                if (events[j].events & (EPOLLIN | EPOLLHUP | EPOLLRDHUP | EPOLLERR) && object->read_ready)
                    object->read_ready(object->context);
                if (events[j].events & EPOLLOUT && object->write_ready)
                    object->write_ready(object->context);
            }
        }
    }
    // vnd_userial.thread_coex_id = -1;
    ALOGD("%s exit", __func__);
    return NULL;
}

int userial_socket_open()
{
    int ret = 0;
    struct epoll_event event;
    if ((ret = socketpair(AF_UNIX, SOCK_STREAM, 0, vnd_userial.uart_fd)) < 0)
    {
        ALOGE("%s, errno : %s", __func__, strerror(errno));
        return ret;
    }

    if ((ret = socketpair(AF_UNIX, SOCK_STREAM, 0, vnd_userial.signal_fd)) < 0)
    {
        ALOGE("%s, errno : %s", __func__, strerror(errno));
        return ret;
    }

    vnd_userial.epoll_fd = epoll_create(64);
    if (vnd_userial.epoll_fd == -1)
    {
        ALOGE("%s unable to create epoll instance: %s", __func__, strerror(errno));
        return -1;
    }

    bt_socket_object.fd = vnd_userial.uart_fd[1];
    bt_socket_object.read_ready = userial_recv_H4_rawdata;
    memset(&event, 0, sizeof(event));
    event.events |= EPOLLIN | EPOLLHUP | EPOLLRDHUP | EPOLLERR;
    event.data.ptr = (void *)&bt_socket_object;
    if (epoll_ctl(vnd_userial.epoll_fd, EPOLL_CTL_ADD, vnd_userial.uart_fd[1], &event) == -1)
    {
        ALOGE("%s unable to register fd %d to epoll set: %s", __func__, vnd_userial.uart_fd[1], strerror(errno));
        close(vnd_userial.epoll_fd);
        vnd_userial.epoll_fd = -1;
        return -1;
    }

    event.data.ptr = NULL;
    if (epoll_ctl(vnd_userial.epoll_fd, EPOLL_CTL_ADD, vnd_userial.signal_fd[1], &event) == -1)
    {
        ALOGE("%s unable to register signal fd %d to epoll set: %s", __func__, vnd_userial.signal_fd[1], strerror(errno));
        close(vnd_userial.epoll_fd);
        vnd_userial.epoll_fd = -1;
        return -1;
    }
    pthread_attr_t thread_attr;
    pthread_attr_init(&thread_attr);
    pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_JOINABLE);
    vnd_userial.thread_running = true;
    if (pthread_create(&vnd_userial.thread_socket_id, &thread_attr, userial_recv_socket_thread, NULL) != 0)
    {
        ALOGE("pthread_create : %s", strerror(errno));
        close(vnd_userial.epoll_fd);
        vnd_userial.epoll_fd = -1;
        vnd_userial.thread_socket_id = -1;
        return -1;
    }

    if (pthread_create(&vnd_userial.thread_uart_id, &thread_attr, userial_recv_uart_thread, NULL) != 0)
    {
        ALOGE("pthread_create : %s", strerror(errno));
        close(vnd_userial.epoll_fd);
        vnd_userial.thread_running = false;
        pthread_join(vnd_userial.thread_socket_id, NULL);
        vnd_userial.thread_socket_id = -1;
        return -1;
    }

    vnd_userial.cpoll_fd = epoll_create(64);
    assert(vnd_userial.cpoll_fd != -1);

    vnd_userial.event_fd = eventfd(10, EFD_NONBLOCK);
    assert(vnd_userial.event_fd != -1);
    if (vnd_userial.event_fd != -1)
    {
        bt_coex_object.fd = vnd_userial.event_fd;
        bt_coex_object.read_ready = userial_coex_handler;
        memset(&event, 0, sizeof(event));
        event.events |= EPOLLIN | EPOLLHUP | EPOLLRDHUP | EPOLLERR;
        event.data.ptr = (void *)&bt_coex_object;
        if (epoll_ctl(vnd_userial.cpoll_fd, EPOLL_CTL_ADD, vnd_userial.event_fd, &event) == -1)
        {
            ALOGE("%s unable to register fd %d to cpoll set: %s", __func__, vnd_userial.event_fd, strerror(errno));
            assert(false);
        }

        event.data.ptr = NULL;
        if (epoll_ctl(vnd_userial.cpoll_fd, EPOLL_CTL_ADD, vnd_userial.signal_fd[1], &event) == -1)
        {
            ALOGE("%s unable to register fd %d to cpoll set: %s", __func__, vnd_userial.signal_fd[1], strerror(errno));
            assert(false);
        }

        if (pthread_create(&vnd_userial.thread_coex_id, &thread_attr, userial_coex_thread, NULL) != 0)
        {
            ALOGE("pthread create  coex : %s", strerror(errno));
            vnd_userial.thread_coex_id = -1;
            assert(false);
        }
    }

    btservice_init();
    ret = vnd_userial.uart_fd[0];
    return ret;
}

void userial_set_bt_interface_state(int bt_on)
{
    if (bt_parse_manager)
    {
        bt_parse_manager->bt_set_bt_on(bt_on);
    }
}
