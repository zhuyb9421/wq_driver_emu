/******************************************************************************
 *
 *  Copyright (C) 2009-2018 WuQi Corporation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at:
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 ******************************************************************************/

/******************************************************************************
 *
 *  Filename:      wq_oem.c
 *
 *  Description:   Contains functions used for wq oem
 *
 ******************************************************************************/

#undef NDEBUG
#define LOG_TAG "wq_bt_oem"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <utils/Log.h>
#include <pthread.h>
#include <dirent.h>

#include "wq_oem.h"
#include "crc.h"


static const char* FIRMWARE_PATHS[] = {
    "/vendor/etc/firmware",
    "/vendor/firmware",
    "/system/etc/firmware",
    "/system/vendor/firmware",
    NULL //end
};

static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static wq_resource_bt_info_t* bt_info = NULL;
static wq_resource_audio_t* audio_cfg = NULL;
static uint8_t* oem_data = NULL;
static size_t oem_size = 0;

static const char* get_oem_path(void)
{
    static char path[PATH_MAX] = {0};
    if (path[0] == 0) {
        for (int i = 0; FIRMWARE_PATHS[i] != NULL; i++) {
            DIR* dir = opendir(FIRMWARE_PATHS[i]);
            if (dir) {
                struct dirent* de;
                while ((de = readdir(dir)) != NULL) {
                    size_t len = strlen(de->d_name);
                    // 1. 检查是否以 ".bin" 结尾
                    if (len < 4) continue;
                    if (memcmp(de->d_name + len - 4, ".bin", 4) != 0) continue;

                    // 2. 检查文件名中是否包含 "_oem"
                    if (strstr(de->d_name, "_oem") != NULL) {
                        snprintf(path, sizeof(path), "%s/%s", FIRMWARE_PATHS[i], de->d_name);
                        closedir(dir);
                        return path;
                    }
                }
                closedir(dir);
            } else {
                ALOGE("get_oem_path opendir %s failed", FIRMWARE_PATHS[i]);
            }
        }
    }
    return path[0] ? path : NULL;
}

static uint8_t* load_file(const char* path, size_t* size){
    FILE *file = fopen(path, "r");
    if (file == NULL) {
        ALOGE("load_file: error opening file %s", path);
        return NULL;
    }

    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    fseek(file, 0, SEEK_SET);

    uint8_t *content = malloc(length);
    if (content == NULL) {
        ALOGE("load_file: error malloc %ld", length);
        fclose(file);
        return NULL;
    }

    size_t read_bytes = fread(content, 1, length, file);
    if (read_bytes != length) {
        ALOGE("load_file: fread %zu != %ld", read_bytes, length);
        fclose(file);
        free(content);
        return NULL;
    }
    fclose(file);

    *size = length;
    return content;
}

static wq_resource_t* get_oem_resource(uint8_t* data, size_t size, uint8_t type){
    size_t pos = sizeof(wq_oem_hearder_t);
    while(pos < size){
        wq_resource_t* resource = (wq_resource_t*)&data[pos];
        if(pos + sizeof(wq_resource_t) + resource->length > size){
            ALOGE("get_oem_resource: length error, pos:%zu length:%d size:%zu", pos, resource->length, size);
            return NULL;
        }
        if(resource->magic != WQ_RESOURCE_MAGIC){
            ALOGE("get_oem_resource: magic error, magic:%x", resource->magic);
            return NULL;
        }
        if(resource->type == type){
            return resource;
        }

        pos += sizeof(wq_resource_t) + resource->length;
    }
    return NULL;
}

static uint8_t* load_oem(void)
{
    if(oem_data) return oem_data;

    const char* path = get_oem_path();
    if(!path){
        ALOGE("wq_oem_get_bt_info: no oem file found");
        return NULL;
    }
    ALOGD("wq_oem_get_bt_info: oem file found: %s", path);


    oem_data = load_file(path, &oem_size);

    if((!oem_data) || (oem_size < sizeof(wq_resource_bt_info_t) + sizeof(wq_oem_hearder_t) + 4)){
        ALOGE("wq_oem_get_bt_info: load oem file error, oem_data:%p size:%zu", oem_data, oem_size);
        if(oem_data) free(oem_data);
        oem_data = NULL;
        return NULL;
    }

    uint32_t crc = getcrc32(oem_data, oem_size - 4);
    uint32_t* pcrc = (uint32_t*)&oem_data[oem_size - 4];

    if(crc != *pcrc){
        ALOGE("wq_oem_get_bt_info: crc error, crc:%x pcrc:%x", crc, *pcrc);
        free(oem_data);
        oem_data = NULL;
        return NULL;
    }

    wq_oem_hearder_t* oem = (wq_oem_hearder_t*)oem_data;
    if(oem->magic != WQ_OEM_MAGIC){
        ALOGE("wq_oem_get_bt_info: magic error, magic:%x", oem->magic);
        free(oem_data);
        oem_data = NULL;
        return NULL;
    }

    return oem_data;
}

wq_resource_bt_info_t* wq_oem_get_bt_info(void)
{
    if(bt_info){
        return bt_info;
    }

    load_oem();
    if(!oem_data) return NULL;

    wq_resource_t* resource = get_oem_resource(oem_data, oem_size, WQ_RESOURCE_TYPE_BT);
    if(!resource){
        ALOGE("wq_oem_get_bt_info: no bt info found");
        return NULL;
    }
    if(resource->length != sizeof(wq_resource_bt_info_t)){
        ALOGE("wq_oem_get_bt_info: bt info length error, length:%d", resource->length);
        return NULL;
    }

    if(!bt_info){
        pthread_mutex_lock(&lock);
        if(!bt_info){
            bt_info = malloc(sizeof(wq_resource_bt_info_t));
            if(bt_info){
                memcpy(bt_info, resource->data, sizeof(wq_resource_bt_info_t));
            }else{
                ALOGE("wq_oem_get_bt_info: malloc for bt info failed");
            }
        }
        pthread_mutex_unlock(&lock);
    }

    return bt_info;
}

wq_resource_audio_t* wq_oem_get_audio_config(void)
{
    if(audio_cfg){
        return audio_cfg;
    }

    load_oem();
    if(!oem_data) return NULL;

    wq_resource_t* resource = get_oem_resource(oem_data, oem_size, WQ_RESOURCE_TYPE_AUDIO);
    if(!resource){
        ALOGE("wq_oem_get_audio_config: no audio config found");
        return NULL;
    }
    if(resource->length != sizeof(wq_resource_audio_t)){
        ALOGE("wq_oem_get_audio_config: audio config length error, length:%d", resource->length);
        return NULL;
    }

    if(!audio_cfg){
        pthread_mutex_lock(&lock);
        if(!audio_cfg){
            audio_cfg = malloc(sizeof(wq_resource_audio_t));
            if(audio_cfg){
                memcpy(audio_cfg, resource->data, sizeof(wq_resource_audio_t));
            }else{
                ALOGE("wq_oem_get_audio_config: malloc for audio config failed");
            }
        }
        pthread_mutex_unlock(&lock);
    }

    return audio_cfg;
}