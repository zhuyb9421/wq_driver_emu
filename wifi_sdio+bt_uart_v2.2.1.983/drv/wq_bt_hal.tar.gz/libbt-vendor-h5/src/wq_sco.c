#undef NDEBUG
#define LOG_TAG "wq_sco"

#include <utils/Log.h>
#include <fcntl.h>
#include <errno.h>
#include <stdio.h>
#include <sys/eventfd.h>
#include "bt_socket.h"
#include <cutils/sockets.h>
#include <pthread.h>
#include <unistd.h>
#include "bt_skbuff.h"
#include "userial_vendor.h"
#include "cvsd.h"

#define ENABLE_SPEED_LOG 1
#define ENABLE_PCM_DUMP  0

#define PRINT_SPEED(prefix, ptr, length)                                                                     \
    if (ENABLE_SPEED_LOG) {                                                                                  \
        static struct timespec last = {0};                                                                   \
        struct timespec now;                                                                                 \
        static unsigned long total = 0;                                                                      \
        total += length;                                                                                     \
        clock_gettime(CLOCK_MONOTONIC, &now);                                                                \
        if (now.tv_sec - last.tv_sec >= 2) {                                                                 \
            unsigned long diff = (now.tv_nsec - last.tv_nsec) / 1000000 + (now.tv_sec - last.tv_sec) * 1000; \
            ALOGD("%s %d %luB/s", prefix, length, total * 1000 / diff);                                      \
            last = now;                                                                                      \
            total = 0;                                                                                       \
        }                                                                                                    \
        if (ENABLE_PCM_DUMP && ptr) {                                                                        \
            static FILE *f = NULL;                                                                           \
            if (!f) f = fopen("/data/misc/bluedroid/" prefix ".pcm", "wb");                                  \
            if (f) fwrite(ptr, length, 1, f);                                                                \
        }                                                                                                    \
    }

#define SCO_DATA_OUT_PATH "/data/misc/bluedroid/.sco_data_out"
#define SCO_DATA_IN_PATH  "/data/misc/bluedroid/.sco_data_in"

typedef enum {
    SCO_CTRL_CMD_NONE,
    SCO_CTRL_CMD_CHECK_READY,
    SCO_CTRL_CMD_OUT_START,
    SCO_CTRL_CMD_IN_START,
    SCO_CTRL_CMD_OUT_STOP,
    SCO_CTRL_CMD_IN_STOP,
    SCO_CTRL_CMD_SUSPEND,
    SCO_CTRL_GET_AUDIO_CONFIG,
    SCO_CTRL_CMD_OFFLOAD_START,
    SCO_CTRL_CMD_CLOSE,
} tSCO_CTRL_CMD;

#define SCO_SAMPLE_RATE_8K  1
#define SCO_SAMPLE_RATE_16K 2

#include "ms_sbc.h"
#ifdef CONFIG_SCO_MSBC_PLC
#include "sbcplc.h"
unsigned char indices0[] = {
    0xad, 0x0,  0x0,  0xc5, 0x0,  0x0,  0x0,  0x0,  0x77, 0x6d, 0xb6, 0xdd, 0xdb, 0x6d, 0xb7,
    0x76, 0xdb, 0x6d, 0xdd, 0xb6, 0xdb, 0x77, 0x6d, 0xb6, 0xdd, 0xdb, 0x6d, 0xb7, 0x76, 0xdb,
    0x6d, 0xdd, 0xb6, 0xdb, 0x77, 0x6d, 0xb6, 0xdd, 0xdb, 0x6d, 0xb7, 0x76, 0xdb, 0x6d, 0xdd,
    0xb6, 0xdb, 0x77, 0x6d, 0xb6, 0xdd, 0xdb, 0x6d, 0xb7, 0x76, 0xdb, 0x6c, 0x00};   // padding at the end
#endif

uint16_t btui_msbc_h2[] = {0x0801, 0x3801, 0xc801, 0xf801};
typedef struct {
    pthread_mutex_t sco_recv_mutex;
    pthread_cond_t sco_recv_cond;
    pthread_mutex_t sco_send_mutex;
    pthread_t thread_socket_sco_id;
    pthread_t thread_recv_sco_id;
    pthread_t thread_send_sco_id;
    uint16_t sco_handle;
    bool thread_sco_running;
    bool thread_recv_sco_running;
    bool thread_send_sco_running;
    uint16_t voice_settings;
    RTB_QUEUE_HEAD *recv_sco_data;
    RTB_QUEUE_HEAD *send_sco_data;
    unsigned char enc_data[480];
    uint16_t sco_packet_len;
    bool msbc_used;
    int data_out_fd, data_in_fd;
    void *decode_handle;
    void *encode_handle;
    void *decode_buffer;
    void *encode_buffer;
    uint32_t pcm_enc_seq;
    int8_t pcm_dec_seq;
    uint32_t pcm_dec_frame;
    int signal_fd[2];
} sco_cb_t;

static sco_cb_t sco_cb = {0};

static inline void pcm_map_chanels(uint8_t *dst, uint8_t *src, uint16_t len)
{
    uint16_t *dst16 = (uint16_t *)dst;
    uint16_t *src16 = (uint16_t *)src;
    uint16_t count = len / 2;
    uint16_t pos = 0;

    for (uint16_t i = 0; i < count; i++) {
        for (uint8_t j = 0; j < CONFIG_SCO_TX_AUDIO_CHANNELS; j++) {
            dst16[pos++] = src16[i];
        }
    }
}

// receive sco encode or non-encode data over hci, we need to decode msbc data to pcm, and send it to sco audio hal
static void *userial_recv_sco_thread(void *arg)
{
    BT_UNUSED(arg);
    BT_BUFFER *skb_sco_data;
    unsigned char dec_data[480];
    unsigned char pcm_data[960 * CONFIG_SCO_TX_AUDIO_CHANNELS];
    uint8_t *p_data = NULL;
    int res = 0;
    int writen = 0;
    prctl(PR_SET_NAME, (unsigned long)"userial_recv_sco_thread", 0, 0, 0);
    sco_cb.pcm_dec_seq = -1;
    sco_cb.pcm_dec_frame = 0;
#ifdef CONFIG_SCO_MSBC_PLC
    unsigned char plc_data[480];
    struct PLC_State plc_state;
    InitPLC(&plc_state);
#endif

    RtbEmptyQueue(sco_cb.recv_sco_data);

    ALOGE("userial_recv_sco_thread start");
    while (sco_cb.thread_recv_sco_running) {
        pthread_mutex_lock(&sco_cb.sco_recv_mutex);
        pthread_cond_wait(&sco_cb.sco_recv_cond, &sco_cb.sco_recv_mutex);
        pthread_mutex_unlock(&sco_cb.sco_recv_mutex);

        skb_sco_data = RtbDequeueHead(sco_cb.recv_sco_data);
        if (!skb_sco_data) {
            continue;
        }
        if (sco_cb.data_in_fd < 0) {
            RtbFree(skb_sco_data);
            continue;
        }
        p_data = skb_sco_data->Data;

        if (!sco_cb.msbc_used) {
            PRINT_SPEED("cvsd_rx", p_data, 60);
            cvsd_decode(p_data, 60, dec_data);
            pcm_map_chanels(pcm_data, dec_data, 120);
            res = Skt_Send_noblock(sco_cb.data_in_fd, pcm_data, 120 * CONFIG_SCO_TX_AUDIO_CHANNELS);
            if (res < 0) {
                ALOGE("userial_recv_sco_thread, send noblock error");
            }
            PRINT_SPEED("pcm_tx", pcm_data, 120 * CONFIG_SCO_TX_AUDIO_CHANNELS);
        } else {
            PRINT_SPEED("msbc_rx", p_data + 2, 57);
            uint8_t seq = (p_data[1] >> 4) & 0x0F;
            if ((seq != 0x00) && (seq != 0x03) && (seq != 0x0C) && (seq != 0x0F)) {
                ALOGE("sbc decode invalid seq: 0x%x", seq);
                RtbFree(skb_sco_data);
                continue;
            }

            uint32_t last_dec_frame = sco_cb.pcm_dec_frame;
            if (sco_cb.pcm_dec_seq == -1) {
                uint8_t step = 0;
                sco_cb.pcm_dec_seq = (int8_t)seq;
                step += (seq & 0x03) / 2;
                step += ((seq >> 2) & 0x03) / 2;
                sco_cb.pcm_dec_frame += step;
            } else {
                for (int i = 0; i < 4; i++) {
                    sco_cb.pcm_dec_seq = (uint8_t)((btui_msbc_h2[(++sco_cb.pcm_dec_frame) % 4] >> 12) & 0x0F);
                    if (sco_cb.pcm_dec_seq == seq) break;
                }

                if ((last_dec_frame + 1) != sco_cb.pcm_dec_frame) {
                    ALOGE("lost frame: %d, may use the plc function", (sco_cb.pcm_dec_frame - last_dec_frame));
#ifdef CONFIG_SCO_MSBC_PLC
                    uint8_t lost_frame = sco_cb.pcm_dec_frame - last_dec_frame - 1;
                    int i = 0;
                    for (i = 0; i < lost_frame; i++) {
                        writen = 240;
                        ms_sbc_decode(sco_cb.decode_handle, indices0, 57, dec_data, &writen);
                        PLC_bad_frame(&plc_state, (short *)dec_data, (short *)plc_data);
                        pcm_map_chanels(pcm_data, plc_data, 240);
                        res = Skt_Send_noblock(sco_cb.data_in_fd, pcm_data, 240 * CONFIG_SCO_TX_AUDIO_CHANNELS);
                    }
#endif
                }
            }

            writen = 240;
            res = ms_sbc_decode(sco_cb.decode_handle, (p_data + 2), 57, dec_data, &writen);
            if (!res) {
#ifdef CONFIG_SCO_MSBC_PLC
                PLC_good_frame(&plc_state, (short *)dec_data, (short *)plc_data);
                pcm_map_chanels(pcm_data, plc_data, 240);
#else
                pcm_map_chanels(pcm_data, dec_data, 240);
#endif
                res = Skt_Send_noblock(sco_cb.data_in_fd, pcm_data, 240 * CONFIG_SCO_TX_AUDIO_CHANNELS);
            } else {
                ALOGE("msbc decode fail! res:%d May use PLC function", res);
#ifdef CONFIG_SCO_MSBC_PLC
                writen = 240;
                ms_sbc_decode(sco_cb.decode_handle, indices0, 57, dec_data, &writen);
                PLC_bad_frame(&plc_state, (short *)dec_data, (short *)plc_data);
                pcm_map_chanels(pcm_data, plc_data, 240);
                res = Skt_Send_noblock(sco_cb.data_in_fd, pcm_data, 240 * CONFIG_SCO_TX_AUDIO_CHANNELS);
#endif
            }
            PRINT_SPEED("pcm_tx", pcm_data, 240 * CONFIG_SCO_TX_AUDIO_CHANNELS);
        }
        RtbFree(skb_sco_data);
    }
    ALOGE("userial_recv_sco_thread exit");
    RtbEmptyQueue(sco_cb.recv_sco_data);
    return NULL;
}

static inline void pcm_to_single_channel(uint8_t *dst, uint8_t *src, uint16_t len)
{
    uint16_t *dst16 = (uint16_t *)dst;
    uint16_t *src16 = (uint16_t *)src;
    uint16_t count = len / 2 / CONFIG_SCO_RX_AUDIO_CHANNELS;

    for (uint16_t i = 0; i < count; i++) {
        dst16[i] = src16[i * CONFIG_SCO_RX_AUDIO_CHANNELS];
    }
}

static void *userial_send_sco_thread(void *arg)
{
    BT_UNUSED(arg);
    unsigned char enc_data[240];
    unsigned char pcm_data[960];
    unsigned char read_data[960 * CONFIG_SCO_RX_AUDIO_CHANNELS];
    unsigned char send_data[240];
    int num_read;
    prctl(PR_SET_NAME, (unsigned long)"userial_send_sco_thread", 0, 0, 0);
    sco_cb.pcm_enc_seq = 0;
    int i;

    // when start sco send thread, first send 6 sco data to controller
    if (!sco_cb.msbc_used) {
        memset(enc_data, 0x55, 60);
        for (i = 0; i < 4; i++) {
            send_data[0] = DATA_TYPE_SCO;
            send_data[3] = 60;
            *(uint16_t *)&send_data[1] = sco_cb.sco_handle;
            memcpy(&send_data[4], enc_data, 60);
            userial_send_sco_to_controller(send_data, 64);
        }
    } else {
        for (i = 0; i < 4; i++) {
            send_data[0] = DATA_TYPE_SCO;
            *(uint16_t *)&send_data[1] = sco_cb.sco_handle;
            send_data[3] = 60;

            *(uint16_t *)(&(send_data[4 + 0])) = btui_msbc_h2[sco_cb.pcm_enc_seq % 4];
            sco_cb.pcm_enc_seq++;

            memcpy(&send_data[4 + 2], indices0, 58);
            userial_send_sco_to_controller(send_data, 64);
        }
    }
    ALOGE("userial_send_sco_thread start");
    while (sco_cb.thread_send_sco_running) {
        if (sco_cb.data_out_fd < 0) {
            usleep(10 * 1000);
            continue;
        }
        if (!sco_cb.msbc_used) {
            num_read = Skt_Read(sco_cb.data_out_fd, read_data, 120 * CONFIG_SCO_RX_AUDIO_CHANNELS,
                                &sco_cb.thread_send_sco_running);
            PRINT_SPEED("pcm_rx", read_data, num_read);
            pcm_to_single_channel(pcm_data, read_data, num_read);
            num_read /= CONFIG_SCO_RX_AUDIO_CHANNELS;
            if (!num_read) continue;
            cvsd_encode(pcm_data, 120, enc_data);
            send_data[0] = DATA_TYPE_SCO;
            send_data[3] = 60;
            *(uint16_t *)&send_data[1] = sco_cb.sco_handle;
            memcpy(&send_data[4], enc_data, 60);
            userial_send_sco_to_controller(send_data, 64);

            PRINT_SPEED("cvsd_tx", enc_data, 60);
        } else {
            num_read = Skt_Read(sco_cb.data_out_fd, read_data, 240 * CONFIG_SCO_RX_AUDIO_CHANNELS,
                                &sco_cb.thread_send_sco_running);
            PRINT_SPEED("pcm_rx", read_data, num_read);
            pcm_to_single_channel(pcm_data, read_data, num_read);
            num_read /= CONFIG_SCO_RX_AUDIO_CHANNELS;
            if (!num_read) continue;
            ms_sbc_encode(sco_cb.encode_handle, pcm_data, 240, &enc_data[2], 57);
            *(uint16_t *)(&(enc_data[0])) = btui_msbc_h2[sco_cb.pcm_enc_seq % 4];
            sco_cb.pcm_enc_seq++;
            enc_data[59] = 0x00;   // padding

            send_data[0] = DATA_TYPE_SCO;
            send_data[3] = 60;
            *(uint16_t *)&send_data[1] = sco_cb.sco_handle;
            memcpy(&send_data[4], enc_data, 60);
            userial_send_sco_to_controller(send_data, 64);

            PRINT_SPEED("msbc_tx", enc_data + 2, 57);
        }
    }
    ALOGE("userial_send_sco_thread exit");
    return NULL;
}

static void userial_sco_send_socket_stop()
{
    ALOGE("%s", __func__);
    pthread_mutex_lock(&sco_cb.sco_send_mutex);
    if (sco_cb.thread_send_sco_running) {
        sco_cb.thread_send_sco_running = false;
    } else {
        pthread_mutex_unlock(&sco_cb.sco_send_mutex);
        return;
    }
    pthread_mutex_unlock(&sco_cb.sco_send_mutex);

    if (sco_cb.thread_send_sco_id != -1) {
        pthread_join(sco_cb.thread_send_sco_id, NULL);
        sco_cb.thread_send_sco_id = -1;
    }
}

static void userial_sco_recv_socket_stop()
{
    ALOGE("%s", __func__);
    pthread_mutex_lock(&sco_cb.sco_recv_mutex);
    if (sco_cb.thread_recv_sco_running) {
        sco_cb.thread_recv_sco_running = false;
        pthread_cond_signal(&sco_cb.sco_recv_cond);
    } else {
        pthread_mutex_unlock(&sco_cb.sco_recv_mutex);
        return;
    }
    pthread_mutex_unlock(&sco_cb.sco_recv_mutex);

    if (sco_cb.thread_recv_sco_id != -1) {
        pthread_join(sco_cb.thread_recv_sco_id, NULL);
        sco_cb.thread_recv_sco_id = -1;
    }
}

static void userial_sco_socket_stop()
{
    ALOGE("%s", __func__);
    userial_sco_send_socket_stop();
    userial_sco_recv_socket_stop();
    if (sco_cb.data_out_fd > 0) {
        close(sco_cb.data_out_fd);
        sco_cb.data_out_fd = -1;
    }
    if (sco_cb.data_in_fd > 0) {
        close(sco_cb.data_in_fd);
        sco_cb.data_in_fd = -1;
    }
    RtbEmptyQueue(sco_cb.recv_sco_data);
}

static void *userial_socket_sco_thread(void *arg)
{
    BT_UNUSED(arg);
    struct sockaddr_un addr, remote;
    // socklen_t alen;
    socklen_t len = sizeof(struct sockaddr_un);
    fd_set read_set, active_set;
    int result, max_fd;
    int s_data_out = socket(AF_LOCAL, SOCK_STREAM, 0);
    if (s_data_out < 0) {
        ALOGE("ctrl socket create fail");
        return NULL;
    }
    int s_data_in = socket(AF_LOCAL, SOCK_STREAM, 0);
    if (s_data_in < 0) {
        ALOGE("data socket create fail");
        close(s_data_out);
        return NULL;
    }
    prctl(PR_SET_NAME, (unsigned long)"userial_socket_sco_thread", 0, 0, 0);

    if ((socketpair(AF_UNIX, SOCK_STREAM, 0, sco_cb.signal_fd)) < 0) {
        ALOGE("%s, errno : %s", __func__, strerror(errno));
        goto socket_close;
    }

    // bind sco ctrl socket
    // unlink(SCO_DATA_OUT_PATH);
    if (socket_local_server_bind(s_data_out, SCO_DATA_OUT_PATH, ANDROID_SOCKET_NAMESPACE_ABSTRACT) < 0) {
        ALOGE("ctrl socket failed to create (%s)", strerror(errno));
        goto signal_close;
    }

    if (listen(s_data_out, 5) < 0) {
        ALOGE("userial_socket_sco_thread, listen ctrl socket error : %s", strerror(errno));
        goto signal_close;
    }

    int res = chmod(SCO_DATA_OUT_PATH, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);
    if (res < 0) {
        ALOGE("chmod ctrl path fail");
    }
    // bind sco data socket
    // unlink(SCO_DATA_IN_PATH);
    if (socket_local_server_bind(s_data_in, SCO_DATA_IN_PATH, ANDROID_SOCKET_NAMESPACE_ABSTRACT) < 0) {
        ALOGE("data socket failed to create (%s)", strerror(errno));
        goto signal_close;
    }

    if (listen(s_data_in, 5) < 0) {
        ALOGE("userial_socket_sco_thread, listen data socket error : %s", strerror(errno));
        goto signal_close;
    }
    res = chmod(SCO_DATA_IN_PATH, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);
    if (res < 0) {
        ALOGE("chmod data path fail");
    }

    ALOGE("userial_socket_sco_thread");
    FD_ZERO(&read_set);
    FD_ZERO(&active_set);
    FD_SET(s_data_out, &active_set);
    FD_SET(s_data_in, &active_set);
    FD_SET(sco_cb.signal_fd[1], &active_set);
    max_fd = MAX(s_data_out, s_data_in);
    max_fd = MAX(max_fd, sco_cb.signal_fd[1]) + 1;
    while (sco_cb.thread_sco_running) {
        read_set = active_set;
        result = select(max_fd, &read_set, NULL, NULL, NULL);
        if (result == 0) {
            ALOGE("select timeout");
            continue;
        }
        if (result < 0) {
            if (errno != EINTR) ALOGE("select failed %s", strerror(errno));
            continue;
        }
        if (FD_ISSET(s_data_out, &read_set)) {
            if (sco_cb.data_out_fd > 0) {
                ALOGE("Already has connect a data_out_fd: %d", sco_cb.data_out_fd);
                shutdown(sco_cb.data_out_fd, SHUT_RDWR);
                close(sco_cb.data_out_fd);
            }
            BT_NO_INTR(sco_cb.data_out_fd = accept(s_data_out, (struct sockaddr *)&remote, &len));
            if (sco_cb.data_out_fd == -1) {
                ALOGE("sock accept failed (%s)", strerror(errno));
                continue;
            }
            const int size = (16 * 960);
            int ret = setsockopt(sco_cb.data_out_fd, SOL_SOCKET, SO_RCVBUF, (char *)&size, (int)sizeof(size));
            ret = setsockopt(sco_cb.data_out_fd, SOL_SOCKET, SO_SNDBUF, (char *)&size, (int)sizeof(size));
            ALOGD("sco_cb.data_out_fd:%d", sco_cb.data_out_fd);
        }

        if (FD_ISSET(s_data_in, &read_set)) {
            if (sco_cb.data_in_fd > 0) {
                ALOGE("Already has connect a data_in_fd: %d", sco_cb.data_in_fd);
                shutdown(sco_cb.data_in_fd, SHUT_RDWR);
                close(sco_cb.data_in_fd);
            }
            BT_NO_INTR(sco_cb.data_in_fd = accept(s_data_in, (struct sockaddr *)&remote, &len));
            if (sco_cb.data_in_fd == -1) {
                ALOGE("socket accept failed (%s)", strerror(errno));
                continue;
            }
            const int size = (16 * 960);
            int ret = setsockopt(sco_cb.data_in_fd, SOL_SOCKET, SO_RCVBUF, (char *)&size, (int)sizeof(size));
            ret = setsockopt(sco_cb.data_in_fd, SOL_SOCKET, SO_SNDBUF, (char *)&size, (int)sizeof(size));
            ALOGD("sco_cb.data_in_fd:%d", sco_cb.data_in_fd);
        }
    }

    userial_sco_socket_stop();
signal_close:
    close(sco_cb.signal_fd[0]);
    close(sco_cb.signal_fd[1]);
socket_close:
    close(s_data_out);
    close(s_data_in);

    memset(&addr, 0, sizeof(addr));
    strcpy((addr.sun_path + 1), SCO_DATA_IN_PATH);
    addr.sun_path[0] = 0;
    unlink(addr.sun_path);

    memset(&addr, 0, sizeof(addr));
    strcpy((addr.sun_path + 1), SCO_DATA_OUT_PATH);
    addr.sun_path[0] = 0;
    unlink(addr.sun_path);
    ALOGE("userial_socket_sco_thread exit");
    return NULL;
}

void wq_sco_recv_sco_data(unsigned char *recv_buffer, int length)
{
    BT_UNUSED(length);
    uint16_t sco_handle;
    uint8_t sco_length;
    uint8_t *p_data = recv_buffer;
    BT_BUFFER *skb_sco_data;
    sco_handle = *((uint16_t *)p_data);
    uint8_t packet_flag = (uint8_t)((sco_handle >> 12) & 0x0003);
    sco_handle &= 0x0FFF;

    if (sco_handle != sco_cb.sco_handle) {
        ALOGE("sco handle error, sco_handle:%d, recv_handle:%d", sco_cb.sco_handle, sco_handle);
        return;
    }

    sco_length = p_data[SCO_PREAMBLE_SIZE - 1];
    p_data += SCO_PREAMBLE_SIZE;

    if (packet_flag != 0x00) ALOGE("sco data receive wrong packet_flag : %d", packet_flag);

    PRINT_SPEED("sco_rx", p_data, sco_length);

    // if use cvsd codec
    if (!sco_cb.msbc_used) {
        skb_sco_data = RtbAllocate(sco_length, 0);
        if (packet_flag != 0x00) {
            memset(skb_sco_data->Data, 0x55, sco_length);
        } else {
            memcpy(skb_sco_data->Data, p_data, sco_length);
        }
        RtbAddTail(skb_sco_data, sco_length);

        RtbQueueTail(sco_cb.recv_sco_data, skb_sco_data);

        pthread_mutex_lock(&sco_cb.sco_recv_mutex);
        pthread_cond_signal(&sco_cb.sco_recv_cond);
        pthread_mutex_unlock(&sco_cb.sco_recv_mutex);
    } else {
        // use msbc codec
        if ((p_data[0] == 0x01) && ((p_data[1] & 0x0f) == 0x08) && (p_data[2] == 0xAD)) {
            memcpy(sco_cb.enc_data, &p_data[0], 60);   // complete msbc data
            skb_sco_data = RtbAllocate(60, 0);
            memcpy(skb_sco_data->Data, sco_cb.enc_data, 60);
            RtbAddTail(skb_sco_data, 60);

            RtbQueueTail(sco_cb.recv_sco_data, skb_sco_data);

            pthread_mutex_lock(&sco_cb.sco_recv_mutex);
            pthread_cond_signal(&sco_cb.sco_recv_cond);
            pthread_mutex_unlock(&sco_cb.sco_recv_mutex);
        } else {
            ALOGE("not msbc data");
        }
    }
}

void wq_sco_handle_event(unsigned char *recv_buffer, int length)
{
    BT_UNUSED(length);
    uint8_t event;
    uint8_t *p_data = recv_buffer;
    event = p_data[0];
    switch (event) {
    case HCI_ESCO_CONNECTION_COMP_EVT: {
        if (p_data[2] != 0) {
            sco_cb.thread_sco_running = false;
            sco_cb.thread_recv_sco_running = false;
            sco_cb.thread_send_sco_running = false;
            sco_cb.data_in_fd = -1;
            sco_cb.data_out_fd = -1;
        } else {
            uint16_t rx_packet_len = *((uint16_t *)&p_data[14]);
            uint16_t tx_packet_len = *((uint16_t *)&p_data[16]);
            uint8_t air_mode = p_data[18];

            int work_space_size;
            sco_cb.decode_handle = ms_sbc_decode_init(sco_cb.decode_buffer, &work_space_size, TYPE_MSBC, 1);
            sco_cb.encode_handle = ms_sbc_encode_init(sco_cb.encode_buffer, &work_space_size);

            sco_cb.sco_handle = *((uint16_t *)&p_data[3]);
            pthread_attr_t thread_attr;
            pthread_attr_init(&thread_attr);
            pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_JOINABLE);
            sco_cb.thread_sco_running = true;
            sco_cb.thread_recv_sco_running = false;
            sco_cb.thread_send_sco_running = false;
            sco_cb.data_in_fd = -1;
            sco_cb.data_out_fd = -1;
            if (pthread_create(&sco_cb.thread_socket_sco_id, &thread_attr, userial_socket_sco_thread, NULL) != 0) {
                ALOGE("pthread_create : %s", strerror(errno));
            }

            RtbEmptyQueue(sco_cb.recv_sco_data);
            if (!(sco_cb.voice_settings & 0x0003)) {
                sco_cb.sco_packet_len = tx_packet_len;
                sco_cb.msbc_used = false;
            } else {
                sco_cb.sco_packet_len = tx_packet_len;
                sco_cb.msbc_used = true;
            }

            if (sco_cb.sco_packet_len == 0) {
                sco_cb.sco_packet_len = 60;
            }

            pthread_attr_init(&thread_attr);
            pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_JOINABLE);
            sco_cb.thread_send_sco_running = true;
            if (pthread_create(&sco_cb.thread_send_sco_id, &thread_attr, userial_send_sco_thread, NULL) != 0) {
                ALOGE("pthread_create : %s", strerror(errno));
            }

            pthread_attr_init(&thread_attr);
            pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_JOINABLE);
            sco_cb.thread_recv_sco_running = true;
            if (pthread_create(&sco_cb.thread_recv_sco_id, &thread_attr, userial_recv_sco_thread, NULL) != 0) {
                ALOGE("pthread_create : %s", strerror(errno));
            }
            ALOGE("esco conneced handle:0x%X msbc:%d rx_len:%d tx_len:%d air_mode:%d sco_packet_len:%d",
                  sco_cb.sco_handle, sco_cb.msbc_used, rx_packet_len, tx_packet_len, air_mode, sco_cb.sco_packet_len);
        }
        break;
    }

    case HCI_DISCONNECTION_COMP_EVT: {
        if ((*((uint16_t *)&p_data[3])) == sco_cb.sco_handle) {
            sco_cb.sco_handle = 0;
            sco_cb.msbc_used = false;
            RtbEmptyQueue(sco_cb.recv_sco_data);
            if (sco_cb.thread_sco_running) {
                sco_cb.thread_sco_running = false;
                unsigned char close_signal = 1;
                ssize_t ret;
                BT_NO_INTR(ret = write(sco_cb.signal_fd[0], &close_signal, 1));
            }
        }
        break;
    }
    default:
        break;
    }
}

void wq_sco_handle_cmd(unsigned char *recv_buffer, int length)
{
    BT_UNUSED(length);
    uint16_t opcode = *(uint16_t *)recv_buffer;
    switch (opcode) {
    case HCI_WRITE_VOICE_SETTINGS: {
        sco_cb.voice_settings = *(uint16_t *)&recv_buffer[3];
        break;
    }
    case HCI_SETUP_ESCO_CONNECTION: {
        sco_cb.voice_settings = *(uint16_t *)&recv_buffer[15];
        break;
    }
    default:
        break;
    }
}

void wq_sco_init(void)
{
    sco_cb.recv_sco_data = RtbQueueInit();
    sco_cb.send_sco_data = RtbQueueInit();
    pthread_mutex_init(&sco_cb.sco_recv_mutex, NULL);
    pthread_cond_init(&sco_cb.sco_recv_cond, NULL);
    pthread_mutex_init(&sco_cb.sco_send_mutex, NULL);

    int work_space_size;
    if (!sco_cb.decode_buffer) {
        (void)ms_sbc_decode_init(NULL, &work_space_size, TYPE_MSBC, 2);
        ALOGD("decode work space size:%d\n", work_space_size);
        sco_cb.decode_buffer = malloc(work_space_size);
    }
    sco_cb.decode_handle = ms_sbc_decode_init(sco_cb.decode_buffer, &work_space_size, TYPE_MSBC, 1);

    if (!sco_cb.encode_buffer) {
        (void)ms_sbc_encode_init(NULL, &work_space_size);
        ALOGD("decode work space size:%d\n", work_space_size);
        sco_cb.encode_buffer = malloc(work_space_size);
    }
    sco_cb.encode_handle = ms_sbc_encode_init(sco_cb.encode_buffer, &work_space_size);
}

void wq_sco_deinit(void)
{
    if (sco_cb.thread_sco_running) {
        sco_cb.thread_sco_running = false;
        unsigned char close_signal = 1;
        ssize_t ret;
        BT_NO_INTR(ret = write(sco_cb.signal_fd[0], &close_signal, 1));
        pthread_join(sco_cb.thread_socket_sco_id, NULL);
    }
}