#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#include "bt_transport_config.h"

static void assert_mode(const char *mode, uint8_t flags, bool use_mbtchar)
{
    bt_transport_config_t config = {0};
    assert(bt_transport_config_parse(mode, &config));
    assert(config.transtype == flags);
    assert(config.use_mbtchar == use_mbtchar);
}

int main(void)
{
    assert_mode("H2", BT_TRANS_H4 | BT_TRANS_HCI_SOCKET, false);
    assert_mode("h2", BT_TRANS_H4 | BT_TRANS_HCI_SOCKET, false);
    assert_mode("H4",
                BT_TRANS_H4 | BT_TRANS_HCI_SOCKET |
                        BT_TRANS_HCI_SOCKET_FALLBACK,
                false);
    assert_mode("h4",
                BT_TRANS_H4 | BT_TRANS_HCI_SOCKET |
                        BT_TRANS_HCI_SOCKET_FALLBACK,
                false);
    assert_mode("H5", BT_TRANS_H5, false);
    assert_mode("h5", BT_TRANS_H5, false);
    bt_transport_config_t config = {0};
    assert(!bt_transport_config_parse("HCI_SOCKET", &config));
    assert(!bt_transport_config_parse("hci_socket", &config));
    assert(!bt_transport_config_parse("invalid", &config));
    assert(!bt_transport_config_parse(NULL, &config));
    assert(!bt_transport_config_parse("H4", NULL));
    puts("bt_transport_config_test: PASS");
    return 0;
}
