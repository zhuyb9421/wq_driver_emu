#include <assert.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>

#include "bt_vendor_open.h"

typedef struct {
    int transport_result;
    int bridge_result;
    int transport_calls;
    int bridge_calls;
    int close_calls;
} fake_open_state_t;

static fake_open_state_t fake_open;

static int fake_transport_open(void *config)
{
    (void)config;
    fake_open.transport_calls++;
    return fake_open.transport_result;
}

static int fake_bridge_open(void)
{
    fake_open.bridge_calls++;
    return fake_open.bridge_result;
}

static void fake_transport_close(void)
{
    fake_open.close_calls++;
}

static const bt_vendor_open_ops_t fake_open_ops = {
    .transport_open = fake_transport_open,
    .bridge_open = fake_bridge_open,
    .transport_close = fake_transport_close,
};

static void reset_fake_open(void)
{
    memset(&fake_open, 0, sizeof(fake_open));
}

static void test_transport_failure_does_not_open_bridge(void)
{
    reset_fake_open();
    fake_open.transport_result = -1;
    int fds[4] = {7, 7, 7, 7};
    assert(bt_vendor_open_channels(NULL, fds, 4, &fake_open_ops) == 0);
    assert(fake_open.transport_calls == 1);
    assert(fake_open.bridge_calls == 0);
    assert(fake_open.close_calls == 0);
    for (size_t i = 0; i < 4; ++i)
        assert(fds[i] == -1);
}

static void test_bridge_failure_closes_transport(void)
{
    reset_fake_open();
    fake_open.transport_result = 9;
    fake_open.bridge_result = -1;
    int fds[4] = {7, 7, 7, 7};
    assert(bt_vendor_open_channels(NULL, fds, 4, &fake_open_ops) == 0);
    assert(fake_open.transport_calls == 1);
    assert(fake_open.bridge_calls == 1);
    assert(fake_open.close_calls == 1);
    for (size_t i = 0; i < 4; ++i)
        assert(fds[i] == -1);
}

static void test_success_returns_one_shared_stack_fd(void)
{
    reset_fake_open();
    fake_open.transport_result = 9;
    fake_open.bridge_result = 11;
    int fds[4] = {-1, -1, -1, -1};
    assert(bt_vendor_open_channels(NULL, fds, 4, &fake_open_ops) == 1);
    assert(fake_open.close_calls == 0);
    for (size_t i = 0; i < 4; ++i)
        assert(fds[i] == 11);
}

int main(void)
{
    test_transport_failure_does_not_open_bridge();
    test_bridge_failure_closes_transport();
    test_success_returns_one_shared_stack_fd();
    puts("bt_vendor_open_test: PASS");
    return 0;
}
