#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "bt_transport_config.h"
#include "hci_socket_transport.h"

struct test_sockaddr_hci {
    sa_family_t hci_family;
    unsigned short hci_dev;
    unsigned short hci_channel;
};

#define TEST_BTPROTO_HCI 1
#define TEST_HCI_CHANNEL_USER 1
#define MAX_CALLS 64

typedef struct {
    int socket_calls;
    int bind_calls;
    int close_calls;
    int sleep_calls;
    int write_calls;
    int bind_errnos[MAX_CALLS];
    ssize_t write_results[MAX_CALLS];
    int write_errnos[MAX_CALLS];
    int64_t now_ms;
    int last_domain;
    int last_type;
    int last_protocol;
    int last_closed_fd;
    struct test_sockaddr_hci last_address;
} fake_state_t;

static fake_state_t fake;

static int fake_socket(int domain, int type, int protocol)
{
    fake.last_domain = domain;
    fake.last_type = type;
    fake.last_protocol = protocol;
    return 100 + fake.socket_calls++;
}

static int fake_bind(int fd, const struct sockaddr *address, socklen_t length)
{
    int error = fake.bind_errnos[fake.bind_calls++];
    (void)fd;
    assert(length == sizeof(struct test_sockaddr_hci));
    memcpy(&fake.last_address, address, sizeof(fake.last_address));
    if (error == 0)
        return 0;
    errno = error;
    return -1;
}

static int fake_close(int fd)
{
    fake.close_calls++;
    fake.last_closed_fd = fd;
    return 0;
}

static int fake_clock_gettime(clockid_t clock_id, struct timespec *time)
{
    assert(clock_id == CLOCK_MONOTONIC);
    time->tv_sec = fake.now_ms / 1000;
    time->tv_nsec = (fake.now_ms % 1000) * 1000000;
    return 0;
}

static int fake_nanosleep(const struct timespec *duration,
                          struct timespec *remaining)
{
    (void)remaining;
    fake.sleep_calls++;
    fake.now_ms += duration->tv_sec * 1000;
    fake.now_ms += duration->tv_nsec / 1000000;
    return 0;
}

static ssize_t fake_write(int fd, const void *buffer, size_t length)
{
    const int index = fake.write_calls++;
    const ssize_t configured_result = fake.write_results[index];
    const int configured_errno = fake.write_errnos[index];
    (void)fd;
    (void)buffer;

    if (configured_result == 0 && configured_errno == 0)
        return (ssize_t)length;
    if (configured_result == -1)
        errno = configured_errno;
    return configured_result;
}

static const hci_socket_transport_ops_t fake_ops = {
    .socket_fn = fake_socket,
    .bind_fn = fake_bind,
    .close_fn = fake_close,
    .write_fn = fake_write,
    .clock_gettime_fn = fake_clock_gettime,
    .nanosleep_fn = fake_nanosleep,
};

static void reset_fake(void)
{
    memset(&fake, 0, sizeof(fake));
}

static void test_binds_hci0_user_channel(void)
{
    reset_fake();
    int fd = hci_socket_transport_open_with_ops(0, 3000, &fake_ops);
    assert(fd == 100);
    assert(fake.socket_calls == 1);
    assert(fake.bind_calls == 1);
    assert(fake.close_calls == 0);
    assert(fake.last_domain == AF_BLUETOOTH);
    assert((fake.last_type & SOCK_RAW) == SOCK_RAW);
    assert(fake.last_protocol == TEST_BTPROTO_HCI);
    assert(fake.last_address.hci_family == AF_BLUETOOTH);
    assert(fake.last_address.hci_dev == 0);
    assert(fake.last_address.hci_channel == TEST_HCI_CHANNEL_USER);
}

static void test_retries_enodev_then_succeeds(void)
{
    reset_fake();
    fake.bind_errnos[0] = ENODEV;
    fake.bind_errnos[1] = 0;
    int fd = hci_socket_transport_open_with_ops(0, 3000, &fake_ops);
    assert(fd == 101);
    assert(fake.socket_calls == 2);
    assert(fake.bind_calls == 2);
    assert(fake.close_calls == 1);
    assert(fake.sleep_calls == 1);
    assert(fake.now_ms == 1000);
}

static void test_stops_after_three_second_deadline(void)
{
    reset_fake();
    for (int i = 0; i < MAX_CALLS; ++i)
        fake.bind_errnos[i] = ENODEV;
    int fd = hci_socket_transport_open_with_ops(0, 3000, &fake_ops);
    assert(fd == -1);
    assert(errno == ENODEV);
    assert(fake.now_ms == 3000);
    assert(fake.sleep_calls == 3);
    assert(fake.socket_calls == 4);
    assert(fake.close_calls == 4);
}

static void test_fatal_bind_errors_do_not_retry(void)
{
    const int fatal_errors[] = {EBUSY, EUSERS, EPERM, EACCES};
    for (size_t i = 0; i < sizeof(fatal_errors) / sizeof(fatal_errors[0]); ++i) {
        reset_fake();
        fake.bind_errnos[0] = fatal_errors[i];
        assert(hci_socket_transport_open_with_ops(0, 3000, &fake_ops) == -1);
        assert(errno == fatal_errors[i]);
        assert(fake.socket_calls == 1);
        assert(fake.bind_calls == 1);
        assert(fake.close_calls == 1);
        assert(fake.sleep_calls == 0);
    }
}

static void test_packet_write_is_one_complete_write(void)
{
    static const uint8_t packet[] = {0x01, 0x03, 0x0c, 0x00};
    reset_fake();
    ssize_t result = hci_socket_transport_write_packet_with_ops(
            42, packet, sizeof(packet), &fake_ops);
    assert(result == (ssize_t)sizeof(packet));
    assert(fake.write_calls == 1);
}

static void test_packet_write_retries_only_eintr(void)
{
    static const uint8_t packet[] = {0x01, 0x03, 0x0c, 0x00};
    reset_fake();
    fake.write_results[0] = -1;
    fake.write_errnos[0] = EINTR;
    fake.write_results[1] = sizeof(packet);
    ssize_t result = hci_socket_transport_write_packet_with_ops(
            42, packet, sizeof(packet), &fake_ops);
    assert(result == (ssize_t)sizeof(packet));
    assert(fake.write_calls == 2);
}

static void test_short_write_is_error_without_second_fragment(void)
{
    static const uint8_t packet[] = {0x01, 0x03, 0x0c, 0x00};
    reset_fake();
    fake.write_results[0] = 2;
    assert(hci_socket_transport_write_packet_with_ops(
            42, packet, sizeof(packet), &fake_ops) == -1);
    assert(errno == EIO);
    assert(fake.write_calls == 1);
}

static void test_selection_requires_hci_socket_flag(void)
{
    assert(!hci_socket_transport_is_selected(BT_TRANS_H4));
    assert(!hci_socket_transport_is_selected(BT_TRANS_H5));
    assert(hci_socket_transport_is_selected(
            BT_TRANS_H4 | BT_TRANS_HCI_SOCKET));
}

static void test_transport_fallback_selection(void)
{
    assert(!hci_socket_transport_should_fallback(
            BT_TRANS_H4 | BT_TRANS_HCI_SOCKET));
    assert(hci_socket_transport_should_fallback(
            BT_TRANS_H4 | BT_TRANS_HCI_SOCKET |
                    BT_TRANS_HCI_SOCKET_FALLBACK));
    assert(!hci_socket_transport_should_fallback(BT_TRANS_H5));
}

int main(void)
{
    test_binds_hci0_user_channel();
    test_retries_enodev_then_succeeds();
    test_stops_after_three_second_deadline();
    test_fatal_bind_errors_do_not_retry();
    test_packet_write_is_one_complete_write();
    test_packet_write_retries_only_eintr();
    test_short_write_is_error_without_second_fragment();
    test_selection_requires_hci_socket_flag();
    test_transport_fallback_selection();
    puts("hci_socket_transport_test: PASS");
    return 0;
}
