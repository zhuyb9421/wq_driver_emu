## OEM bin map

| 类型        | module id        | 接口      | ROM_VER | oem.bin                    | 备注        |
|:---------:|:----------------:|:-------:|:-------:|:--------------------------:|:---------:|
| EFEM      | 0x2245           | USB+USB | 1.1     | wq9201_oem_1_1_0245.bin    | SD FEM    |
| EFEM      | 0x2265           | USB+USB | 1.1     | wq9201_oem_1_1_0265.bin    | SFPV FEM  |
| EFEM      | 0x2285           | USB+USB | 1.1     | wq9201_oem_1_1_0285.bin    | HE FEM    |
| EFEM      | 0x22C5           | USB+USB | 1.1     | wq9201_oem_1_1_02C5.bin    | U3621 FEM |
| 2718/1315 | 0x22A5           | USB+USB | 1.1     | wq9201_oem_1_1_02A5.bin    |           |
| 1315      | 0x22A5           | USB+USB | 1.1     | wq9201_oem_1_1_02A5_h4.bin | bt h4     |
| 1213      | 0x5385           | USB+USB | 1.1     | wq9201_oem_1_1_0385.bin    | 9101U 1*1 |
| demo      | 0x20E0/21E4/2104 | all     | 1.1     | wq9201_oem_1_1_00E0.bin    | demo板     |
