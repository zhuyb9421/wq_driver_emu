#
# Copyright(c) 2020 by WuQi Technologies. ALL RIGHTS RESERVED.
#
# This Information is proprietary to WuQi Technologies and MAY NOT
# be copied by any method or incorporated into another program without
# the express written consent of WuQi. This Information or any portion
# thereof remains the property of WuQi. The Information contained herein
# is believed to be accurate and WuQi assumes no responsibility or
# liability for its use in any way and conveys no license or title under
# any patent or copyright and makes no representation or warranty that this
# Information is free from patent or copyright infringement.

import os
import sys
import json
import struct
import pdb
import platform
import collections
import binascii
import ctypes
import copy
from enum import Enum

oem_tool_version = '0.3.0'

class RESOURCE_TYPE(Enum):
    RESOURCE_TYPE_IOMAP         = 0
    RESOURCE_TYPE_COEX          = 1
    RESOURCE_TYPE_UART          = 2
    RESOURCE_TYPE_MAC           = 3
    RESOURCE_TYPE_PHY_PARAMS    = 4
    RESOURCE_TYPE_BT            = 5
    RESOURCE_TYPE_WIFI          = 6
    RESOURCE_TYPE_RTC_SOURCE    = 7
    RESOURCE_TYPE_FEM           = 8
    RESOURCE_TYPE_AUDIO         = 9

class GPIO_NAME(Enum):
    UART0_RXD            = 0
    UART0_TXD            = 1
    UART1_RXD            = 2
    UART1_TXD            = 3
    UART0_RTS            = 4
    UART0_CTS            = 5
    UART1_RTS            = 6
    UART1_CTS            = 7
    BT_UART_TXD          = 8
    BT_UART_RXD          = 9
    BT_UART_RTS          = 10
    BT_UART_CTS          = 11
    WIFI_UART_TXD        = 12
    WIFI_UART_RXD        = 13
    WIFI_UART_RTS        = 14
    WIFI_UART_CTS        = 15
    AUDIO_IIS_BCK        = 16
    AUDIO_IIS_WS         = 17
    AUDIO_IIS_TX         = 18
    AUDIO_IIS_RX         = 19
    BT_WAKEUP_HOST       = 32
    BT_WAKEUP_CONTROLLER = 33
    WLAN_WAKEUP_HOST     = 34
    WLAN_REG_ON          = 35
    COEX_RF_SWITCH       = 48
    COEX_3_WIRE_REQ      = 49
    COEX_3_WIRE_PRIO     = 50
    COEX_3_WIRE_RESULT   = 51
    FEM0_2G_C0           = 64
    FEM0_2G_C1           = 65
    FEM0_2G_C2           = 66
    FEM0_2G_C3           = 67
    FEM0_5G_C0           = 68
    FEM0_5G_C1           = 69
    FEM0_5G_C2           = 70
    FEM0_5G_C3           = 71
    FEM1_2G_C0           = 72
    FEM1_2G_C1           = 73
    FEM1_2G_C2           = 74
    FEM1_2G_C3           = 75
    FEM1_5G_C0           = 76
    FEM1_5G_C1           = 77
    FEM1_5G_C2           = 78
    FEM1_5G_C3           = 79
    WIFI_MP_TEST_TXD     = 80
    WIFI_MP_TEST_RXD     = 81
    BT_MP_TEST_TXD       = 82
    BT_MP_TEST_RXD       = 83
    PWM_CH_0             = 96
    PWM_CH_1             = 97
    PWM_CH_2             = 98
    PWM_CH_3             = 99
    APP_REPEATER_UART_TX = 128
    APP_REPEATER_UART_RX = 129
    APP_KEEP_ALIVE       = 130
    IO_MAP_MAX           = 255

class oem_header_ctypes(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ('magic', ctypes.c_uint32),
        ('version', ctypes.c_uint8),
        ('type_cnt', ctypes.c_uint8),
        ('reserved', ctypes.c_uint8 * 2),
    ]

class oem_tlv_header_ctypes(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ('magic', ctypes.c_uint8),
        ('type', ctypes.c_uint8),
        ('length', ctypes.c_uint8),
        ('reserved', ctypes.c_uint8),
    ]

class oem_iomap_ctypes(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ('id', ctypes.c_uint8),
        ('pull', ctypes.c_uint8),
        ('gpio', ctypes.c_uint8),
        ('use_iomap', ctypes.c_uint8),
    ]

fem_dict = {
    'vendor': {
        'none': 0,
        'vanchip': 1,
        'kct_8531_efem': 2,
        'kct_8585_sfpv_fem_he': 3,
        'kct_fem_he_v1_2': 4,
    },
    'prop': {
        'wifi_only': 0,
        'share_bt': 1,
    },
}

class fem_ctypes(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ('vendor', ctypes.c_uint8),
        ('prop', ctypes.c_uint8),
        ('reserved', ctypes.c_uint8 * 2),
    ]

coex_dict = {
    'prop': {
        'bt_bypass': 0,
        'share_bt_with_switch': 1,
        'share_bt_no_switch': 2,
    },
    'invert_signal': {
        'disable': 0,
        'enable': 1,
    },
    'ant2_version': None
}

class coex_ctypes(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ('prop', ctypes.c_uint8),
        ('invert_signal', ctypes.c_uint8),
        ('ant2_version', ctypes.c_uint8),
        ('reserved', ctypes.c_uint8),
    ]

bt_dict = {
    'hci_mode': {
        'h2': 0,
        'h4': 1,
        'h5': 2,
    },
    'stb': {
        'disable': 0,
        'enable': 1,
    },
    'host_wakeup_bt': {
        'gpio_default_low': 0,
        'gpio_default_high': 1,
    },
    'bt_wakeup_host': {
        'gpio_default_low': 0,
        'gpio_default_high': 1,
    },
    'deep_sleep': {
        'disable': 0,
        'enable': 1,
    },
    'uart_hw_flow_ctrl': {
        'disable': 0,
        'enable': 1,
    },
    'uart_parity_en': {
        'disable': 0,
        'enable': 1,
    },
    'uart_parity': {
        'even': 0,
        'odd': 1,
    },
    'uart_baudrate': None
}

class bt_ctypes(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        # bytes 0
        ('hci_mode', ctypes.c_uint8, 2),
        ('stb', ctypes.c_uint8, 1),
        ('host_wakeup_bt', ctypes.c_uint8, 1),
        ('bt_wakeup_host', ctypes.c_uint8, 1),
        ('deep_sleep', ctypes.c_uint8, 1),
        ('uart_hw_flow_ctrl', ctypes.c_uint8, 1),
        ('uart_parity_en', ctypes.c_uint8, 1),
        # bytes 1
        ('uart_parity', ctypes.c_uint8, 1),
        ('reserved', ctypes.c_uint8, 7),
        # bytes 3-6
        ('uart_baudrate', ctypes.c_uint32),
    ]

audio_dict = {
    'iis_tx_mode': {
        'slave': 0,
        'master': 1,
    },
    'iis_tx_standard': {
        'philips': 0,
        'msb': 1,
        'lsb': 2,
    },
    'iis_tx_data_format': {
        '16B': 0,
        '24B': 1,
    },
    'iis_tx_pcm_mode': {
        'false': 0,
        'true': 1,
    },
    'iis_rx_mode': {
        'slave': 0,
        'master': 1,
    },
    'iis_rx_standard': {
        'philips': 0,
        'msb': 1,
        'lsb': 2,
    },
    'iis_rx_data_format': {
        '16B': 0,
        '24B': 1,
    },
    'iis_rx_pcm_mode': {
        'false': 0,
        'true': 1,
    },
    'audio_path': {
        'pcm': 0,
        'hci': 1,
    }
}

class audio_ctypes(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        # bytes 0
        ('iis_tx_mode', ctypes.c_uint8, 1),
        ('iis_tx_standard', ctypes.c_uint8, 2),
        ('iis_tx_data_format', ctypes.c_uint8, 2),
        ('iis_tx_pcm_mode', ctypes.c_uint8, 1),
        ('reserved1', ctypes.c_uint8, 2),
        # bytes 1
        ('iis_rx_mode', ctypes.c_uint8, 1),
        ('iis_rx_standard', ctypes.c_uint8, 2),
        ('iis_rx_data_format', ctypes.c_uint8, 2),
        ('iis_rx_pcm_mode', ctypes.c_uint8, 1),
        ('reserved2', ctypes.c_uint8, 2),
        # bytes 2
        ('audio_path', ctypes.c_uint8, 1),
        ('reserved3', ctypes.c_uint8, 7),
        # bytes 3
        ('reserved4', ctypes.c_uint8),
    ]

wifi_dict = {
    'deep_sleep': {
        'disable': 0,
        'enable': 1,
    }
}

class wifi_ctypes(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ('deep_sleep', ctypes.c_uint16, 1),
        ('reserved', ctypes.c_uint16, 15),
    ]

rtc_dict = {
    'source': {
        'rco': 0,
        'xtal': 1,
        'ext_32k': 2,
        '32k_xtal': 3,
    }
}

class rtc_ctypes(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ('source', ctypes.c_uint8),
    ]

uart_dict = {
    'port': None,
    'out_core': {
        'core0': 0,
        'core0': 1,
        'core0': 2,
        'core0': 3,
        'Not specified': 255,
    },
    'out_host_en': {
        'disable': 0,
        'enable': 1,
        'Not specified': 255,
    },
    'baudrate': None
}

class uart_ctypes(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ('port', ctypes.c_uint8),
        ('out_core', ctypes.c_uint8),
        ('out_host_en', ctypes.c_uint8),
        ('reserved', ctypes.c_uint8),
        ('baudrate', ctypes.c_uint32),
    ]

class mac_ctypes(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ('mac_addr', ctypes.c_uint8 * 6),
        ('reserved', ctypes.c_uint8 * 2),
    ]

class phy_ctypes_ver_0_1(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ('11b_max_pwr_2g4', ctypes.c_int8 * 4),
        ('ofdm_max_pwr_2g4', ctypes.c_int8 * 10),
        ('11ax_max_pwr_2g4', ctypes.c_int8 * 12),
        ('ofdm_max_pwr_5g', ctypes.c_int8 * 10),
        ('11ax_max_pwr_5g', ctypes.c_int8 * 12),
        ('bw_pwr_offset', ctypes.c_int8 * 3),
        ('fem_truth_table_2g', ctypes.c_int8 * 8),
        ('fem_truth_table_5g', ctypes.c_int8 * 6),
        ('sideband_limit_en', ctypes.c_int8),
    ]

class phy_ctypes_ver_0_2(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ('fem_truth_table_2g', ctypes.c_int8 * 8),
        ('fem_truth_table_5g', ctypes.c_int8 * 6),
        ('sideband_limit_en', ctypes.c_int8),
    ]

class Oem(object):
    def __init__(self, path, chip, branch_version, parse=False, show_struct=False):
        # add support key when add json param
        self.support_keys = [
            'version', 'fem', 'coex', 'bt', 'audio', 'iomap',
            'wifi', 'rtc_source', 'uart', 'mac_addr', 'phy_params',
        ]
        self.find_keys = []

        ### common parameters
        self.oem_comment_key    = '//'
        self.oem_chip           = chip
        self.oem_branch_version = branch_version

        self.oem_show_ctypes    = show_struct

        self.oem_magic          = 0x696F6D70
        self.oem_tlv_magic      = 0x51
        self.oem_iomap_cnt_max  = 32

        self.oem_header_ctypes  = oem_header_ctypes()

        ### for generate oem bin
        self.generate_json_path         = path                      # json path we used
        self.generate_json_version      = None                      # json['version']
        self.generate_json              = collections.OrderedDict() # json data in python

        self.generate_tlv_count         = 0
        self.generate_iomap_count       = 0                         # iomap count we find in json

        self.generate_bin               = bytes()

        ### for parse oem bin
        self.parse_bin_path             = path
        self.parse_bin_version          = None
        self.parse_json                 = collections.OrderedDict()

        self.parse_tlv_count            = 0
        self.parse_iomap_count       = 0                         # iomap count we find in bin

        if parse == True:
            self.parse_init_bin()
        else:
            self.generate_init_json()

        ### for compare oem bin

    def parse_init_bin(self):
        if not os.path.exists(os.path.join(self.parse_bin_path)):
            print('cant find %s' % (self.parse_bin_path))
            sys.exit(-1)
        else:
            if os.path.getsize(self.parse_bin_path) != 256:
                print('oem bin size is not 256 Bytes, read {0}'.format(os.path.getsize(self.parse_bin_path)))
                sys.exit(-1)

            with open(self.parse_bin_path, 'rb') as f:
                self.parse_bin = f.read()

        print('parse oem: check magic ... ', end='')
        if int.from_bytes(self.parse_bin[:4], 'little') != self.oem_magic:
            print('failed!')
            sys.exit(-1)
        print('done')

        print('parse oem: check crc32 ... ', end='')
        crc32_from_bin = int.from_bytes(self.parse_bin[-4:], 'little')
        crc32 = binascii.crc32(self.parse_bin[0 : len(self.parse_bin) - 4])
        if crc32_from_bin != crc32:
            print('failed!')
            sys.exit(-1)
        print('done')

    def parse_bin_header(self):
        ver = int(self.parse_bin[4])
        version = str((ver >> 4) & 0xf) + '.' + str(ver & 0xf)

        self.parse_json['version'] = version
        self.parse_tlv_count = self.parse_bin[5]

        print('\noem:')
        if version != oem_tool_version[:3]:
            print('  -> tool version: {0}, bin version: {1} !!!'.format(oem_tool_version, version))
        else:
            print('  -> version: {0}'.format(version))
        print('  -> tlv count: {0} (include \'version\')'.format(self.parse_tlv_count))
        print('')

    def parse_bin_mac(self, tlv_bin):
        print(tlv_bin.hex())

    def parse_bin_iomap(self, tlv_bin):
        print(tlv_bin.hex())

    def parse_bin_phy(self, tlv_bin):
        print(tlv_bin.hex())

    def parse_bin_tlv(self):
        parse_bin_tlvs = self.parse_bin[8:-4]

        if parse_bin_tlvs[0] != self.oem_tlv_magic:
            print('oem tlv magic error, not 0x51')
            sys.exit(-1)

        tlv = None
        tlv_dict = None
        key_name = ''
        while parse_bin_tlvs[0] == 0x51:
            oem_tlv_header = oem_tlv_header_ctypes()
            oem_tlv_header_size = ctypes.sizeof(oem_tlv_header)
            ctypes.memmove(ctypes.byref(oem_tlv_header), parse_bin_tlvs[:oem_tlv_header_size], oem_tlv_header_size)

            if oem_tlv_header.type == RESOURCE_TYPE.RESOURCE_TYPE_BT.value:
                tlv = bt_ctypes()
                tlv_dict = bt_dict
                key_name = 'bt'
                print('bt:')
            elif oem_tlv_header.type == RESOURCE_TYPE.RESOURCE_TYPE_WIFI.value:
                tlv = wifi_ctypes()
                tlv_dict = wifi_dict
                key_name = 'wifi'
                print('wifi:')
            elif oem_tlv_header.type == RESOURCE_TYPE.RESOURCE_TYPE_COEX.value:
                tlv = coex_ctypes()
                tlv_dict = coex_dict
                key_name = 'coex'
                print('coex:')
            elif oem_tlv_header.type == RESOURCE_TYPE.RESOURCE_TYPE_RTC_SOURCE.value:
                tlv = rtc_ctypes()
                tlv_dict = rtc_dict
                key_name = 'rtc_source'
                print('rtc:')
            elif oem_tlv_header.type == RESOURCE_TYPE.RESOURCE_TYPE_UART.value:
                tlv = uart_ctypes()
                tlv_dict = uart_dict
                key_name = 'uart'
                print('uart:')
            elif oem_tlv_header.type == RESOURCE_TYPE.RESOURCE_TYPE_FEM.value:
                tlv = fem_ctypes()
                tlv_dict = fem_dict
                key_name = 'fem'
                print('fem:')
            elif oem_tlv_header.type == RESOURCE_TYPE.RESOURCE_TYPE_MAC.value:
                tlv = mac_ctypes()
                tlv_dict = None
                key_name = 'mac_addr'
                print('mac:')
            elif oem_tlv_header.type == RESOURCE_TYPE.RESOURCE_TYPE_IOMAP.value:
                tlv = oem_iomap_ctypes()
                tlv_dict = None
                key_name = 'iomap'
                print('iomap:')
            elif oem_tlv_header.type == RESOURCE_TYPE.RESOURCE_TYPE_PHY_PARAMS.value:
                if oem_tlv_header.length == ctypes.sizeof(phy_ctypes_ver_0_1):
                    tlv = phy_ctypes_ver_0_1()
                elif oem_tlv_header.length == ctypes.sizeof(phy_ctypes_ver_0_2):
                    tlv = phy_ctypes_ver_0_2()
                tlv_dict = None
                key_name = 'phy_params'
                print('phy:')
            elif oem_tlv_header.type == RESOURCE_TYPE.RESOURCE_TYPE_AUDIO.value:
                tlv = audio_ctypes()
                tlv_dict = audio_dict
                key_name = 'audio'
                print('audio:')
            else:
                print('parse oem: unknown oem tlv type {0}'.format(oem_tlv_header.type))
                sys.exit(-1)

            print('tlv: {0} - {1}'.format(
                  parse_bin_tlvs[:oem_tlv_header_size].hex(),
                  parse_bin_tlvs[oem_tlv_header_size:oem_tlv_header_size + oem_tlv_header.length].hex()))

            if oem_tlv_header.type == RESOURCE_TYPE.RESOURCE_TYPE_IOMAP.value:
                self.parse_json[key_name] = []

                iomap_bin = copy.deepcopy(parse_bin_tlvs[oem_tlv_header_size : oem_tlv_header_size + oem_tlv_header.length])

                if oem_tlv_header.length % ctypes.sizeof(oem_iomap_ctypes) != 0:
                    print('parse oem: iomap bin length {0} error, not multiple of {1}'.format(
                                    oem_tlv_header.length, ctypes.sizeof(oem_iomap_ctypes)))
                    sys.exit(-1)

                self.parse_iomap_count = int(oem_tlv_header.length / ctypes.sizeof(oem_iomap_ctypes))

                for _ in range(self.parse_iomap_count):
                    oem_iomap = oem_iomap_ctypes()
                    parse_json_iomap = {}
                    ctypes.memmove(ctypes.byref(oem_iomap), iomap_bin[:ctypes.sizeof(oem_iomap)], ctypes.sizeof(oem_iomap))

                    gpio_id = oem_iomap.id
                    gpio_gpio = oem_iomap.gpio
                    gpio_pull = oem_iomap.pull

                    if gpio_id in GPIO_NAME._value2member_map_:
                        gpio_name = GPIO_NAME(gpio_id).name.lower()
                    else:
                        gpio_name = 'unknown'

                    parse_json_iomap['name'] = gpio_name
                    parse_json_iomap['id'] = gpio_id
                    parse_json_iomap['pull'] = gpio_pull
                    parse_json_iomap['gpio'] = gpio_gpio
                    self.parse_json[key_name].append(parse_json_iomap)

                    print('  -> {0}: id {1} -> gpio {2}, pull {3}'.format(gpio_name.ljust(20), gpio_id, gpio_gpio, gpio_pull))

                    iomap_bin = iomap_bin[ctypes.sizeof(oem_iomap):]
                print('')
            else:
                self.parse_json[key_name] = collections.OrderedDict()

                if oem_tlv_header.length != ctypes.sizeof(tlv):
                    print('parse oem: tlv {0} size {1} not same as tool {2}'.format(oem_tlv_header.type, oem_tlv_header.length, ctypes.sizeof(tlv)))
                    sys.exit(-1)

                ctypes.memmove(ctypes.byref(tlv),
                                parse_bin_tlvs[oem_tlv_header_size:oem_tlv_header_size + oem_tlv_header.length],
                                len(parse_bin_tlvs[oem_tlv_header_size:oem_tlv_header_size + oem_tlv_header.length]))

                for field in tlv._fields_:
                    value = getattr(tlv, field[0])

                    if tlv_dict != None and not field[0].startswith('reserved'):
                        keys = tlv_dict[field[0]]

                        if keys is None:
                            print('  -> {0}: {1}'.format(field[0].ljust(20), value))
                            self.parse_json[key_name][field[0]] = value
                        else:
                            for key, key_value in keys.items():
                                if key_value == value:
                                    print('  -> {0}: {1}'.format(field[0].ljust(20), key))
                                    self.parse_json[key_name][field[0]] = key
                    else:
                        if issubclass(field[1], ctypes.Array):
                            if oem_tlv_header.type == RESOURCE_TYPE.RESOURCE_TYPE_MAC.value:
                                if field[0].startswith('reserved'):
                                    continue
                                mac_addr = bytes(getattr(tlv, field[0]))
                                mac_addr = (hex(mac_addr[0])[2:] + ':' +
                                                hex(mac_addr[1])[2:] + ':' +
                                                hex(mac_addr[2])[2:] + ':' +
                                                hex(mac_addr[3])[2:] + ':' +
                                                hex(mac_addr[4])[2:] + ':' +
                                                hex(mac_addr[5])[2:])
                                self.parse_json[key_name] = mac_addr
                                print('  -> {0}: {1}'.format(field[0].ljust(20), mac_addr))
                            else:
                                print('  -> {0}: {1}'.format(field[0].ljust(20), list(getattr(tlv, field[0]))))

                                if field[0].startswith('reserved'):
                                    pass
                                else:
                                    self.parse_json[key_name][field[0]] = list(getattr(tlv, field[0]))
                        else:
                            print('  -> {0}: {1}'.format(field[0].ljust(20), value))

                            if field[0].startswith('reserved'):
                                pass
                            else:
                                self.parse_json[key_name][field[0]] = value

                print('')

            parse_bin_tlvs = parse_bin_tlvs[oem_tlv_header_size + oem_tlv_header.length:]

    def parse_bin_out_json(self):
        separator_char = '\\' if platform.system() == 'Windows' else '/'
        output_name = self.parse_bin_path.split(separator_char)[-1]

        if output_name.startswith('wq9201_oem_'):
            output_name = 'oem_' + output_name[len('wq9201_oem_') + 4:]

        output_name = output_name.split('.')[0]
        output_name = output_name + '_parse.json'
        json.dump(self.parse_json, open(output_name,'w'), indent = 4)

    def generate_bin_ctypes_show_struct(self, name, _ctypes):
        print('  -> struct {0} {1}'.format(name, '{'))
        for field in _ctypes._fields_:
            if issubclass(field[1], ctypes.Array):
                field_type = field[1].__name__.split('Array')[0][:-1]
                print('         {0} {1}[{2}]; ==> {3}'.format(field_type, field[0], ctypes.sizeof(field[1]), list(getattr(_ctypes, field[0]))))
            else:
                if len(field) == 2:
                    print('         {0} {1}; ==> {2}'.format(field[1].__name__, field[0], getattr(_ctypes, field[0])))
                else:
                    print('         {0} {1} : {2}; ==> {3}'.format(field[1].__name__, field[0], field[2], getattr(_ctypes, field[0])))
        print('     {0} '.format('}'), end='')

        print('{0}'.format('0x{0:0{1}x}'.format(
                int.from_bytes(bytes(_ctypes), byteorder='little'),
                ctypes.sizeof(_ctypes) * 2)))

    def generate_bin_ctypes(self, name, c_struct, keys, json):
        if not isinstance(keys, dict):
            print('keys must is dict')
            sys.exit(-1)

        if len(keys) == 0:
            print('no keys in bitmap!')
            sys.exit(-1)

        struct_field = [field[0] for field in c_struct._fields_]

        for key in keys:
            if key not in json.keys():
                print('from json file can not find key [{0}]!!'.format(key))
                sys.exit(-1)

            if key not in struct_field:
                print('from struct file can not find key [{0}]!!'.format(key))
                sys.exit(-1)

            # check size !!

            try:
                setattr(c_struct, key, keys[key][json[key]])
            except TypeError:
                try:
                    setattr(c_struct, key, int(json[key]))
                except:
                    sys.exit(-1)

            print('  -> {0}: {1}'.format(key.ljust(20), json[key]))
            # if show:
            #     print('{0}[{1}] is {2}: bin: {3}'.format(
            #         key, json[key], keys[key][json[key]],
            #         '0x{0:0{1}x}'.format(
            #             int.from_bytes(bytes(c_struct), byteorder='little'),
            #             ctypes.sizeof(c_struct) * 2))) 

        if self.oem_show_ctypes == True:
            self.generate_bin_ctypes_show_struct(name, c_struct)
        print('')

        return bytes(c_struct)

    def get_all_data_from_json(self, keys, data):
        if isinstance(keys, dict):
            for _, value in keys.items():
                self.get_all_data_from_json(value, data)
        else:
            if isinstance(keys, int):
                data.append(keys)
            elif isinstance(keys, list):
                data.extend(keys)

    def generate_init_json(self):
        if not os.path.exists(os.path.join(self.generate_json_path)):
            print('cant find file: {0}'.format(self.generate_json_path))
            sys.exit(-1)

        with open(os.path.join(self.generate_json_path)) as file:
            self.generate_json = json.load(file, object_pairs_hook=collections.OrderedDict)

    def generate_oem_type_count(self):
        show_version = False

        if self.generate_json == None:
            print('generate oem: json is None, please indicate json path!')
            sys.exit(-1)

        # check version
        if self.generate_json['version'] == None:
            print('generate oem: can not find key[version] in json!')
            sys.exit(-1)
        else:
            show_version = True if self.generate_json['version'] != oem_tool_version[:3] else None
            self.generate_json_version = self.generate_json['version']

        # check all type key of json
        for key in self.support_keys:
            if key not in self.generate_json.keys():
                print('generate oem: from json can not find oem key: {0}, remove key ...'.format(key))
            else:
                self.find_keys.append(key)

        self.generate_tlv_count = len(self.find_keys) - 1

        # show log
        print('oem')
        if show_version == True:
            print('  -> tool version: {0}, json version: {1} !!!'.format(oem_tool_version, self.generate_json['version']))
        else:
            print('  -> version: {0}'.format(self.generate_json['version']))
        print('  -> tlv count: {0} (include \'version\')'.format(self.generate_tlv_count))
        print('')

    def generate_oem_bin_header(self):
        if self.generate_tlv_count == 0:
            print('generate oem: can not find tlv in json!')
            sys.exit(-1)

        version_high = int(self.generate_json_version[0])
        version_low = int(self.generate_json_version[2])
        version = hex((version_high << 4) | version_low)

        # fill oem header struct
        self.oem_header_ctypes.magic = self.oem_magic
        self.oem_header_ctypes.version = int(version, 16)
        self.oem_header_ctypes.type_cnt = self.generate_tlv_count

        # generate oem header bin
        self.generate_bin += bytes(self.oem_header_ctypes)

    def generate_tlv_header(self, tlv_type, tlv_len):
        oem_tlv_header = oem_tlv_header_ctypes()
        oem_tlv_header.magic = self.oem_tlv_magic
        oem_tlv_header.type = tlv_type
        oem_tlv_header.length = tlv_len

        return bytes(oem_tlv_header)

    def generate_tlv_mac(self, json, show=False):
        addr = json.split(':')

        bin = bytes()
        mac = mac_ctypes()

        bin += self.generate_tlv_header(RESOURCE_TYPE.RESOURCE_TYPE_MAC.value, ctypes.sizeof(mac))

        mac.mac_addr[0] = int(addr[0], 16)
        mac.mac_addr[1] = int(addr[1], 16)
        mac.mac_addr[2] = int(addr[2], 16)
        mac.mac_addr[3] = int(addr[3], 16)
        mac.mac_addr[4] = int(addr[4], 16)
        mac.mac_addr[5] = int(addr[5], 16)
        bin += bytes(mac)

        print('mac ({0} bytes):'.format(ctypes.sizeof(mac)))
        print('  -> {0}: {1}'.format('addr'.ljust(20), json))

        if self.oem_show_ctypes == True:
            self.generate_bin_ctypes_show_struct('mac', mac)

        print('')

        return bin

    def generate_tlv_iomap(self, json):
        must_have_keys = ['id', 'pull', 'gpio']

        # check iomap keys from json must in must_have_keys
        for iomap in json:
            for key in must_have_keys:
                if key not in iomap.keys():
                    print("generate oem: oem[iomap] {0} incomplete properties, cant find {2}".format(iomap['name'], key))
                    sys.exit(-1)

        # check max iomap count
        if len(self.generate_json['iomap']) <= self.oem_iomap_cnt_max:
            self.generate_iomap_count = len(self.generate_json['iomap'])
        else:
            print('generate oem: oem[iomap] max count is {0}'.format(self.oem_iomap_cnt_max))
            self.generate_iomap_count = self.oem_iomap_cnt_max
        oem_tlv_iomap_len = self.generate_iomap_count * ctypes.sizeof(oem_iomap_ctypes)

        # show iomap log
        print('iomap ({0} bytes), count {1}:'.format(oem_tlv_iomap_len, self.generate_iomap_count))
        for iomap in self.generate_json['iomap']:
            iomap_name = iomap['name']
            iomap_id = iomap['id']
            iomap_pull = iomap['pull']
            iomap_gpio = iomap['gpio']
            print('  -> {0}: id {1} -> gpio {2}, pull {3}'.format(iomap_name.ljust(20), iomap_id, iomap_gpio, iomap_pull))

        # generat tlv header
        bin = bytes()
        bin += self.generate_tlv_header(RESOURCE_TYPE.RESOURCE_TYPE_IOMAP.value, oem_tlv_iomap_len)

        # generat tlv data
        oem_iomap = oem_iomap_ctypes()
        for iomap in json:
            oem_iomap.id = iomap['id']
            oem_iomap.pull = iomap['pull']
            oem_iomap.gpio = iomap['gpio']
            oem_iomap.use_iomap = 1

            if self.oem_show_ctypes == True:
                self.generate_bin_ctypes_show_struct('iomap-id{0}'.format(iomap['id']), oem_iomap)

            bin += bytes(oem_iomap)

        print('')

        return bin

    def generate_tlv_phy(self, json):
        data = []

        ### 1. get all json data to list
        self.get_all_data_from_json(json, data)

        ### 2. check data value
        for value in data:
            if value not in range(-128, 128):
                raise ValueError("generate oem: oem[phy] data value error")
        if not all(isinstance(x, int) for x in data):
            raise ValueError("generate oem: oem[phy] data only support signed char")

        ### 3. check phy version
        phy_ctypes = None
        if len(data) == ctypes.sizeof(phy_ctypes_ver_0_1):
            # print('generate oem: find oem[phy] version 1')
            phy_ctypes = phy_ctypes_ver_0_1()
            print('phy ({0} bytes) ver 1:'.format(len(data)))
        elif len(data) == ctypes.sizeof(phy_ctypes_ver_0_2):
            # print('generate oem: find oem[phy] version 2')
            phy_ctypes = phy_ctypes_ver_0_2()
            print('phy ({0} bytes) ver 2:'.format(len(data)))
        else:
            print('generate oem: phy data len error, please check json')
            sys.exit(-1)

        ### 4. generate tlv header
        bin = bytes()
        bin += self.generate_tlv_header(RESOURCE_TYPE.RESOURCE_TYPE_PHY_PARAMS.value, len(data))

        ### 5. generate tlv data (memcpy)
        # can not direct copy from list to ctypes, construct a ctypes from a list
        src_data = (ctypes.c_int8 * len(data))(*data)
        # copy to phy
        ctypes.memmove(ctypes.byref(phy_ctypes), src_data, len(data))

        ### 6. show log
        for field in phy_ctypes._fields_:
            if issubclass(field[1], ctypes.Array):
                print('  -> {0}: {1}'.format(field[0].ljust(20), list(getattr(phy_ctypes, field[0]))))
            else:
                print('  -> {0}: {1}'.format(field[0].ljust(20), getattr(phy_ctypes, field[0])))

        if self.oem_show_ctypes == True:
            self.generate_bin_ctypes_show_struct('phy', phy_ctypes)
        print('')

        bin += bytes(phy_ctypes)
        return bin

    def generate_oem_bin_tlv(self):
        for key in self.find_keys:
            if key == 'version':
                continue

            if key == 'iomap':
                self.generate_bin += self.generate_tlv_iomap(self.generate_json[key])
            elif key == 'phy_params':
                self.generate_bin += self.generate_tlv_phy(self.generate_json[key])
            elif key == 'mac_addr':
                self.generate_bin += self.generate_tlv_mac(self.generate_json[key])
            else:
                maps = {
                    'coex': {
                        'tlv': coex_ctypes(),
                        'tlv_dict': coex_dict,
                        'type': RESOURCE_TYPE.RESOURCE_TYPE_COEX.value
                    },
                    'uart': {
                        'tlv': uart_ctypes(),
                        'tlv_dict': uart_dict,
                        'type': RESOURCE_TYPE.RESOURCE_TYPE_UART.value
                    },
                    'bt': {
                        'tlv': bt_ctypes(),
                        'tlv_dict': bt_dict,
                        'type': RESOURCE_TYPE.RESOURCE_TYPE_BT.value
                    },
                    'audio': {
                        'tlv': audio_ctypes(),
                        'tlv_dict': audio_dict,
                        'type': RESOURCE_TYPE.RESOURCE_TYPE_AUDIO.value
                    },
                    'wifi': {
                        'tlv': wifi_ctypes(),
                        'tlv_dict': wifi_dict,
                        'type': RESOURCE_TYPE.RESOURCE_TYPE_WIFI.value
                    },
                    'rtc_source': {
                        'tlv': rtc_ctypes(),
                        'tlv_dict': rtc_dict,
                        'type': RESOURCE_TYPE.RESOURCE_TYPE_RTC_SOURCE.value
                    },
                    'fem': {
                        'tlv': fem_ctypes(),
                        'tlv_dict': fem_dict,
                        'type': RESOURCE_TYPE.RESOURCE_TYPE_FEM.value
                    }
                }

                tlv = maps[key]['tlv']
                tlv_dict = maps[key]['tlv_dict']
                resouece_type = maps[key]['type']
                print('{0} ({1} bytes):'.format(key, ctypes.sizeof(tlv)))
                self.generate_bin += self.generate_tlv_header(resouece_type, ctypes.sizeof(tlv))
                self.generate_bin += self.generate_bin_ctypes(key, tlv, tlv_dict, self.generate_json[key])

    def generate_oem_bin_crc32(self):
        if (len(self.generate_bin) > 256 - 4):    # 4 bytes for crc32
            print('bin length too long, must less or equal 252!')
            sys.exit(-1)
        else:
            while len(self.generate_bin) < 252:
                gap_struct = '<1B'
                self.generate_bin += struct.pack(gap_struct, 0)
            if len(self.generate_bin) != 252:
                print('bin length error, must equal to 252 after fill zero value!')
                sys.exit(-1)

        crc = binascii.crc32(self.generate_bin)
        self.generate_bin += struct.pack('<1I', crc)     # crc32 is uint32_t

    def generate_oem_bin_out(self):
        if platform.system() == 'Windows':
            name = self.generate_json_path.split('\\')[-1].split('.')[0][4:]
        else:
            name = self.generate_json_path.split('/')[-1].split('.')[0][4:]

        output_name = self.oem_chip + '_oem_' + self.oem_branch_version + '_' + name + '.bin'

        with open(output_name, 'wb') as f:
            f.write(self.generate_bin)

def main(path, output=True, chip='wq', branch_ver='0_0', debug=False):

    print('use \033[31m{0}\033[0m to generate oem bin ...\n'.format(path))

    oem = Oem(path, chip, branch_ver, show_struct=debug)
    oem.generate_oem_type_count()
    oem.generate_oem_bin_header()
    oem.generate_oem_bin_tlv()
    oem.generate_oem_bin_crc32()
    oem.generate_oem_bin_out() if output == True else None

    return oem.generate_bin

def oem_generate(oem_json):
    return main(oem_json, output=False)

def oem_parse(path):

    print('use \033[31m{0}\033[0m to parse oem bin ...\n'.format(path))

    oem_parse = Oem(path, chip='21', branch_version='0_0', parse=True)
    oem_parse.parse_bin_header()
    oem_parse.parse_bin_tlv()
    oem_parse.parse_bin_out_json()

def compare_oem_parse_oem(path):
    if not os.path.exists(os.path.join(path)):
        print('compare oem: cant find {0}' % (path))
        sys.exit(-1)

    with open(path, 'rb') as f:
       oem = f.read()

    oem_ver = int(oem[4])
    oem_tlv_cnt = oem[5]
    oem_crc32 = int.from_bytes(oem[-4:], 'little')
    oem_version = str((oem_ver >> 4) & 0xf) + '.' + str(oem_ver & 0xf)

    oem_tlv = oem[8:]
    oem_tlv_map = {}

    if oem_tlv[0] != 0x51:
        print('oem tlv magic error, not 0x51')
        sys.exit(-1)

    while oem_tlv[0] == 0x51:
        tlv_type = oem_tlv[1]
        tlv_length = oem_tlv[2]
        oem_tlv_map[str(tlv_type)] = oem_tlv[:4 + tlv_length]
        oem_tlv = oem_tlv[4 + tlv_length:]

    return (oem_version, oem_crc32, oem_tlv_cnt, oem_tlv_map)

def compare_oem_show_diff(name1, name2, tlv1_bin, tlv2_bin, debug):
    oem_tlv_header1 = oem_tlv_header_ctypes()
    oem_tlv_header2 = oem_tlv_header_ctypes()

    ctypes.memmove(ctypes.byref(oem_tlv_header1), tlv1_bin, ctypes.sizeof(oem_tlv_header1))
    ctypes.memmove(ctypes.byref(oem_tlv_header2), tlv2_bin, ctypes.sizeof(oem_tlv_header2))

    tlv_name = RESOURCE_TYPE(oem_tlv_header1.type).name.lower().split('resource_type_')[-1]

    print('\033[31moem[{0}] bin data differ !!\033[0m'.format(tlv_name))

    if debug == True:
        if oem_tlv_header1.type == RESOURCE_TYPE.RESOURCE_TYPE_IOMAP.value:
            tlv_dict = None

            bin_data1 = tlv1_bin[4:]
            bin_data2 = tlv2_bin[4:]

            iomap_size = ctypes.sizeof(oem_iomap_ctypes)

            iomaps1 = []
            iomaps2 = []

            gpio_id_from_1 = {}
            gpio_id_from_2 = {}

            for i in range(int(oem_tlv_header1.length / iomap_size)):
                iomap_ctypes = oem_iomap_ctypes()
                ctypes.memmove(ctypes.byref(iomap_ctypes), bin_data1[iomap_size * i : iomap_size * (i + 1)], iomap_size)
                iomaps1.append(iomap_ctypes)
                gpio_id_from_1[iomap_ctypes.id] = iomap_ctypes.gpio

            for i in range(int(oem_tlv_header2.length / iomap_size)):
                iomap_ctypes = oem_iomap_ctypes()
                ctypes.memmove(ctypes.byref(iomap_ctypes), bin_data2[iomap_size * i : iomap_size * (i + 1)], iomap_size)
                iomaps2.append(iomap_ctypes)
                gpio_id_from_2[iomap_ctypes.id] = iomap_ctypes.gpio

            print('\033[31m')
            print('    {0}: iomap count: {1}'.format(name1.ljust(30), len(iomaps1)))
            print('    {0}: iomap count: {1}'.format(name2.ljust(30), len(iomaps2)))

            if len(iomaps1) == 0 or len(iomaps2) == 0:
                return

            gpio_id_common = list(set(list(gpio_id_from_1.keys())).intersection(set(list(gpio_id_from_2.keys()))))
            gpio_id_1 = list(set(list(gpio_id_from_1.keys())).difference(set(list(gpio_id_from_2.keys()))))
            gpio_id_2 = list(set(list(gpio_id_from_2.keys())).difference(set(list(gpio_id_from_1.keys()))))

            print('')
            print('    id-common: {0}'.format(gpio_id_common))

            for gpio_id in gpio_id_common:
                print('        id-{0}:'.format(gpio_id))
                print('            {0}: {1}'.format(name1.ljust(30), gpio_id_from_1[gpio_id]))
                print('            {0}: {1}'.format(name2.ljust(30), gpio_id_from_2[gpio_id]))
            print('')

            print('    id-{0}: {1}'.format(name1, gpio_id_1))
            for gpio_id in gpio_id_1:
                print('        id-{0}: {1}'.format(gpio_id, gpio_id_from_1[gpio_id]))
            print('')

            print('    id-{0}: {1}'.format(name2, gpio_id_2))
            for gpio_id in gpio_id_2:
                print('        id-{0}: {1}'.format(gpio_id, gpio_id_from_2[gpio_id]))

            print('\033[0m')

            return

        if oem_tlv_header1.type == RESOURCE_TYPE.RESOURCE_TYPE_BT.value:
            tlv1 = bt_ctypes()
            tlv2 = bt_ctypes()
            tlv_dict = bt_dict
        elif oem_tlv_header1.type == RESOURCE_TYPE.RESOURCE_TYPE_WIFI.value:
            tlv1 = wifi_ctypes()
            tlv2 = wifi_ctypes()
            tlv_dict = wifi_dict
        elif oem_tlv_header1.type == RESOURCE_TYPE.RESOURCE_TYPE_COEX.value:
            tlv1 = coex_ctypes()
            tlv2 = coex_ctypes()
            tlv_dict = coex_dict
        elif oem_tlv_header1.type == RESOURCE_TYPE.RESOURCE_TYPE_RTC_SOURCE.value:
            tlv1 = rtc_ctypes()
            tlv2 = rtc_ctypes()
            tlv_dict = rtc_dict
        elif oem_tlv_header1.type == RESOURCE_TYPE.RESOURCE_TYPE_UART.value:
            tlv1 = uart_ctypes()
            tlv2 = uart_ctypes()
            tlv_dict = uart_dict
        elif oem_tlv_header1.type == RESOURCE_TYPE.RESOURCE_TYPE_FEM.value:
            tlv1 = fem_ctypes()
            tlv2 = fem_ctypes()
            tlv_dict = fem_dict
        elif oem_tlv_header1.type == RESOURCE_TYPE.RESOURCE_TYPE_MAC.value:
            tlv1 = mac_ctypes()
            tlv2 = mac_ctypes()
            tlv_dict = None
        elif oem_tlv_header1.type == RESOURCE_TYPE.RESOURCE_TYPE_PHY_PARAMS.value:
            if oem_tlv_header1.length == ctypes.sizeof(phy_ctypes_ver_0_1):
                tlv1 = phy_ctypes_ver_0_1()
                tlv2 = phy_ctypes_ver_0_1()
            elif oem_tlv_header1.length == ctypes.sizeof(phy_ctypes_ver_0_2):
                tlv1 = phy_ctypes_ver_0_2()
                tlv2 = phy_ctypes_ver_0_2()
            tlv_dict = None
        elif oem_tlv_header1.type == RESOURCE_TYPE.RESOURCE_TYPE_AUDIO.value:
            tlv1 = audio_ctypes()
            tlv2 = audio_ctypes()
            tlv_dict = audio_dict
        else:
            print('parse oem: unknown oem tlv type {0}'.format(oem_tlv_header1.type))
            sys.exit(-1)

            if len(tlv1_bin[ctypes.sizeof(oem_tlv_header1):]) != ctypes.sizeof(tlv1):
                print("compare oem: oem[{0}] data length error from bin 1!!".format(tlv_name))
                sys.exit(-1)
            if len(tlv2_bin[ctypes.sizeof(oem_tlv_header2):]) != ctypes.sizeof(tlv1):
                print("compare oem: oem[{0}] data length error from bin 2!!".format(tlv_name))
                sys.exit(-1)

        ctypes.memmove(ctypes.byref(tlv1), tlv1_bin[ctypes.sizeof(oem_tlv_header1):], ctypes.sizeof(tlv1))
        ctypes.memmove(ctypes.byref(tlv2), tlv2_bin[ctypes.sizeof(oem_tlv_header2):], ctypes.sizeof(tlv2))

        for field in tlv1._fields_:
            name = field[0]

            if name.startswith('reserved'):
                continue

            if issubclass(field[1], ctypes.Array):
                value1 = list(getattr(tlv1, field[0]))
                value2 = list(getattr(tlv2, field[0]))
            else:
                value1 = getattr(tlv1, field[0])
                value2 = getattr(tlv2, field[0])

            if tlv_dict != None:
                if isinstance(tlv_dict[name], dict):
                    for key, val in tlv_dict[name].items():
                        if val == value1:
                            value1 = key
                        if val == value2:
                            value2 = key

            if value1 == value2:
                continue

            print('    \033[31moem[{0}].{1}\033[0m'.format(tlv_name, name))
            print('        \033[31m{0}: {1}\033[0m'.format(name1.ljust(30), value1))
            print('        \033[31m{0}: {1}\033[0m'.format(name2.ljust(30), value2))
            print('')

    print('')

def oem_compare(path1, path2, debug=False):
    

    print('use \033[31m{0}\033[0m and \033[31m{1}\033[0m to compare oem bin ...\n'.format(path1, path2))

    is_same = True

    bin_name1 = path1.split('/')[-1]
    bin_name2 = path2.split('/')[-1]

    version_1, crc32_1, tlv_cnt_1, tlv_map_1 = compare_oem_parse_oem(path1)
    version_2, crc32_2, tlv_cnt_2, tlv_map_2 = compare_oem_parse_oem(path2)

    # if oem_crc32_1 != oem_crc32_2:
    #     print('oem compare: crc32 differ')
    #     sys.exit(-1)

    if version_1 != version_2:
        print('compare oem: version differ')

    if tlv_cnt_1 != tlv_cnt_2:
        print('compare oem: tlv count differ')

    tlv1_keys = list(tlv_map_1.keys())
    tlv2_keys = list(tlv_map_2.keys())

    for key, val in tlv_map_1.items():
        if key not in tlv_map_2.keys():
            tlv_name = RESOURCE_TYPE(int(key)).name.lower().split('resource_type_')[-1]
            print('\033[31m{0} have not key: {1}\033[0m\n'.format(bin_name2, tlv_name))
            continue

        if debug == True:
            print(bin_name1.ljust(30), ': tlv header - data: ', val[:4].hex(), '-', val[4:].hex())
            print(bin_name2.ljust(30), ': tlv header - data: ', tlv_map_2[key][:4].hex(), '-', tlv_map_2[key][4:].hex())
            print('')

        if val != tlv_map_2[key]:
            compare_oem_show_diff(bin_name1, bin_name2, val, tlv_map_2[key], debug)
            # sys.exit(-1) if debug == False else None
            is_same = False

    for key in tlv2_keys:
        if key not in tlv1_keys:
            tlv_name = RESOURCE_TYPE(int(key)).name.lower().split('resource_type_')[-1]
            print('\033[31m{0} have not key: {1}\033[0m\n'.format(bin_name1, tlv_name))

    print('oem [{0}] and [{1}] is same'.format(path1, path2)) if is_same == True else None

if __name__ == "__main__":
    print('oem tool v{0}'.format(oem_tool_version), end=' , ')

    debug = False
    arg_size = len(sys.argv)

    for arg in sys.argv:
        if arg.startswith('debug='):
            arg_size -= 1
            if arg.split('debug=')[-1] == '1':
                debug = True

    if arg_size == 4:
        chip = sys.argv[2]
        branch_ver = sys.argv[3]
        main(sys.argv[1], output=True, chip=chip, branch_ver=branch_ver, debug=debug)

    elif arg_size == 2:    # parse oem.bin
        if sys.argv[1].endswith('.json'):
            main(sys.argv[1], output=True, chip='wq9201', branch_ver='1_1', debug=debug)
        elif sys.argv[1].endswith('.bin'):
            oem_parse(sys.argv[1])
        elif sys.argv[1] == '--help':
            print('show help ...')
            print('1. generate oem bin : python wq_oem.py oem_xx.json [chip_name branch_version]')
            print('2. parse oem bin    : python wq_oem.py oem_xx.bin')
            print('2. compare 2 oem bin: python wq_oem.py oem_xx1.bin oem_xx1.bin')
        else:
            print('only support bin/json')
            sys.exit(-1)

    elif arg_size == 3:    # compare oem.bin
        if sys.argv[1].endswith('.bin') and sys.argv[2].endswith('.bin'):
            oem_compare(sys.argv[1], sys.argv[2], debug=debug)

    else:
        main(sys.argv[1])
