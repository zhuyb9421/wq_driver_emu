#
# Copyright(c) 2020 by WuQi Technologies. ALL RIGHTS RESERVED.
#
# This Information is proprietary to WuQi Technologies and MAY NOT
# be copied by any method or incorporated into another program without
# the express written consent of WuQi. This Information or any portion
# thereof remains the property of WuQi. The Information contained herein
# is believed to be accurate and WuQi assumes no responsibility or
# liability for its use in any way and conveys no license or title under
# any patent or copyright and makes no representation or warranty that this
# Information is free from patent or copyright infringement.

import os
import sys
import json
import collections
import binascii
import json
import math
import platform
from enum import Enum
from enum import IntEnum

import pdb

oem_magic = 0x696F6D70
type_magic = 0x51
iomap_version = '0.1'
max_iomap_num = 32

class RESOURCE_TYPE(IntEnum):
    RESOURCE_TYPE_IOMAP         = 0
    RESOURCE_TYPE_COEX          = 1
    RESOURCE_TYPE_UART          = 2
    RESOURCE_TYPE_MAC           = 3
    RESOURCE_TYPE_PHY_INFO      = 4
    RESOURCE_TYPE_BT            = 5
    RESOURCE_TYPE_WIFI          = 6
    RESOURCE_TYPE_RTC_SOURCE    = 7
    RESOURCE_TYPE_FEM           = 8

class FEM_VENDOR_ID(IntEnum):
    FEM_VENDOR_NONE     = 0
    FEM_VENDOR_VANCHIP  = 1
    FEM_VENDOR_KCT_8531_EFEM = 2
    FEM_VENDOR_KCT_8585_SFPV_FEM_HE = 3
    FEM_VENDOR_KCT_FEM_HE_V1_2 = 4

class FEM_PROP(IntEnum):
    FEM_WIFI_ONLY   = 0
    FEM_SHARE_BT    = 1

class COEX_PROP(Enum):
    COEX_BT_BYPASS = 0
    COEX_BT_SHARE_WITH_SWITCH = 1
    COEX_BT_SHARE_NO_SWITCH = 2

class GPIO_ID(Enum):
    UART0_RXD            = 0
    UART0_TXD            = 1
    UART1_RXD            = 2
    UART1_TXD            = 3
    UART0_RTS            = 4
    UART0_CTS            = 5
    UART1_RTS            = 6
    UART1_CTS            = 7
    BT_UART_TXD          = 8
    BT_UART_RXD          = 9
    BT_UART_RTS          = 10
    BT_UART_CTS          = 11
    WIFI_UART_TXD        = 12
    WIFI_UART_RXD        = 13
    WIFI_UART_RTS        = 14
    WIFI_UART_CTS        = 15
    AUDIO_IIS_BCK        = 16
    AUDIO_IIS_WS         = 17
    AUDIO_IIS_TX         = 18
    AUDIO_IIS_RX         = 19
    BT_WAKEUP_HOST       = 32
    BT_WAKEUP_CONTROLLER = 33
    WLAN_WAKEUP_HOST     = 34
    WLAN_REG_ON          = 35
    COEX_RF_SWITCH       = 48
    COEX_3_WIRE_REQ      = 49
    COEX_3_WIRE_PRIO     = 50
    COEX_3_WIRE_RESULT   = 51
    FEM0_2G_C0           = 64
    FEM0_2G_C1           = 65
    FEM0_2G_C2           = 66
    FEM0_2G_C3           = 67
    FEM0_5G_C0           = 68
    FEM0_5G_C1           = 69
    FEM0_5G_C2           = 70
    FEM0_5G_C3           = 71
    FEM1_2G_C0           = 72
    FEM1_2G_C1           = 73
    FEM1_2G_C2           = 74
    FEM1_2G_C3           = 75
    FEM1_5G_C0           = 76
    FEM1_5G_C1           = 77
    FEM1_5G_C2           = 78
    FEM1_5G_C3           = 79
    WIFI_MP_TEST_TXD     = 80
    WIFI_MP_TEST_RXD     = 81
    BT_MP_TEST_TXD       = 82
    BT_MP_TEST_RXD       = 83
    PWM_CH_0             = 96
    PWM_CH_1             = 97
    PWM_CH_2             = 98
    PWM_CH_3             = 99
    APP_REPEATER_UART_TX = 128
    APP_REPEATER_UART_RX = 129
    APP_KEEP_ALIVE       = 130
    IO_MAP_MAX           = 255

class OemParse(object):
    def __init__(self, oem_bin):
        self.support_keys = [
            'version',
            'uart',
            'mac_addr',
            'iomap',
            'coex',
            'phy_params',
            'bt',
            'wifi',
            'rtc_source',
            'fem',
        ]

        self.bin         = oem_bin
        self.json        = collections.OrderedDict()
        self.version     = None

        self.discard_key    = []
        self.oem_type_count = 0

        self.bin_iomap   = None
        self.iomap_count = None

        self.bin_coex   = None
        self.coex_prop  = None

        self.bin_uart   = None
        self.port       = None
        self.baudrate   = None 

        self.bin_mac    = None

        self.bin_phy    = None
        self.phy_params = []

        self.bin_bt     = None
        self.bin_wifi   = None
        self.bin_rtc_source = None

        self.bin_fem    = None

    def check_magic(self):
        magic_from_bin = int.from_bytes(self.bin[:4], 'little')
        if magic_from_bin != oem_magic:
            print('bin magic check failed!')
            sys.exit(-1)

    def check_crc32(self):
        crc32_from_bin = int.from_bytes(self.bin[-4:], 'little')
        crc32 = binascii.crc32(self.bin[0 : len(self.bin) - 4])
        if crc32_from_bin != crc32:
            print('bin crc check failed!')
            sys.exit(-1)

    def parse_bin_header(self):
        ver = int(self.bin[4])
        ver_high = (ver >> 4) & 0xf
        ver_low = ver & 0xf
        self.oem_type_count = self.bin[5]
        self.version = str(ver_high) + '.' + str(ver_low)
        self.json['version'] = self.version

    def get_all_data_from_json(self, keys, data):
        if isinstance(keys, dict):
            for _, value in keys.items():
                self.get_all_data_from_json(value, data)
        else:
            if isinstance(keys, int):
                data.append(keys)
            elif isinstance(keys, list):
                data.extend(keys)

    def bin_parse_type(self):
        bin_tmp = self.bin[8:-4]
        
        find_key = []

        type_list = list(map(int, RESOURCE_TYPE))
        type_max_cnt = max(type_list)

        for _ in range(0, type_max_cnt + 1):
            if bin_tmp[0] != 0x51:
                print('iomap type magic error: %x, not 0x51' % (bin_tmp[0]))
                sys.exit(-1)
            else:
                bin_type = bin_tmp[1]
                bin_length = bin_tmp[2]
                if bin_type == RESOURCE_TYPE.RESOURCE_TYPE_IOMAP.value:
                    self.bin_iomap = bin_tmp[4 : 4 + bin_length]
                    find_key.append('iomap')
                elif bin_type == RESOURCE_TYPE.RESOURCE_TYPE_COEX.value:
                    self.bin_coex = bin_tmp[4 : 4 + bin_length]
                    find_key.append('coex')
                elif bin_type == RESOURCE_TYPE.RESOURCE_TYPE_UART.value:
                    self.bin_uart = bin_tmp[4 : 4 + bin_length]
                    find_key.append('uart')
                elif bin_type == RESOURCE_TYPE.RESOURCE_TYPE_MAC.value:
                    self.bin_mac_addr = bin_tmp[4 : 4 + bin_length]
                    find_key.append('mac_addr')
                elif bin_type == RESOURCE_TYPE.RESOURCE_TYPE_PHY_INFO.value:
                    self.bin_phy_params = bin_tmp[4 : 4 + bin_length]
                    find_key.append('phy_params')
                elif bin_type == RESOURCE_TYPE.RESOURCE_TYPE_BT.value:
                    self.bin_bt = bin_tmp[4 : 4 + bin_length]
                    find_key.append('bt')
                elif bin_type == RESOURCE_TYPE.RESOURCE_TYPE_WIFI.value:
                    self.bin_wifi = bin_tmp[4 : 4 + bin_length]
                    find_key.append('wifi')
                elif bin_type == RESOURCE_TYPE.RESOURCE_TYPE_RTC_SOURCE.value:
                    self.bin_rtc_source = bin_tmp[4 : 4 + bin_length]
                    find_key.append('rtc_source')
                elif bin_type == RESOURCE_TYPE.RESOURCE_TYPE_FEM.value:
                    self.bin_fem = bin_tmp[4 : 4 + bin_length]
                    find_key.append('fem')
                bin_tmp = bin_tmp[4 + bin_length:]

        for key in self.support_keys:
            if key not in find_key:
                self.discard_key.append(key)

    def parse_iomap(self):
        self.iomap_count = math.floor(len(self.bin_iomap) / 4)
        self.json['iomap'] = []
        i = 0
        while i < self.iomap_count:
            iomap_tmp = self.bin_iomap[i * 4 : i * 4 + 4]
            iomap_info = collections.OrderedDict()
            gpio_id = iomap_tmp[0]
            if gpio_id in GPIO_ID._value2member_map_:
                iomap_info['name'] = GPIO_ID(gpio_id).name.lower()
                iomap_info['id'] = gpio_id
                iomap_info['pull'] = iomap_tmp[1]
                iomap_info['gpio'] = iomap_tmp[2]
                self.json['iomap'].append(iomap_info)
            else:
                iomap_info['name'] = 'unknown to parse.py, maybe need add to GPIO_ID!'
                iomap_info['id'] = gpio_id
                iomap_info['pull'] = iomap_tmp[1]
                iomap_info['gpio'] = iomap_tmp[2]
                self.json['iomap'].append(iomap_info)
            i += 1

    def parse_phy_info(self):
        for i in self.bin_phy_params:
            self.phy_params.append(int(i) if int(i) <= 127 else int(i) - 256)
        
        self.json['phy_params'] = collections.OrderedDict()
        self.json['phy_params']['rate_max_pwr_hdb'] = collections.OrderedDict()
        self.json['phy_params']['rate_max_pwr_hdb']['11b_max_pwr_2g4'] = collections.OrderedDict()
        self.json['phy_params']['rate_max_pwr_hdb']['ofdm_max_pwr_2g4'] = collections.OrderedDict()
        self.json['phy_params']['rate_max_pwr_hdb']['11ax_max_pwr_2g4'] = collections.OrderedDict()
        self.json['phy_params']['rate_max_pwr_hdb']['ofdm_max_pwr_5g'] = collections.OrderedDict()
        self.json['phy_params']['rate_max_pwr_hdb']['11ax_max_pwr_5g'] = collections.OrderedDict()
        self.json['phy_params']['rate_max_pwr_hdb']['bw_pwr_offset'] = collections.OrderedDict()
        self.json['phy_params']['fem_truth_table'] = collections.OrderedDict()
        self.json['phy_params']['fem_truth_table']['2g'] = []
        self.json['phy_params']['fem_truth_table']['5g'] = []

        self.json['phy_params']['rate_max_pwr_hdb']['11b_max_pwr_2g4']['1M']     = self.phy_params[0]
        self.json['phy_params']['rate_max_pwr_hdb']['11b_max_pwr_2g4']['2M']     = self.phy_params[1]
        self.json['phy_params']['rate_max_pwr_hdb']['11b_max_pwr_2g4']['5p5M']   = self.phy_params[2]
        self.json['phy_params']['rate_max_pwr_hdb']['11b_max_pwr_2g4']['11M']    = self.phy_params[3]

        offset = 4
        for i in range(0, 10):
            self.json['phy_params']['rate_max_pwr_hdb']['ofdm_max_pwr_2g4']['mcs' + str(i)]  = self.phy_params[offset]
            offset += 1
        for i in range(0, 12):
            self.json['phy_params']['rate_max_pwr_hdb']['11ax_max_pwr_2g4']['mcs' + str(i)]  = self.phy_params[offset]
            offset += 1
        for i in range(0, 10):
            self.json['phy_params']['rate_max_pwr_hdb']['ofdm_max_pwr_5g']['mcs' + str(i)]  = self.phy_params[offset]
            offset += 1
        for i in range(0, 12):
            self.json['phy_params']['rate_max_pwr_hdb']['11ax_max_pwr_5g']['mcs' + str(i)]  = self.phy_params[offset]
            offset += 1

        self.json['phy_params']['rate_max_pwr_hdb']['bw_pwr_offset']['bw_20M']   = self.phy_params[48]
        self.json['phy_params']['rate_max_pwr_hdb']['bw_pwr_offset']['bw_40M']   = self.phy_params[49]
        self.json['phy_params']['rate_max_pwr_hdb']['bw_pwr_offset']['bw_80M']   = self.phy_params[50]

        for i in range(0, 8):
            self.json['phy_params']['fem_truth_table']['2g'].append(self.phy_params[51 + i])
        for i in range(0, 6):
            self.json['phy_params']['fem_truth_table']['5g'].append(self.phy_params[59 + i])

        self.json['phy_params']['sideband_limit_en'] = self.phy_params[65]

    def val_to_msk(self, val):
        if val == 0:
            return 0
        msk = 0
        for i in range(val):
            msk |= 0x1 << i
        return msk

    def parse_bt(self):
        bit_map = {
            'hci_mode': {
                'len': 2,
                'val': {
                    0: 'h2',
                    1: 'h4',
                    2: 'h5'
                }
            },
            'stb': {
                'len': 1,
                'val': {
                    0: 'disable',
                    1: 'enable'
                }
            },
            'host_wakeup_bt': {
                'len': 1,
                'val': {
                    0: 'gpio_default_low',
                    1: 'gpio_default_high'
                }
            },
            'bt_wakeup_host': {
                'len': 1,
                'val': {
                    0: 'gpio_default_low',
                    1: 'gpio_default_high'
                }
            },
            'deep_sleep': {
                'len': 1,
                'val': {
                    0: 'disable',
                    1: 'enable'
                }
            },
            'uart_hw_flow_ctrl': {
                'len': 1,
                'val': {
                    0: 'disable',
                    1: 'enable'
                }
            },
            'uart_parity_en': {
                'len': 1,
                'val': {
                    0: 'disable',
                    1: 'enable'
                }
            },
            'uart_parity': {
                'len': 1,
                'val': {
                    0: 'even',
                    1: 'odd'
                }
            },
            'uart_baudrate': {
                'len': 4
            }
        }

        offset = 0
        self.json['bt']     = collections.OrderedDict()
        hci_mode_val        = (int.from_bytes(self.bin_bt[:2], 'little') >> offset) & self.val_to_msk(bit_map['hci_mode']['len'])
        offset              += bit_map['hci_mode']['len']
        stb_val             = (int.from_bytes(self.bin_bt[:2], 'little') >> offset) & self.val_to_msk(bit_map['stb']['len'])
        offset              += bit_map['stb']['len']
        host_wakeup_bt_val  = (int.from_bytes(self.bin_bt[:2], 'little') >> offset) & self.val_to_msk(bit_map['host_wakeup_bt']['len'])
        offset              += bit_map['host_wakeup_bt']['len']
        bt_wakeup_host_val  = (int.from_bytes(self.bin_bt[:2], 'little') >> offset) & self.val_to_msk(bit_map['bt_wakeup_host']['len'])
        offset              += bit_map['bt_wakeup_host']['len']
        deep_sleep_val      = (int.from_bytes(self.bin_bt[:2], 'little') >> offset) & self.val_to_msk(bit_map['deep_sleep']['len'])
        offset              += bit_map['deep_sleep']['len']
        uart_hw_flow_ctrl_val   = (int.from_bytes(self.bin_bt[:2], 'little') >> offset) & self.val_to_msk(bit_map['uart_hw_flow_ctrl']['len'])
        offset                  += bit_map['uart_hw_flow_ctrl']['len']
        uart_parity_en_val      = (int.from_bytes(self.bin_bt[:2], 'little') >> offset) & self.val_to_msk(bit_map['uart_parity_en']['len'])
        offset                  += bit_map['uart_parity_en']['len']
        uart_parity_val         = (int.from_bytes(self.bin_bt[:2], 'little') >> offset) & self.val_to_msk(bit_map['uart_parity']['len'])
        offset                  += bit_map['uart_parity']['len']

        uart_baudrate       = int.from_bytes(self.bin_bt[2:6], 'little')

        self.json['bt']['hci_mode']         = bit_map['hci_mode']['val'][hci_mode_val]
        self.json['bt']['stb']              = bit_map['stb']['val'][stb_val]
        self.json['bt']['host_wakeup_bt']   = bit_map['host_wakeup_bt']['val'][host_wakeup_bt_val]
        self.json['bt']['bt_wakeup_host']   = bit_map['bt_wakeup_host']['val'][bt_wakeup_host_val]
        self.json['bt']['deep_sleep']       = bit_map['deep_sleep']['val'][deep_sleep_val]
        self.json['bt']['uart_hw_flow_ctrl']= bit_map['uart_hw_flow_ctrl']['val'][uart_hw_flow_ctrl_val]
        self.json['bt']['uart_parity_en']   = bit_map['uart_parity_en']['val'][uart_parity_en_val]
        self.json['bt']['uart_parity']      = bit_map['uart_parity']['val'][uart_parity_val]
        self.json['bt']['uart_baudrate']    = uart_baudrate

    def parse_wifi(self):
        bit_map = {
            'deep_sleep': {
                'len': 1,
                'val': {
                    0: 'disable',
                    1: 'enable'
                }
            }
        }

        offset = 0
        self.json['wifi'] = collections.OrderedDict()

        deep_sleep_val      = (int.from_bytes(self.bin_wifi, 'little') >> offset) & self.val_to_msk(bit_map['deep_sleep']['len'])
        offset              += bit_map['deep_sleep']['len']

        self.json['wifi']['deep_sleep']       = bit_map['deep_sleep']['val'][deep_sleep_val]

    def parse_rtc_source(self):
        bit_map = {
            'source': {
                'len': 2,
                'val': {
                    0: 'rco',
                    1: 'xtal',
                    2: 'ext_32k',
                    3: '32k_xtal'
                }
            }
        }

        offset = 0
        self.json['rtc_source'] = collections.OrderedDict()

        source_val          = (int.from_bytes(self.bin_rtc_source, 'little') >> offset) & self.val_to_msk(bit_map['source']['len'])
        offset              += bit_map['source']['len']

        self.json['rtc_source']['source'] = bit_map['source']['val'][source_val]

    def parse_fem(self):
        self.json['fem'] = collections.OrderedDict()

        fem_vendor = self.bin_fem[0]
        fem_prop = self.bin_fem[1]

        fem_vendor_max = max(list(map(int, FEM_VENDOR_ID)))
        fem_prop_max   = max(list(map(int, FEM_PROP)))

        if fem_vendor > fem_prop_max:
            print('fem vendor value error, max {0}, find {1}'.format(fem_prop_max, fem_vendor))
        if fem_prop > fem_vendor_max:
            print('fem vendor value error, max {0}, find {1}'.format(fem_prop_max, fem_vendor))

        invert_signal_map = {
            'vendor': {
                FEM_VENDOR_ID.FEM_VENDOR_NONE.value     : 'none',
                FEM_VENDOR_ID.FEM_VENDOR_VANCHIP.value  : 'vanchip',
                FEM_VENDOR_ID.FEM_VENDOR_KCT_8531_EFEM.value          : 'kct_8531_efem',
                FEM_VENDOR_ID.FEM_VENDOR_KCT_8585_SFPV_FEM_HE.value   : 'kct_8585_sfpv_fem_he',
                FEM_VENDOR_ID.FEM_VENDOR_KCT_FEM_HE_V1_2.value        : 'kct_fem_he_v1_2'
            },
            'prop': {
                FEM_PROP.FEM_WIFI_ONLY.value    : 'wifi_only',
                FEM_PROP.FEM_SHARE_BT.value     : 'share_bt',
            }
        }

        self.json['fem']['vendor'] = invert_signal_map['vendor'][fem_vendor]
        self.json['fem']['prop'] = invert_signal_map['prop'][fem_prop]

    def parse_coex(self):
        self.json['coex'] = collections.OrderedDict()
        self.json['coex']['prop'] = COEX_PROP(self.bin_coex[0]).name.lower()[5:]

        invert_signal_map = {
            0: 'disable',
            1: 'enable',
        }

        self.json['coex']['invert_signal'] = invert_signal_map[self.bin_coex[1]]
        self.json['coex']['ant2_version'] = self.bin_coex[2]

    def parse_uart(self):
        out_core_map = {
            0: "core0",
            1: "core1",
            2: "core2",
            3: "core3",
            0xff : "Not specified"
        }

        out_host_enable_map = {
            0: "disable",
            1: "enable",
            0xff : "Not specified"
        }

        self.uart_port = self.bin_uart[0]
        self.out_core = self.bin_uart[1]
        self.out_host_enable = self.bin_uart[2]
        self.uart_baudrate = int.from_bytes(self.bin_uart[4:7], 'little')
        self.json['uart'] = collections.OrderedDict()
        self.json['uart']['port'] = self.uart_port
        self.json['uart']['out_core'] = out_core_map[self.out_core]
        self.json['uart']['out_host_en'] = out_host_enable_map[self.out_host_enable]
        self.json['uart']['baudrate'] = self.uart_baudrate

    def parse_mac(self):
        mac_addr = (hex(self.bin_mac_addr[0])[2:] + ':' +
                    hex(self.bin_mac_addr[1])[2:] + ':' +
                    hex(self.bin_mac_addr[2])[2:] + ':' +
                    hex(self.bin_mac_addr[3])[2:] + ':' +
                    hex(self.bin_mac_addr[4])[2:] + ':' +
                    hex(self.bin_mac_addr[5])[2:])
        self.json['mac_addr'] = mac_addr

    def show_phy_params(self):
        print('phy config:')
        for key in self.json['phy_params']:
            if key in ['rate_max_pwr_hdb', 'fem_truth_table']:
                print('  -> {0}:'.format(key))
                for sub_key in self.json['phy_params'][key]:
                    key_data = []
                    self.get_all_data_from_json(self.json['phy_params'][key][sub_key], key_data)
                    print('      -> {0}: {1}'.format(sub_key.ljust(16), key_data))
            else:
                key_data = []
                self.get_all_data_from_json(self.json['phy_params'][key], key_data)
                print('  -> {0}: {1}'.format(key.ljust(16), key_data))

    def show_iomap(self):
        print('iomap: {0}'.format(self.iomap_count))  
        for iomap in self.json['iomap']:
            iomap_name = iomap['name']
            iomap_id = iomap['id']
            iomap_pull = iomap['pull']
            iomap_gpio = iomap['gpio']
            print('  -> {0}: id {1} -> gpio {2}, pull {3}'.format(iomap_name.ljust(20), iomap_id, iomap_gpio, iomap_pull))

    def show_parse_info(self):
        print('oem\n  -> version: {0}\n  -> key cnt: {1}'.format(self.json['version'], self.oem_type_count))

        for key in self.discard_key:
            self.support_keys.remove(key)
            print('cant find oem key: {0}, discarded'.format(key))

        for key in self.support_keys:
            if key == 'version':
                continue
            elif key == 'phy_params':
                self.show_phy_params()
                continue
            elif key == 'iomap':
                self.show_iomap()
            else:
                print('{0}:'.format(key))
                if type(self.json[key]) == collections.OrderedDict:
                    for key, val in self.json[key].items():
                        print('  -> {0}: {1}'.format(key.ljust(20), val))
                elif type(self.json[key]) in [str, int]:
                    print('  -> {0}'.format(self.json[key]))

    def gen_json(self, path):
        separator_char = '\\' if platform.system() == 'Windows' else '/'
        output_name = path.split(separator_char)[-1]

        if output_name.startswith('wq9201_oem_'):
            output_name = 'oem_' + output_name[len('wq9201_oem_') + 4:]

        output_name = output_name.split('.')[0]
        output_name = output_name + '_parse.json'
        json.dump(self.json, open(output_name,'w'), indent = 4)

def bin_parse(bin_path):
    if not os.path.exists(os.path.join(bin_path)):
        print('cant find %s' % (bin_path))
        sys.exit(-1)
    else:
        with open(bin_path, 'rb') as f:
            bin = f.read()

    if os.path.getsize(bin_path) != 256:
        print('oem bin size is not 256 Bytes, read {0}'.format(os.path.getsize(bin_path)))
        sys.exit(-1)

    oem_parse = OemParse(bin)
    oem_parse.check_magic()
    oem_parse.check_crc32()
    oem_parse.parse_bin_header()
    oem_parse.bin_parse_type()

    oem_parse.parse_fem()
    oem_parse.parse_coex()
    oem_parse.parse_bt()
    oem_parse.parse_wifi()
    oem_parse.parse_rtc_source()
    oem_parse.parse_uart()
    oem_parse.parse_mac()
    oem_parse.parse_iomap()
    oem_parse.parse_phy_info()
    oem_parse.show_parse_info()
    oem_parse.gen_json(bin_path)

if __name__ == "__main__":
    bin_parse(sys.argv[1])
